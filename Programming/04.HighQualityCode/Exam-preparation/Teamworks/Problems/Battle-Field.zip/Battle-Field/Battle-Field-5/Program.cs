﻿namespace BattleField
{
    class Program
    {
        static void Main(string[] args)
        {
            // ei go na pochva
            Battlefield game = new Battlefield();
            game.Start();
            // i do tuka ne stigam
        }
    }
}
