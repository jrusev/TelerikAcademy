﻿namespace BattleField
{
    public class Mine
    {
        // a tova e mina
        public int X { get; set; }
        public int Y { get; set; }
    }
}
