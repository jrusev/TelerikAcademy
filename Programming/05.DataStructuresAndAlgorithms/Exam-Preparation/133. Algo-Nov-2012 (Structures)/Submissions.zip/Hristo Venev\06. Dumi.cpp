#include <string>
#include <iostream>
#include <vector>
#include <set>
struct WordData{
    unsigned met[32];
    WordData(const std::string &str){
        for(unsigned i=0;i<32;i++) met[i]=0;
        for(std::string::const_iterator i=str.begin();i!=str.end();++i){
            if(*i>='A'&&*i<='Z') met[*i-'A']++;
            if(*i>='a'&&*i<='z') met[*i-'a']++;
        }
        return;
    }
    bool contains(const WordData &wd){
        for(unsigned i=0;i<32;i++){
            if(wd.met[i]&&!met[i]) return 0;
        }
        return 1;
    }
};
std::vector<WordData> words;
std::set<std::string> unique;
void callback(const std::string &word){
    if(!unique.insert(word).second) return;
    words.push_back(WordData(word));
    return;
}
void processLine(){
    char ch=std::cin.get();
    std::string word;
    while(ch!='\n'){
        if((ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z')){
            word.push_back(ch&~32);
        }else if(!word.empty()){
            if(!word.empty()) callback(word);
            word.clear();
        }
        ch=std::cin.get();
    }
    if(!word.empty()) callback(word);
    return;
}
int main(){
    unsigned N;
    std::ios::sync_with_stdio(0);
    std::cin.tie(0);
    std::cin>>N;
    std::cin.get();
    while(N--) processLine();
    std::cin>>N;
    while(N--){
        std::string w;
        std::cin>>w;
        WordData wd=WordData(w);
        unsigned cnt=0;
        for(size_t i=0;i<words.size();i++){
            if(words[i].contains(wd)) cnt++;
        }
        std::cout<<w<<" -> "<<cnt<<'\n';
    }
    return 0;
}