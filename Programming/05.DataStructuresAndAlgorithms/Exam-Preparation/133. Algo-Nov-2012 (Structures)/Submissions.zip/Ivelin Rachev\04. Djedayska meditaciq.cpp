#include<iostream>
#include<vector>
#include<string>
using namespace std;
string master="";
string knight="";
string padowan="";
int main()
{
  int n;
  cin>>n;
  string s;
  for(int i=0;i<n;i++)
  {
    cin>>s;
    if(s[0]=='m'){master+=s;master+=' ';}
    if(s[0]=='k'){knight+=s;knight+=' ';}
    if(s[0]=='p'){padowan+=s;padowan+=' ';}
  }
  string ans="";
  ans+=master;
  ans+=knight;
  ans+=padowan;
  ans.erase(ans.size()-1,1);
  cout<<ans<<endl;
  cout<<endl;
  return 0;
}