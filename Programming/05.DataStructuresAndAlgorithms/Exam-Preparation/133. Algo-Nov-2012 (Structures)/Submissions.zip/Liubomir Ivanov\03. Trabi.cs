using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Pipes
{
    static void Main(string[] args)
    {
        long n = int.Parse(Console.ReadLine());
        long m = int.Parse(Console.ReadLine());
        long[] a = new long[n];
        long sum = 0;
        for (int i = 0; i < n; i++)
        {
            a[i] = int.Parse(Console.ReadLine());
            sum += a[i];
        }
        long length = sum / m;
        for ( ;  ; length--)
        {
            long countOfPipes = 0;
            for (int j = 0; j < n; j++)
            {
                countOfPipes += (a[j] / length);
            }
            if (countOfPipes >= m)
            {
                break;
            }
        }
        Console.WriteLine(length);
    }
}