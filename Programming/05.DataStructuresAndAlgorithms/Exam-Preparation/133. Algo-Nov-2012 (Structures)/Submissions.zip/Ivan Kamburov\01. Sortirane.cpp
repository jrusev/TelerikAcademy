#include <stdio.h>
#include <queue>
#include <vector>

using namespace std;

unsigned int x;

struct intComparer
{
	bool operator()(unsigned int a, unsigned int b)
	{
		return ((a % x > b % x) || ((a % x == b%x) && (a > b)));
	}
};

int n;
priority_queue <unsigned int, vector<unsigned int>, intComparer> sortedList;

void Input()
{
    scanf("%d%u", &n, &x);
    for (int i = 0; i < n; i++)
    {
        unsigned int a;
        scanf("%u", &a);
        sortedList.push(a);
    }
}

int main()
{
    Input();
    printf("%u", sortedList.top());
    sortedList.pop();
    int sortedListSize = sortedList.size();
    for (int i = 1; i <= sortedListSize; i++)
    {
        printf(" %u", sortedList.top());
        sortedList.pop();
    }
    printf("\n");

    return 0;
}

