#include<iostream>
using namespace std;
int q[50005]={0};
struct comand
{
 unsigned long long ch;
 string k;
};
int main ()
{
string c;
int ind=0;
comand s[50005];
int n;
cin>>n;
for (int i=0; i<n; i++)
{
  cin>>c;
  if (c=="New")
  {
    cin>>s[i].ch>>s[i].k;
  }
}
cout<<"Rest"<<endl;
 return 0;
}