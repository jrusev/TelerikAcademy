#include <cstdio>
#include <vector>
#include <algorithm>
struct Coord{
    unsigned x, y;
    Coord(unsigned a, unsigned b):x(a),y(b){}
};
unsigned diff(unsigned a, unsigned b){
    if(a<b) return b-a;
    return a-b;
}
unsigned dist(const Coord &a, const Coord &b){
    return diff(a.x, b.x)+diff(a.y, b.y);
}
double grade(){
    unsigned w, h;
    std::vector<Coord> food, v;
    scanf("%u %u", &w, &h);
    for(unsigned x=0;x<w;x++){
        for(unsigned y=0;y<h;y++){
            char ch=10;
            while(ch==10||ch==32) scanf("%c", &ch);
            if(ch=='*') v.push_back(Coord(x,y));
            else if(ch=='#') food.push_back(Coord(x,y));
        }
    }
    if(v.size()>2*food.size()){
        return 1.0/0.0;
    }else if(2*v.size()<food.size()){
        return 0.0;
    }
    double quality=0;
    for(unsigned i=0;i<v.size();i++){
        unsigned min=1000000000;
        for(unsigned j=0;j<food.size();j++){
            unsigned curr=dist(v[i], food[j]);
            if(curr<min) min=curr;
        }
        quality+=min;
    }
    return quality/v.size();
}
std::pair<double, unsigned> pop[1<<17];
unsigned sel[1<<17];
int main(){
    unsigned N, i, max, min;
    scanf("%u %u %u", &N, &max, &min);
    for(i=0;i<N;i++){
        pop[i].second=i+1;
        pop[i].first=grade();
    }
    std::sort(pop, pop+N);

    for(i=0;i<max;i++){
        sel[i]=pop[i].second;
    }
    std::sort(sel, sel+max);
    for(i=0;i<max;i++){
        if(i==0) printf("%u", sel[i]);
        else printf(" %u", sel[i]);
    }
    putchar(10);
    
    for(i=0;i<min;i++){
        sel[i]=pop[N-1-i].second;
    }
    std::sort(sel, sel+min);
    for(i=0;i<min;i++){
        if(i==0) printf("%u", sel[i]);
        else printf(" %u", sel[i]);
    }
    putchar(10);
    return 0;
}