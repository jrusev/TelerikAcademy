#include<cstdio>
using namespace std;
int main()
{
    printf("OK\n");
    return 0;
}
