#include <iostream>
using namespace std;
int main() {
int n;
long long sum=0,ostatak=0,current,m ;
cin>>n>>m;
long long a[n] ;
for(int i=0;i<n;i++){
    cin>>current ;
    a[i]=current;
    sum+=current/m;
    ostatak+=current%m ;
    //cout<<current<<" "<<sum<<" "<<ostatak<<endl; ;
    if(ostatak>=m){sum+=ostatak/m;ostatak%=m;}
} if(ostatak>=m){sum+=ostatak/m;ostatak%=m;}
   
for(long long i=sum;i>0;i--){
        long long s=0,h;
        for(long long j=0;j<n;j++)s+=a[j]/i ;
        if(s==m){cout<<i<<endl;return 0;}
}
return 0;
}