using System;
using System.Linq;


class SortingNumbers
{
    class Numbers
    {
        public uint value { get; set; }
        public uint reminder { get; set; }
    }


    static void Main(string[] args)
    {
        string[] input = Console.ReadLine().Split(' ');
        int n = int.Parse(input[0]);
        uint x = uint.Parse(input[1]);
        string[] inputNumbers = Console.ReadLine().Split(' ');
        Numbers[] numbers = new Numbers[n];
        for (int i = 0; i < n; i++)
        {
            numbers[i] = new Numbers();
            numbers[i].value = uint.Parse(inputNumbers[i]);
            numbers[i].reminder = numbers[i].value % x;
        }
        var sortedList = numbers.OrderBy(si => si.value).ToList();
        sortedList = sortedList.OrderBy(si => si.reminder).ToList();
        for (int i = 0; i < n; i++)
        {
            Console.Write("{0} ", sortedList[i].value);
        }
        Console.WriteLine();
    }
}

