#include <iostream>
#include <queue>
#include <cstdio>
#include <algorithm>
#include <cmath>
#define INF 50000
using namespace std;

struct pop
{
       int ind;
       double v;
       pop(){}
       pop(int _ind, double _v)
       {
               ind=_ind;
               v=_v;
       }
       bool operator<(const pop &a)
       const {
            if(v<a.v) return true;
            if(v==a.v) return ind<a.ind;
            return false;
       }
};


struct point
{
       int x,y;
       point(){}
       point(int _x, int _y)
       {
                 x=_x;
                 y=_y;
       }
};

char c[16][16];
vector<point> dz;
vector<point> zv;
     
vector<pop> a;
vector<int> res1;
vector<int> res2;
int main()
{
    int n,kmn, kmx;
    scanf("%d%d%d", &n, &kmn, &kmx);
    
    int r,cc;
    int m, kzz, mw;
    double cr=0;
    double mn;
    for(int i=0; i<n; i++)
    {
            kzz=0;
            scanf("%d%d", &r, &cc);
            for(int ri=0; ri<r; ri++) 
            {
                    for(int ci=0; ci<cc; ci++)
                    {
                            cin >> c[ri][ci];
                            if(c[ri][ci]=='*') dz.push_back(point(ri,ci));
                            if(c[ri][ci]=='#') { zv.push_back(point(ri, ci)); kzz++; }
                    }
                            
                    //scanf("\n");
            }
            
            cr=0.0;
            m=dz.size();
            mw=zv.size();
            
            if(kzz*2<m) cr=INF;
            else if(m*2<kzz) cr=-INF;
            else {
               for(int j=0; j<m; j++){
                       mn=5000;
                       for(int w=0; w<mw; w++) mn=min(mn,(double)abs(dz[j].x-zv[w].x)+abs(dz[j].y-zv[w].y));
                       cr+=mn;
                       //cout << cr << "-";
                       }
               cr/=m;
               }
            dz.clear();
            zv.clear();
            a.push_back(pop(i,cr));
           // cout << endl;
            //cout << cr << endl;
    }
    
    sort(a.begin(),a.end());
    
    //cout << "whole sorted vector\n";
    
    //for(int i=0; i<n; i++) cout << a[i].ind+1 << ' ' << a[i].v << endl;
    //cout << endl;
   
    
    
    for(int i=0; i<kmn; i++)
    {
            res1.push_back(a[i].ind+1);
    }
    
    for(int i=0; i<kmx; i++)
    {
            res2.push_back(a[n-i-1].ind+1);
    }
    
    sort(res1.begin(), res1.end());
    sort(res2.begin(), res2.end());
    
    
    int xn, xm;
    xn=res1.size(); xm=res2.size();
    for(int i=0; i<xn-1; i++) cout << res1[i] << ' '; cout << res1[xn-1] << endl;
    for(int i=0; i<xm-1; i++) cout << res2[i] << ' '; cout << res2[xm-1] << endl;
           
    
    return 0;
}
