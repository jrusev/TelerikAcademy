#include <iostream>
#include <algorithm>
#include <cstdio>
#include <vector>
using namespace std;
struct jedi
{
       char r;
       int id;
       int ind;
       jedi(){}
       jedi(char _r, int _id, int _ind)
       {
                 r=_r;
                 id=_id;
                 ind=_ind;
       }
        
      /* bool operator<(jedi const &a)
       const {
            if(rk[r]>rk[a.r]) return true;
            if(rk[r]==rk[a.r]) return ind>a.ind;
            return false;
       }*/
}a[128000];
 
vector<jedi> vr;
 
int main()
{
    int n;
    scanf("%d\n", &n);
    char c;
    int d;
     
    for(int i=0; i<n; i++)
    {
            scanf("%c%d", &c, &d);
            a[i]=jedi(c,d,i);
            if(c=='m') vr.push_back(a[i]);
            if(i<n-1) scanf(" ");
           //cout << c << "   sadjklads   " << d << endl;
    }
     
    for(int i=0; i<n; i++) if(a[i].r=='k') vr.push_back(a[i]);
    for(int i=0; i<n; i++) if(a[i].r=='p') vr.push_back(a[i]);
     
    for(int i=0; i<n-1; i++)
    {
            printf("%c%d ", vr[i].r, vr[i].id);
    }
     
    printf("%c%d\n", vr[n-1].r, vr[n-1].id);
    return 0;
}