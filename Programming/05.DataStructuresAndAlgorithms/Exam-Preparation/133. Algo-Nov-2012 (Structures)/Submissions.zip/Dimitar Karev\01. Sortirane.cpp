//
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
vector<long long int>a;
long long n,x;
    bool comp(long long a,long long b)
    {
        if(a%x<b%x){return 1;}
        if(a%x>b%x){return 0;}
        if(a%x==b%x)
        {
            if(a<b){return 1;}
            else{return 0;}
        }
    }
int main()
{
    long long Help;
    cin>>n>>x;
    for(int i=0;i<n;i++)
    {
        cin>>Help;
        a.push_back(Help);
    }
    sort(a.begin(),a.end(),comp);
    cout<<a[0];
    for(int i=1;i<n;i++)
    {
        cout<<" "<<a[i];
    }
    cout<<endl;
    return 0;
}