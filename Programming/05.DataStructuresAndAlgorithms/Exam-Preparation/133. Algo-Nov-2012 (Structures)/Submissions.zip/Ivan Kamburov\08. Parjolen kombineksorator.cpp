#include <stdio.h>
#include <vector>
#include <algorithm>
#include <math.h>

using namespace std;

struct point
{
    int x;
    int y;
};

struct steak
{
    point a;
    point b;
    point c;
    double steakSize;
};

int n;
vector<double> steakSizes;
vector<double> finalSteakSizes;

double DistanceBetweenPoints(point a, point b)
{
    return sqrt(((a.x - b.x) * (a.x - b.x)) + ((a.y - b.y) * (a.y - b.y)));
}

int main()
{
    scanf("%d", &n);

    for (int i = 0; i < n; i++)
    {
        steak a;
        scanf("%d%d%d%d%d%d", &a.a.x, &a.a.y, &a.b.x, &a.b.y, &a.c.x, &a.c.y);
        double A = DistanceBetweenPoints(a.a, a.b), B = DistanceBetweenPoints(a.b, a.c), C = DistanceBetweenPoints(a.a, a.c), s = (A + B + C) / 2;
        a.steakSize = sqrt(s * (s - A) * (s - B) * (s - C));
        steakSizes.push_back(a.steakSize);
        //!printf(" i = %d current size = %f\n", i, a.steakSize);
    }

    sort(steakSizes.begin(), steakSizes.end());

    double currentSteakSize = steakSizes[0];
    int i = 1, numberOfCurrentSteaks = 1;

    while(i < n)
    {
        printf("current size = %f\n", currentSteakSize);
        while ((steakSizes[i] == currentSteakSize) && (i < n))
        {
            i++;
            numberOfCurrentSteaks++;
        }
        if (i == n) numberOfCurrentSteaks--;
        if (numberOfCurrentSteaks % 2) finalSteakSizes.push_back(currentSteakSize);
        if (i < n) currentSteakSize = steakSizes[i];
        numberOfCurrentSteaks = 1;
    }

    if (finalSteakSizes.size() == 1) printf("%f\n", finalSteakSizes[0]);
    else printf("%f\n", finalSteakSizes[2]);

    return 0;
}
