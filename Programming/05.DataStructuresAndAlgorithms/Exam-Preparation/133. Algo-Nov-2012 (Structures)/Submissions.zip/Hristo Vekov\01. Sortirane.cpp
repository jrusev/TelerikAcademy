#include <iostream>
#include<cstdio>
#include <algorithm>
using namespace std;
unsigned long long a[100001];
int x;
bool chislo(unsigned long long a,unsigned  long long b)
{if(a%x==b%x) return a<b;
 return a%x<b%x;

}

int main()
{unsigned long long  n,i;
   scanf("%llu%llu",&n,&x);
for(i=0;i<n;i++) scanf("%llu",&a[i]);

sort(a,a+n,chislo);
cout<<a[0];
for(i=1;i<n;i++) printf(" %llu",a[i]);
cout<<endl;
return 0;
}
