#include <iostream>
using namespace std;
int main ()
{
    long long M, N, i, sum, oldsum, maxl, x, oldmaxl;
    long l[20001];
    cin>>N>>M;
    for (i=0;i<N;i++)
    {
        cin>>l[i];
        sum=sum+l[i];
    }
    maxl=sum/M;
    x=maxl;
    do
    {
          sum=0;
          for (i=0;i<N;i++)
              sum=sum+l[i]/maxl;
          x=x/2; if (x==0) x=1;
          if (sum>M) maxl=maxl+x;
          else if (sum<M) maxl=maxl-x;
          else 
              {
               oldsum=sum;
               do{
                 maxl++;
                 sum=0;
                 for (i=0;i<N;i++)
                 sum=sum+l[i]/maxl;
                 }
               while (sum==M);
               sum=oldsum; maxl--;
               }
    } while (sum!=M);
    cout<<maxl<<endl;
//    system ("pause");
    return 0;
}