#include <cstdio>
int n;
long long pipes[1 << 15];
long long m;
long long sum;
int main() {
    scanf("%d %lld", &n, &m);
    long long max = 0;
    for (int i = 0;i < n; ++i) {
        scanf("%lld", &pipes[i]);
        sum += pipes[i];
        if (max < pipes[i])
            max = pipes[i];
    }
    if (sum < m) {
        puts("-1");
        return 0;
    }
    long long l = 0, mid, r = max + 1;
    while (l + 1 < r) {
        mid = (r + l) / 2;
        long long count = 0;
        for (int i = 0; i < n; ++i) {
            count += pipes[i] / mid;
        }
        if (count >= m) l = mid;
        else r = mid;
    }
    printf("%lld\n", l);
    return 0;
}