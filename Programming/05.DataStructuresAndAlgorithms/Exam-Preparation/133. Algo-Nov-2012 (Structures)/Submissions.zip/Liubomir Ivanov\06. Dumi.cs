using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Words
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        Dictionary<string, int> occurences = new Dictionary<string, int>();
        for (int j = 0; j < n; j++)
        {
            string separators = @",.:;~ !@#$%^&*(){}\/[]<>|'?؟-_+،""=";
            string s = Console.ReadLine();
            s = s.ToLower();
            for (int i = 0; i < s.Length; i++)
            {
                if (separators.Contains(s[i]) == true)
                {
                    string word = s.Substring(0, i);
                    s = s.Remove(0, i + 1);
                    if (word.Length != 0)
                    {
                        if (occurences.ContainsKey(word) == true)
                        {
                            occurences[word]++;
                        }
                        else
                        {
                            occurences.Add(word, 1);
                        }
                    }
                    i = -1;
                }
            }
        }
        int w = int.Parse(Console.ReadLine());
        string result = "";
        for (int i = 0; i < w; i++)
        {
            string input = Console.ReadLine();
            string word = input.ToLower();
            int count = 0;
            int length = word.Length;
            foreach (var item in occurences)
            {
                bool flag = true;
                for (int j = 0; j < length; j++)
                {
                    if (item.Key.Contains(word[j]) == false)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag == true)
                {
                    count++;
                }
            }
            result += (input + " -> " + count.ToString() + "\n");
        }
        //foreach (var item in occurences)
        //{
        //    Console.WriteLine("{0} - {1} times",item.Key,item.Value);
        //}
        Console.Write(result);
    }
}