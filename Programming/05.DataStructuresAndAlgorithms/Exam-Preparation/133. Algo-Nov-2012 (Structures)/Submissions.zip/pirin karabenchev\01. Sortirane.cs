using System;
using System.Collections.Generic;
using Wintellect.PowerCollections;

class Sort
{
    static uint x;
    static public int CustomSort(uint first, uint second)
    {
        if ((first % x) == (second % x))
        {
            return first.CompareTo(second);
        }
        else
        {
            return (first % x).CompareTo(second % x);
        }
    }
    static void Main()
    {
        string[] input = Console.ReadLine().Split();
        int n = int.Parse(input[0]);
        x = uint.Parse(input[1]);
        input = Console.ReadLine().Split();
        List<uint> numbers = new List<uint>();
        for (int i = 0; i < n; i++)
			{
			    numbers.Add(uint.Parse(input[i]));   
			}
        numbers.Sort(new Comparison<uint>(CustomSort));
        for (int i = 0; i < n; i++)
        {
            Console.Write(numbers[i] + " ");

        }
    }
}