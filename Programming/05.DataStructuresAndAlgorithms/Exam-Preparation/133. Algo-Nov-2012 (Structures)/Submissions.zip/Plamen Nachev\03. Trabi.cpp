#include <iostream>
#include <cstdio>
using namespace std;
int main()
{ 
  int N;
  long long M, x[10000];
  
  scanf("%d %I64d", &N, &M);
  
//  long long min_el = 2000000000;
  scanf("%I64d", &x[0]);
  //if( x[0] < min_el )  min_el = x[0];
  
  long long sum = x[0];
  
  for( int i = 1; i < N; i++ )
  { 
    scanf("%I64d", &x[i]);
    //if( x[i] < min_el )  min_el = x[i];
    sum += x[i];
   }
  
  long long br = 0, i;
  for( i = sum/M; i >= 1; i-- )
  { 
    br = 0;
    for( int j = 0; j < N; j++ )
    br += x[j]/i;
    
    
    if( br == M )  break;
   }
  
  printf("%I64d\n", i);
    
  //scanf("%d", &N);
  return 0;
}
/*
4
11
803
777
444
555

*/
