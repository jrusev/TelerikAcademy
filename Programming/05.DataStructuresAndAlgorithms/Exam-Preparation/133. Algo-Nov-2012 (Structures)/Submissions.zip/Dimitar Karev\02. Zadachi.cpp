//
#include<iostream>
#include<vector>
#include<algorithm>
#include<set>
using namespace std;
pair<long long int,string>a[50000];
int main()
{
    bool l=0;
    long long int n,Help,k=0,k1=0;
    cin>>n;
    string s,s1;
    for(int i=0;i<n;i++)
    {
        cin>>s;
        if(s[0]=='N')
        {
            cin>>Help;
            cin>>s1;
            a[k].first=Help;
            a[k].second=s1;
            k++;
            l=1;
        }
        else
        {
            if(k1+1!=k && l==1){sort(a+k1,a+k);}
            if(k1<k)cout<<a[k1].second<<endl;
            else{cout<<"Rest"<<endl;}
            k1++;
            l=0;           
        }
    }
    return 0;
}