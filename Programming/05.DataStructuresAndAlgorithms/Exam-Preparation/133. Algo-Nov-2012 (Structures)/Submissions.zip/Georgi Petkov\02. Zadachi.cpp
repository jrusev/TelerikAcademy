#include <iostream>
#include <cstring>
#include <set>
using namespace std;
//binary heap
struct task
{
	int complexity;
	char name[7];
};

struct taskComparer
{
    bool operator()(task a, task b)
    {
        return a.complexity < b.complexity
			|| (a.complexity == b.complexity && strcmp(a.name, b.name) < 0);
    }
};


int main()
{
	int N;
	cin >> N;

	set<task, taskComparer> ms;
	set<task>::iterator b;
	char buffer[6];
	task t;

	for (int i = 0; i < N; ++i)
	{
		cin >> buffer;
		if(strcmp(buffer, "New") == 0)
		{
			cin >> t.complexity;
			cin >> t.name;
			ms.insert(t);
		}
		else
		{
			if(ms.size() == 0)
			{
				cout << "Rest" << endl;
			}
			else
			{
				b = ms.begin();
				cout << b->name << endl;
				ms.erase(b);
			}
		}
	}

	return 0;
}