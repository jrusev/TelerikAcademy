#include<cstdio>
int n,m;
int A[20042];
int s,l,r,curr;
int main()
{
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;++i)
		scanf("%d",A+i);
	l=1;r=2000000042;
	while(l+1<r)
	{
		s=l+r>>1;
		curr=A[0]/s;
		for(int i=1;i<n;++i)
			curr+=A[i]/s;
		if(curr<m)r=s;
		else l=s;
	}
	printf("%d\n",l);
	return 0;
}
