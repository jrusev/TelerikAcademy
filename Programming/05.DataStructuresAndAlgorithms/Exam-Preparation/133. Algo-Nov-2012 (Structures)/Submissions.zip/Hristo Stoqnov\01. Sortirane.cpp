#include <cstdio>
#include <algorithm>
using namespace std;
typedef long long ll;
ll x;
bool cmp(ll a, ll b) {
    ll ax, bx;
    ax = a % x;
    bx = b % x;
    if (ax < bx) return true;
    if (ax > bx) return false;
    if (a < b) return true;
    return false;
}
int n;
ll nums[1 << 17];
int main() {
    scanf("%d %lld", &n, &x);
    for (int i = 0;i < n; ++i) {
        scanf("%lld", nums + i);
    }
    sort(nums, nums + n, cmp);
    printf("%lld", nums[0]);
    for (int i = 1;i < n; ++i) {
        printf(" %lld", nums[i]);
    }
    puts("");
    return 0;
}