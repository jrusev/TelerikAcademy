using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evolution
{
    class Program
    {
        class Population
        {
            public Population(int a, int b)
            {
                this.rows = a;
                this.cols = b;
                this.charArray = new string[a, b];
            }

            public string[,] charArray { get; set; }
            public int rows { get; set; }
            public int cols { get; set; }


            public int GetPerspect()
            {
                int creatures = 0;
                int food = 0;
                for (int row = 0; row < rows; row++)
			    {
                    for (int col = 0; col < cols; col++)
                    {
                        if (this.charArray[row, col] == "*")
                        {
                            creatures++;
                        }
                        if (this.charArray[row, col] == "#")
                        {
                            food++;
                        }
                    }
			    }
                if (food > 2 * creatures)
                {
                    return 2;
                }
                if (creatures > 2 * food)
                {
                    return 0;
                }
                else
                {
                    return 1;
                }
            }

            public int GetDistance()
            {
                int creaturesX = 0;
                int creaturesY = 0;
                int foodX = 0;
                int foodY = 0;
                int count = 0;
                for (int row = 0; row < rows; row++)
                {
                    for (int col = 0; col < cols; col++)
                    {
                        if (this.charArray[row, col] == "*")
                        {
                            creaturesX += col;
                            creaturesY += row;
                        }
                        if (this.charArray[row, col] == "#")
                        {
                            foodX += col;
                            foodY += row;
                            count++;
                        }
                    }
                }
                int distanceX = Math.Abs(creaturesX - foodX);
                int distanceY = Math.Abs(creaturesY - foodY);
                int finaldistance = (distanceX + distanceY) / count;
                return finaldistance;
            }
        }

        class Distance
        {
            public int value { get; set; }
            public int distance { get; set; }
        }

        static List<Population> populations = new List<Population>();
        static List<int> perspectivePopulations = new List<int>();
        static List<int> nonPerspectivePopulations = new List<int>();
        static List<Distance> shortdistancePopulations = new List<Distance>();
        static List<Distance> longDistancePopulations = new List<Distance>();

        static void GetPerspectivePopulations()
        {
            int populationsPerspective;
            for (int i = 0; i < populations.Count; i++)
            {
                populationsPerspective = populations[i].GetPerspect();
                if (populationsPerspective == 2)
                {
                    perspectivePopulations.Add(i);
                }
                else if (populationsPerspective == 0)
                {
                    nonPerspectivePopulations.Add(i);
                }
            }

        }

        static void GetDistances()
        {
            int getDistance;
            for (int i = 0; i < populations.Count; i++)
            {
                getDistance = populations[i].GetDistance();
                Distance newObject = new Distance();
                newObject.value = i;
                newObject.distance = getDistance;
                shortdistancePopulations.Add(newObject);
            }
            shortdistancePopulations = shortdistancePopulations.OrderBy(si => si.distance).ToList();
            longDistancePopulations.AddRange(shortdistancePopulations);
            longDistancePopulations.Reverse();
        }

        static void PrintOutput(int kMax, int kMin)
        {
            for (int i = 0; i < kMax; i++)
            {
                if (perspectivePopulations.Count > 0)
                {
                    Console.Write("{0} ", perspectivePopulations[0]); 
                    perspectivePopulations.RemoveAt(0);
                }
                else
                {
                    Console.Write("{0} ", shortdistancePopulations[0].distance);
                    shortdistancePopulations.RemoveAt(0);
                }
            }
            Console.WriteLine();
            for (int i = 0; i < kMin; i++)
            {
                if (nonPerspectivePopulations.Count > 0)
                {
                    Console.Write("{0} ", nonPerspectivePopulations[0]);
                    nonPerspectivePopulations.RemoveAt(0);
                }
                else
                {
                    Console.Write("{0} ", longDistancePopulations[0].distance);
                    longDistancePopulations.RemoveAt(0);
                }
            }
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split(' ');
            int n = int.Parse(input[0]);
            int kMin = int.Parse(input[1]);
            int kMax = int.Parse(input[2]);

            for (int i = 0; i < n; i++)
            {
                string[] populationSize = Console.ReadLine().Split(' ');
                int rows = int.Parse(populationSize[0]);
                int columns = int.Parse(populationSize[1]);
                Population currentPopulation = new Population(rows, columns);
                for (int row = 0; row < rows; row++)
			    {
			         string[] populationValues = Console.ReadLine().Split(' ');
                    for (int coll = 0; coll < columns; coll++)
			        {
                        currentPopulation.charArray[row, coll] = populationValues[coll];
			        }
			    }
                populations.Add(currentPopulation);
            }
            //GetPerspectivePopulations();
            GetDistances();
            PrintOutput(kMax, kMin);
        }
    }
}
