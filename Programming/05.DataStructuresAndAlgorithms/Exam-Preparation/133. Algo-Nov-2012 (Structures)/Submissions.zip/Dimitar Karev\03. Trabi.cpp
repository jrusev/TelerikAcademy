//
#include<iostream>
#include<vector>
#include<algorithm>
#include<set>
using namespace std;
unsigned long long n,m,a[20030];
bool binary(unsigned long long int k)
{
    unsigned long long int s=0;
    for(int i=0;i<n;i++)
    {
        s=s+a[i]/k;
    }
    if(s>=m){return 0;}
    else{return 1;}
}
int main()
{
    cin>>n>>m;
    unsigned long long sum=0;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
        sum=sum+a[i];
    }
    unsigned long long int mid=0,right=sum,left=0;
    bool ans=0;
    while(right!=(left+1))
    {
        mid=(left+right)/2;
        ans=binary(mid);
        if(ans==0){left=mid;}
        else{right=mid;}
    }
    cout<<left<<endl;    
    return 0;
}