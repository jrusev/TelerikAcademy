#include <cstdio>
#include <algorithm>
#include <math.h>
using namespace std;
struct triangle{
    int x[3];
    int y[3];
};
int n,tekbr;
bool bol=true;
triangle t[200200];
bool cmp(triangle a,triangle b){
    int ka[3],kb[3];
    for (int i=0;i<3;++i){
        ka[i]=abs(a.x[i]-a.y[i]);
        kb[i]=abs(b.x[i]-b.y[i]);
    }
    //
    if (ka[0]==kb[0]){
        if (ka[1]==kb[1]){return ka[2]<kb[2];}
        return ka[1]<kb[1];
    }
    return ka[0]<kb[0];
}
float S(int ind){
    /*triangle a;
    for (int i=0;i<3;++i){
        a.x[i]=t[ind].x[i];
    }*/
    return abs((t[ind].x[0]*t[ind].y[1]+t[ind].x[2]*t[ind].y[0]+t[ind].x[1]*t[ind].y[2])-(t[ind].x[2]*t[ind].y[1]+t[ind].x[0]*t[ind].y[2]+t[ind].x[1]*t[ind].y[0]))/2.0;
}
int main(){
    scanf("%d",&n);
    for (int i=0;i<n;++i){
        for (int j=0;j<3;++j){scanf("%d%d",&t[i].x[j],&t[i].y[j]);}
    }
    sort (t,t+n,cmp);
    tekbr=1;
    for (int i=1;i<n;++i){
        //printf("%d %d %d %d %d %d\n",t[i].x[0],t[i].y[0],t[i].x[1],t[i].y[1],t[i].x[2],t[i].y[2]);
        if (abs(t[i].x[0]-t[i].y[0])==abs(t[i-1].x[0]-t[i-1].y[0])&&abs(t[i].x[1]-t[i].y[1])==abs(t[i-1].x[1]-t[i-1].y[1])&&abs(t[i].x[2]-t[i].y[2])==abs(t[i-1].x[2]-t[i-1].y[2])){
            ++tekbr;//printf("a");
        }else{
            if (tekbr%2==1){bol=false;printf("%f\n",S(i-1));break;}
            else {tekbr=1;}
        }
    }
    if (bol){
        if (tekbr%2==1){printf("%f\n",S(n-1));}
        else {tekbr=1;}
    }
    return 0;
}
