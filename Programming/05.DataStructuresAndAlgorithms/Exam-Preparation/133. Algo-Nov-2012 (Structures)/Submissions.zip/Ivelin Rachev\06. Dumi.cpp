#include<iostream>
#include<string>
using namespace std;
int main()
{
  int t;
  cin>>t;
  string a,s,work;
  string words[10020];
  int ans[10020];
  for(int i=0;i<t;i++)
    getline(cin,s);
    a+=s;
  int w;
  cin>>w;
  for(int k=0;k<w;k++)
    {
      cin>>words[k];
      work=a;
      while(work.find(words[k])!=string::npos)
      {
        ans[k]++;
        work.erase(work.find(words[k]),words[k].size());
      }
    }
  for(int i=0;i<w;i++)
    {
      cout<<words[i]<<" -> "<<ans[i]<<endl;
    }
    return 0;
}