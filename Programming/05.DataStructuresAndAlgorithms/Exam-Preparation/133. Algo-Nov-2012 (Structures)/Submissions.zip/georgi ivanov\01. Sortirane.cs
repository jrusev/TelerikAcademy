using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace AlgoCompetitionNov2012
{
    class Sorting
    {
        static uint x, n;
        static void Main(string[] args)
        {
            string inputStr = Console.ReadLine();
            string[] numbersStr = new string[2];
            numbersStr = Regex.Split(inputStr, " ");

            
            n = Convert.ToUInt32(numbersStr[0]);
            x = Convert.ToUInt32(numbersStr[1]);

            inputStr = Console.ReadLine();
            numbersStr = new string[n];
            numbersStr = Regex.Split(inputStr, " ");

            uint[] numbers = new uint[n];

            for (uint i = 0; i < numbersStr.LongLength; i++)
            {
                numbers[i] = Convert.ToUInt32(numbersStr[i]);
            }
            quickSort q = new quickSort(numbers, n, x);
            //q.sort(numbers[0], numbers[n - 1]);


            foreach (var item in numbers)
            {
                Console.WriteLine(item);
            }

            //for (uint i = 0; i < n; i++)
            //{
                
            //}

        }
    }

    class quickSort
    {
        // this is our array to sort
        uint[] arr; //= new uint[n];

        // this holds a number of elements in array
        private uint len;
        private uint x;
        // Quick Sort Algorithm
        public quickSort(uint[] numbers ,uint n, uint x)
        {
            this.x = x;
            len = n;
            this.arr = numbers;
            sort(0, len - 1);
        }

        public void sort(uint left, uint right)
        {
            uint pivot, l_holder, r_holder;

            l_holder = left;
            r_holder = right;
            pivot = arr[left];

            while (arr[left] % arr[right] > x)
            {
                while ((arr[right] >= pivot) && (left < right))
                {
                    right--;
                }

                if (left != right)
                {
                    arr[left] = arr[right];
                    left++;
                }

                while ((arr[left] <= pivot) && (left < right))
                {
                    left++;
                }

                if (left != right)
                {
                    arr[right] = arr[left];
                    right--;
                }
            }

            arr[left] = pivot;
            pivot = left;
            left = l_holder;
            right = r_holder;

            if (left < pivot)
            {
                sort(left, pivot - 1);
            }

            if (right > pivot)
            {
                sort(pivot + 1, right);
            }
        }
    }
}
