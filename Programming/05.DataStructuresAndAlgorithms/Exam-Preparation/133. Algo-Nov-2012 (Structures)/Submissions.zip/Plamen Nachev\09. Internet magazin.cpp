#include <iostream>
#include <cstdio>
#include <string.h>
#include <cstdlib>
#include <algorithm>
using namespace std;

int N;

struct list
{ 
  string name, brand;
  
  double price;
  bool deleted;
};
list l[100050], l1[100050];
int br;

/*
void print()
{ 
  cout << "br= " << br << endl;
  
  for( int i = 0; i < br; i++ )
  cout << "{" << l[i].name << ";" << l[i].brand << ";" << l[i].price << "}\n";
}*/


void add_product( string S )
{ 
  int len = S.length();
  int i = 0;
  l[br].deleted = 0;
  
  l[br].name[0] = S[0];
  i = 1;
  
  while( S[i] != ';' && i < len )
  { 
    l[br].name += S[i];
    i++;
   }
  //cout << l[br].name << "fdfeffdfdfdfdd" << endl;
  i++;
  l[br].price = 0.0;
  while( S[i] != ';' && S[i] != '.' && i < len )
  { 
    l[br].price = l[br].price*10 + (double)(S[i]-'0');
    i++;
   }
  
  if( S[i] == '.' )
  { 
    i++;
    double r = 0.0;
    while( S[i] != ';' && i < len )
    { 
      r = r*10 + (double)(S[i]-'0');
      i++;
     }
    if( r - 9.0 < 0.000000001 )  r *= 10.0;
    l[br].price += r/100.0;
   }
  
  l[br].brand[0] = S[0];
  i++;
  while( i < len )
  { 
    l[br].brand += S[i];
    i++;
   }
  
  //cout << "yeeeees" << endl;
  //cout << "{" << l[0].name << ";" << l[0].brand << ";" << l[0].price << "}\n";
  
  br++;
}


bool sort1( list a, list b )
{ 
  return a.name < b.name;
}


void FindProductsByName( string S )
{ 
  //cout << "S= " << S << endl;
  //cout << "br= " << br << endl;
  
  int br1 = 0;
  for( int i = 0; i < br; i++ )
  { 
    //cout << l[i].name << endl;
    if( l[i].name == S && !l[i].deleted )  { l1[br1] = l[i]; br1++; }
   }
  
  
  if( br1 == 0 )  printf("No products found\n");
  else
  { 
    sort(l1, l1+br1, sort1);
    
    for( int i = 0; i < br1; i++ ) 
    //printf("{%s;%s;%.2lf}\n", l1[i].name, l1[i].brand, l1[i].price);
    cout << "{" << l1[i].name << ";" << l1[i].brand << ";" << l1[i].price << "}\n";
   }
}


/*
2
AddProduct IdeaPad Z560;1536.50;Lenovo
FindProductsByProducer Lenovo
*/

void FindProductsByProducer( string S )
{ 
  //cout << "fnfjrnfevnjenfes;krbgfjk    " << S << endl;
  int br1 = 0;
  //cout << "br= " << br << endl;
  //cout << "print... " << endl;
  //print();
  for( int i = 0; i < br; i++ )
  { 
    //if( l[i].brand == "Lenovo" )  cout << l[i].brand  << "   yeyeeyeye" << endl;
    if( l[i].brand == S && !l[i].deleted )  { l1[br1] = l[i]; br1++; /*cout << "azzzzzzzz" << endl;*/ }
   }
  
  //cout << l[0].brand << " " << S << endl;
  //cout << l[0].brand.size() << " " << S.size() << endl;
  if( br1 == 0 )  printf("No products found\n");
  else
  { 
    sort(l1, l1+br1, sort1);
    
    for( int i = 0; i < br1; i++ )
    //printf("{%s;%s;%.2lf}\n", l1[i].name, l1[i].brand, l1[i].price);
    cout << "{" << l1[i].name << ";" << l1[i].brand << ";" << l1[i].price << "}\n";
   }
}


void FindProductsByPriceRange( string S )
{ 
  double p1 = 0.0, p2 = 0.0;
  
  int len = S.length();
  
  int i = 0;
  while( S[i] != '.' && S[i] != ';' && i < len )
  { 
    p1 = p1*10 + (double)(S[i]-'0');
    i++;
   }
  
  if( S[i] == '.' )
  { 
    i++;
    double r = 0.0;
    while( S[i] != ';' && i < len )
    { 
      r = r*10 + (double)(S[i]-'0');
      i++;
     }
    if( r - 9.0 < 0.000000001 )  r *= 10.0;
    p1 += r/100.0;
   }
  
  i++;
  while( S[i] != '.' && i < len )
  { 
    p2 = p2*10 + (double)(S[i]-'0');
    i++;
   }
  
  if( S[i] == '.' )
  { 
    i++;
    double r = 0.0;
    while( i < len )
    { 
      r = r*10 + (double)(S[i]-'0');
      i++;
     }
    if( r - 9.0 < 0.000000001 )  r *= 10.0;
    p2 += r/100.0;
   }
  
  
  int br1 = 0;
  for( i = 0; i < br; i++ )
  if( p1 - l[i].price < 0.000000001 && l[i].price - p2 < 0.000000001 && !l[i].deleted )  l1[br1++] = l[i];
  
  if( br1 == 0 )  printf("No products found\n");
  else
  { 
    sort(l1, l1+br1, sort1);
    
    for( int i = 0; i < br1; i++ ) 
    cout << "{" << l1[i].name << ";" << l1[i].brand << ";" << l1[i].price << "}\n";
    //printf("{%s;%s;%.2lf}\n", l1[i].name, l1[i].brand, l1[i].price);
   }
}


void DeleteProductsByNameOrProducer( string S )
{ 
  string name1 = "", brand1 = "";
  
  int len = S.length();
  int f = S.find(";");
  
  name1 = S.substr(0, f+1);
  brand1 = S.substr(f, len-f);
  
  int br1 = 0;
  for( int i = 0; i < br; i++ )
  if( l[i].name == name1 || l[i].brand == brand1 )  { br1++; l[i].deleted = 1; }
  
  if( br1 == 0 )  printf("No products found\n");
  else            printf("%d products deleted\n", br1);
}


void DeleteProductsByProducer( string S)
{ 
  /*cout << endl;
  cout << "S= " << S << endl;
  cout << endl;
  
  print();*/
  
  int br1 = 0;
  for( int i = 0; i < br; i++ )
  if( l[i].brand == S && !l[i].deleted )  { br1++; l[i].deleted = 1; }
  
  if( br1 == 0 )  printf("No products found\n");
  else            printf("%d products deleted", br1);
}


int main()
{ 
  scanf("%d", &N);
  
  char com[31];
  
  string S;
  char c1;
  
  for( int i = 0; i < N; i++ )
  { 
    scanf("%s", &com);
    
    if( !strcmp(com, "AddProduct") )
    { 
      getline(cin, S, '\n');
      //S.erase(0, 1);
      add_product(S);
      printf("Product added\n");
      //print();
     }
    
    else if( !strcmp(com, "FindProductsByName") )
    { 
      getline(cin, S, '\n');
      S.erase(0, 1);
      FindProductsByName(S);
     }
    
    else if( !strcmp(com, "FindProductsByProducer") )
    { 
      getline(cin, S, '\n');
      S.erase(0, 1);
      FindProductsByProducer(S);
     }
    
    else if( !strcmp(com, "FindProductsByPriceRange" ) )
    { 
      getline(cin, S, '\n');
      S.erase(0, 1);
      FindProductsByPriceRange(S);
     }
     
    else if( !strcmp(com, "DeleteProducts") )
    { 
      getline(cin, S, '\n');
      S.erase(0, 1);
      if( S.find(";") != string::npos )  DeleteProductsByNameOrProducer(S);
      else                               DeleteProductsByProducer(S);
     }
   }
  
  //scanf("%d", &N);
  return 0;
}
/*
14
AddProduct IdeaPad Z560;1536.50;Lenovo
AddProduct ThinkPad T410;3000;Lenovo
AddProduct VAIO Z13;4099.99;Sony
AddProduct CLS 63 AMG;200000;Mercedes
FindProductsByName CLS 63 AMG
FindProductsByName CLS 63
FindProductsByName cls 63 amg
AddProduct 320i;10000;BMW
FindProductsByName 320i
AddProduct G560;999;Lenovo
FindProductsByProducer Lenovo
DeleteProducts Lenovo
FindProductsByProducer Lenovo
FindProductsByPriceRange 100000;200000

*/
