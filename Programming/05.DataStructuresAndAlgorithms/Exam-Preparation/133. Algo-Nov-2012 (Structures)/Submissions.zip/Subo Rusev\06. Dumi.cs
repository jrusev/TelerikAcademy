using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Words
{

    private static char[] ExtractSeparators(string text)
    {
        List<char> separators = new List<char>();
        foreach (char character in text)
        {
            if (!char.IsLetter(character))
            {
                separators.Add(character);
            }
        }
        return separators.ToArray();
    }

    private static string[] ExtractWords(string text)
    {
        char[] separators = ExtractSeparators(text);
        List<string> extractedWords = new List<string>();
        foreach (string extractedWord in text.Split(separators))
        {
            if (!string.IsNullOrEmpty(extractedWord))
            {
                extractedWords.Add(extractedWord);
            }
        }
        return extractedWords.ToArray();
    }

    private static List<string> findAllWordsWithSymbols(string wordToCheck, List<string[]> allWords)
    {
      //  int count = 0;
        List<string> wordsContainingSymbols = new List<string>();
        foreach (string[] line in allWords)
        {
            //bool unique = true;
            for (int i = 0; i < line.Length; i++)
            {
                if (checkContainsSymbols(wordToCheck, line[i]))
                {
                    wordsContainingSymbols.Add(line[i]);
                }
            }
        }
        return wordsContainingSymbols;
    }

    private static bool checkContainsSymbols(string wordToCheck, string wordFromText)
    {
        foreach (char c in wordToCheck)
        {
            //string chLow = c.ToString().ToLower();
            //chLow.ToCharArray();                IGNORE CASE!!!
            if (wordFromText.IndexOf(c.ToString(), 0, StringComparison.CurrentCultureIgnoreCase) == -1) 
            {
                return false;
            }
        }
        return true;
    }
    private static int findCount(List<string> wordsWithSymbols)
    {
        int count = 0;
        var unique_items = new HashSet<string>(wordsWithSymbols);
        foreach (string s in unique_items)
        {
            count++;
        }
        return count;
    }

   


    static void Main(string[] args)
    {
        ushort numberLines = ushort.Parse(Console.ReadLine());

        string[] lines = new string[numberLines];

        List<string[]> allWords = new List<string[]>();

        for (int i = 0; i < numberLines; i++)
        {
            lines[i] = Console.ReadLine(); //lines[i]->string
            allWords.Add(ExtractWords(lines[i])); // a list from string arrays per lines 
            //extract words - takes a string and returns an array of strings    
        }
        

        ushort numberWords = ushort.Parse(Console.ReadLine());
        string[] inputWords = new string[numberWords];
        for (int i = 0; i < numberWords; i++)
        {
            inputWords[i] = Console.ReadLine();
        }

        List<string> wordsWithSymbols = new List<string>();

        for (int i = 0; i < numberWords; i++)
        {
           int count = 0;
            wordsWithSymbols = findAllWordsWithSymbols(inputWords[i], allWords);
            count = findCount(wordsWithSymbols);
            Console.WriteLine("{0} -> {1}", inputWords[i], count);
        }
        //List<string>asd = new List<string>();
        //asd.Add("asd");
        //asd.Add("asd"); asd.Add("asd"); asd.Add("asd"); asd.Add("asdasdasd");

        //Console.WriteLine( findCount(asd));
    }
}

