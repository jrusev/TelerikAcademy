using System;
using System.Collections.Generic;

class Jeday
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] input = Console.ReadLine().Split(' ');
            List<string> list1 = new List<string>();
            List<string> list2 = new List<string>();
            List<string> list3 = new List<string>();
            //string[] output = new string[n];
            string character = "";

            for (int i = 0; i < n; i++)
            {
                character = input[i].Substring(0, 1);
                if (character == "m")
                {
                    list1.Add(input[i]);
                }
                if (character == "k")
                {
                    list2.Add(input[i]);
                }
                if (character == "p")
                {
                    list3.Add(input[i]);
                }
            }
            list1.AddRange(list2);
            list1.AddRange(list3);
            for (int i = 0; i < n; i++)
            {
                Console.Write("{0} ", list1[i]);
            }

            Console.WriteLine();
        }
    }
