#include <iostream>
#include <string>
#include <map>
#include <cstdio>
#include <cstring>
using namespace std;

string s[8000000];
string w[1024];
map<string,bool> us[1024];
bool check(string a, string b)
{
     int n=a.size();
     int m=b.size();
     bool ok;
     for(int i=0; i<n; i++)
     {
             ok=false;
             for(int j=0; j<m; j++)
             if(tolower(a[i])==b[j]) { ok=true; break; }
             if(!ok) return false;
     }
     //cout << a << ' ' << b << endl;
     return true;
}

string format(string a)
{
     string res="";
     int n=a.size();
     for(int i=0; i<n; i++)
     {
             if(a[i]<'A' || (a[i]>'Z' && a[i]<'a') || a[i]>'z') continue;
             a[i]=tolower(a[i]); 
             res+=a[i];
     }
     return res;
}
       
int main()
{
    int n;
    cin >> n;
    
    int j=0;
    int k=0;
    char c;
    do
    {
        cin >> s[j];
        s[j]=format(s[j]);
        j++;
        scanf("%c", &c);
         if(c=='\n') k++;
         if(k==n) break;
    }
    while(1);
    
    
    //cout << "----------------------fine------------------\n";
    //for(int i=0; i<j; i++) cout << s[i] << endl;
    
    int m;
    cin >> m;
    
    for(int i=0; i<m; i++) cin >> w[i];
    
    int res;
    for(int i=0; i<m; i++)
    {
            res=0;
            for(int z=0; z<j; z++)
            {
                    if(us[i][s[z]]==0){
                                    res+=check(w[i],s[z]);
                                    //cout << w[i] << ' ' << s[z] << ' ' << res << endl;
                                    }
                    us[i][s[z]]=1;
            }
            
            cout << w[i] << " -> " << res << endl;
    }
    
    return 0;
}
    
