#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
long long i,n,m,a[20001];
void binary (long long n1,long long k1) {
 long long c,s=0;
 c=(n1+k1)/2;
 for(i=1;i<=n;i++) {
  s=s+(a[i]/c);
 }
 if(n1+1==k1) {
  cout<<c<<endl;
 }
 else {
 if(s<m) {
 
  binary(n1,c);
 }
 if(s>=m) {
 
  binary(c,k1);
 }
 }
 
}
int main () {
  cin>>n>>m;
  for(i=1;i<=n;i++) {
   cin>>a[i];
  }
  sort(a+1,a+1+n);
  binary(1,a[n]);
 
  return 0;
}