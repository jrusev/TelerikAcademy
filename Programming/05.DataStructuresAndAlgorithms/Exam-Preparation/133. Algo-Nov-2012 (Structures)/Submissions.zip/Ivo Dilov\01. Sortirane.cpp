#include <cstdio>
#include <algorithm>
using namespace std;
int n,k;
unsigned long long nums[100200];
bool cmp(unsigned long long a,unsigned long long b){
    if (a%k==b%k){return a<b;}
    return a%k<b%k;
}
int main(){
    scanf("%d%d",&n,&k);
    for (int i=0;i<n;++i){
        scanf("%llu",&nums[i]);
    }
    sort(nums,nums+n,cmp);
    for (int i=0;i<n;++i){
        printf("%llu ",nums[i]);
    }
    printf("\n");
    return 0;
}
