using System;

class Metro
{
    static void Main()
    {
        Console.WriteLine("OK");
    }
}
