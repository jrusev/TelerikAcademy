#include <iostream>
#include <vector>
using namespace std;
int main() {
vector<string> m,k,p ;
int n;
cin>>n;
string current ;
for(int i=0;i<n;i++){
    cin>>current ;
    if(current[0]=='m'){ m.push_back(current) ;}
    if(current[0]=='k'){ k.push_back(current) ;}
    if(current[0]=='p'){ p.push_back(current) ;}
    //cout<<"read"<<endl;
}
int msize=m.size() ;
int ksize=k.size() ;
int psize=p.size() ;
for(int i=0;i<msize;i++){cout<<m[i]<<" " ; }
for(int i=0;i<ksize;i++){cout<<k[i]<<" " ; }
for(int i=0;i<psize-1;i++){cout<<p[i]<<" " ; }
cout<<p[psize-1]<<endl;
return 0;
}
/*
7
p4 p2 p3 m1 k2 p1 k1
*/