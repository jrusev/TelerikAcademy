using System;
using System.Collections;


class Sorting
{
    static void Main()
    {
        string input = Console.ReadLine();
        string[] inputDigits = input.Split(' ');

        uint n = uint.Parse(inputDigits[0]);
        uint remainder = uint.Parse(inputDigits[1]);


        uint[] arr = new uint[n];

        input = Console.ReadLine();
        inputDigits = input.Split(' ');
        for (int i = 0; i < n; i++)
        {
            arr[i] = uint.Parse(inputDigits[i]);
        }

        Array.Sort(arr, ((a, b) => (a % remainder).CompareTo(b % remainder)));
        for (int i = 0; i < n; i++)
        {
            Console.Write(arr[i] + " ");
        }
    }
}