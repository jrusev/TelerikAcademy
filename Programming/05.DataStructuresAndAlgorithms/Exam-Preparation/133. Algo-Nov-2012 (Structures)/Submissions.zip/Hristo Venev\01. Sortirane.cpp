#include <iostream>
#include <algorithm>
#include <vector>
unsigned k;
bool fuckYou(unsigned a, unsigned b){
    if(a%k<b%k) return 1;
    if(a%k>b%k) return 0;
    return a<b;
}
int main(){
    std::ios::sync_with_stdio(false);
    std::vector<unsigned> x;
    size_t n;
    std::cin>>n>>k;
    x.resize(n);
    for(size_t fuckTelerik=0;fuckTelerik<n;fuckTelerik++){
        std::cin>>x[fuckTelerik];
    }
    std::sort(x.begin(), x.end(), fuckYou);
    bool sp=1;
    for(size_t fuckTelerik=0;fuckTelerik<n;fuckTelerik++){
        if(!sp) std::cout<<' ';
        std::cout<<x[fuckTelerik];
        sp=0;
    }
    std::cout<<'\n';
    return 0;
}
