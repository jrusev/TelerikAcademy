#include<cstring>
#include<iostream>
using namespace std;
string a[100001];
int main()
{int n,i,j;
bool fl=0;
    cin>>n;
for(i=0;i<n;i++)
cin>>a[i];



for(j=0;j<n;j++)
{


for(i=0;i<n;i++)
{if(a[i][0]=='m') {cout<<a[i]<<" ";a[i][0]=0;fl=1;}

}
if(!fl) break;
}

for(j=0;j<n;j++)
{

for(i=0;i<n;i++)
{if(a[i][0]=='k') {cout<<a[i]<<" ";a[i][0]=0;fl=1;}

}
if(!fl) break;
}

for(j=0;j<n;j++)
{


for(i=0;i<n;i++)
{if(a[i][0]=='p') {cout<<a[i]<<" ";a[i][0]=0;fl=1;}

}
if(!fl) break;
}
cout<<endl;
return 0;

}
