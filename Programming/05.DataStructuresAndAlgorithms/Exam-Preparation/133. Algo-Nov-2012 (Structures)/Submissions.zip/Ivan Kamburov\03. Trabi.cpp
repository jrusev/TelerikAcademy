#include <stdio.h>

using namespace std;

int n;
unsigned int m, pipes[20000];
unsigned long long right = 0, left = 0, max = 0;

void BinSearch()
{
    unsigned long long middle = (left + right) / 2;
    unsigned int sum = 0;

    if (middle == max) return;

    for (int i = 0; i < n; i++) sum += (unsigned int)(pipes[i] / middle);
    if (sum > m)
    {
        max = middle;
        left = middle;
        BinSearch();
    }
    else if (sum == m)
    {
        if (middle > max) max = middle;
        left = middle;
        BinSearch();
    }
    else
    {
        right = middle;
        BinSearch();
    }

}

int main()
{
    scanf("%d%u", &n, &m);
    for (int i = 0; i < n; i++)
    {
        scanf("%u", &pipes[i]);
        right += pipes[i];
    }

    BinSearch();

    printf("%u\n", max);

    return 0;
}
