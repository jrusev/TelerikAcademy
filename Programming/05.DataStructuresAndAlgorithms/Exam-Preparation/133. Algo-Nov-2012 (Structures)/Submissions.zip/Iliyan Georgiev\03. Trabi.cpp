#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>
using namespace std;
int main()
{
	int n,m,k,r=0;
	long long sum=0LL,max;
	vector<int> vec;
	scanf("%d%d",&n,&m);
	for( int i = 0; i < n; i++ )
	{
		scanf("%d",&k);
		vec.push_back(k);
		sum+=k;
	}
	max=sum/m;
	if( max == 0LL )
	{
		printf("-1");
		return 0;
	}
	while(r!=m)
	{
        r=0;
		for( int i = 0; i < vec.size(); i++ )
		 r+=vec[i]/max;
		max--;
	}
	printf("%lld",max+1);
	return 0;
}
