#include <iostream>
#include <map>
#include <vector>
#include <sstream>
#include <iomanip>
#include <algorithm>
#pragma GCC optimize("-Ofast")
struct Product;
struct StringPtrComparator{
    bool operator()(const std::string *a, const std::string *b){
        return *a<*b;
    }
};
typedef std::multimap<const std::string*, Product*, StringPtrComparator> stringMap;
typedef std::multimap<const std::string, Product*> stringMapV;
typedef std::multimap<double, Product*> doubleMap;
struct Product{
    std::string name, producer;
    double price;
    stringMap::iterator nameI, producerI;
    doubleMap::iterator priceI;
    stringMapV::iterator bothI;
};
stringMap byName, byProducer;
doubleMap byPrice;
stringMapV byBoth;
std::vector<Product*> chunks;
size_t prLeft;
Product *newProduct(){
    if(prLeft==0){
        chunks.push_back(new Product[1<<20]);
        prLeft=1<<12;
        return chunks.back()+--prLeft;
    }else{
        return chunks.back()+--prLeft;
    }
}
void addProduct(const std::string &name, double price, const std::string &prod){
    Product *p=newProduct();
    p->name=name;
    p->price=price;
    p->producer=prod;
    p->priceI=byPrice.insert(std::make_pair(p->price, p));
    p->nameI=byName.insert(std::make_pair(&p->name, p));
    p->producerI=byProducer.insert(std::make_pair(&p->producer, p));
    p->bothI=byBoth.insert(std::make_pair(p->name+';'+p->producer, p));
    std::cout<<"Product added\n";
    return; 
}
void deleteProduct(Product *p){
    byName.erase(p->nameI);
    byProducer.erase(p->producerI);
    byPrice.erase(p->priceI);
    byBoth.erase(p->bothI);
    return;
}
void deleteProducts(const std::string &prod){
    std::pair<stringMap::iterator, stringMap::iterator> i=byProducer.equal_range(&prod);
    size_t cnt=0;
    while(i.first!=i.second){
        deleteProduct(i.first++->second);
        cnt++;
    }
    if(cnt==0) std::cout<<"No products found\n";
    else std::cout<<cnt<<" products deleted\n";
    return;
}
void deleteProducts(std::string name, const std::string &prod){
    name+=';'+prod;
    std::pair<stringMapV::iterator, stringMapV::iterator> i=byBoth.equal_range(name);
    size_t cnt=0;
    while(i.first!=i.second){
        deleteProduct(i.first++->second);
        cnt++;
    }
    if(cnt==0) std::cout<<"No products found\n";
    else std::cout<<cnt<<" products deleted\n";
    return;
}
std::vector<std::string> printed;
void print(Product *p){
    std::ostringstream s;
    s<<'{'<<p->name<<';'<<p->producer<<';'<<std::setprecision(2)<<std::fixed<<p->price<<'}';
    printed.push_back(s.str());
    return;
}
void doPrint(){
    std::sort(printed.begin(), printed.end());
    for(size_t i=0;i<printed.size();i++){
        std::cout<<printed[i]<<'\n';
    }
    printed.clear();
    return;
}
void findProductsByPriceRange(double min, double max){
    doubleMap::iterator begin=byPrice.lower_bound(min);
    doubleMap::iterator end=byPrice.upper_bound(max);
    if(begin==end) std::cout<<"No products found\n";
    while(begin!=end){
        print(begin->second);
        begin++;
    }
    doPrint();
    return;
}
void findProductsByProducer(const std::string &prod){
    std::pair<stringMap::iterator, stringMap::iterator> i=byProducer.equal_range(&prod);
    if(i.first==i.second) std::cout<<"No products found\n";
    while(i.first!=i.second){
        print(i.first->second);
        i.first++;
    }
    doPrint();
    return;
}
void findProductsByName(const std::string &name){
    std::pair<stringMap::iterator, stringMap::iterator> i=byName.equal_range(&name);
    if(i.first==i.second) std::cout<<"No products found\n";
    while(i.first!=i.second){
        print(i.first->second);
        i.first++;
    }
    doPrint();
    return;
}
bool readTilSep(std::string &str){
    char ch;
    ch=std::cin.get();
    while(ch!=';'&&ch!='\n'){
        str+=ch;
        ch=std::cin.get();
    }
    return ch==';';
}
char coutbuf[1<<20];
char cinbuf[1<<20];
int main(){
    size_t N;
    std::ios::sync_with_stdio(0);
    std::cin.tie(0);
    std::cout.rdbuf()->pubsetbuf(coutbuf, 1<<20);
    std::cin.rdbuf()->pubsetbuf(cinbuf, 1<<20);
    std::cin>>N;
    while(N--){
        std::string command;
        std::cin>>command;
        std::cin.get(); //whitespace
        if(command=="AddProduct"){
            std::string name, producer;
            double price;
            readTilSep(name);
            std::cin>>price;
            std::cin.get();
            readTilSep(producer);
            addProduct(name, price, producer);
        }else if(command=="DeleteProducts"){
            std::string name, producer;
            if(readTilSep(name)){
                readTilSep(producer);
                deleteProducts(name, producer);
            }else{
                deleteProducts(name); //by producer
            }
        }else if(command=="FindProductsByName"){
            std::string name;
            readTilSep(name);
            findProductsByName(name);
        }else if(command=="FindProductsByProducer"){
            std::string prod;
            readTilSep(prod);
            findProductsByProducer(prod);
        }else if(command=="FindProductsByPriceRange"){
            double min, max;
            std::cin>>min;
            std::cin.get();
            std::cin>>max;
            findProductsByPriceRange(min, max);
        }
    }
    return 0;
}