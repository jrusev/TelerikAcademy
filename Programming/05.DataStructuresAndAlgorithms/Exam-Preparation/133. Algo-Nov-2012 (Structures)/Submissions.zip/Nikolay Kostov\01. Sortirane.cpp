#include <iostream>
#include <algorithm>
#define uint unsigned int
#define MAXN 100002
using namespace std; uint n, k;uint nums[MAXN];bool sortFunction (uint i, uint j){    if (i % k < j % k) return true;    if (i % k > j % k) return false;    if (i < j) returntrue;    if (i > j) return false;    return false;}int main(){    cin >> n >> k;    for(int i = 0; i < n; i++)    {        cin >> nums[i];    }    sort(nums, nums + n,sortFunction);    for(int i = 0; i < n; i++)    {        if (i == n - 1) cout << nums[i] << endl;        else cout << nums[i] << " ";    }    return 0;}
