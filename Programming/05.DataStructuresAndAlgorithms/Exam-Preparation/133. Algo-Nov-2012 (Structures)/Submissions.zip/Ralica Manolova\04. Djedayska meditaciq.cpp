#include<iostream>
using namespace std;
struct dj
{
  char b;
  int ch;
};
int main ()
{
dj a[100001];
int n,help=0;
cin>>n;
for (int i=0; i<n; i++)
{
  cin>>a[i].b>>a[i].ch;
}

for (int i=0; i<n; i++)
{
  if (a[i].b=='m')
  {
    if (help==0) {cout<<a[i].b<<a[i].ch;}
    else {cout<<" "<<a[i].b<<a[i].ch;}
    help++;
  }
}
for (int i=0; i<n; i++)
{
  if (a[i].b=='k')
  {
    if (help==0) {cout<<a[i].b<<a[i].ch;}
    else {cout<<" "<<a[i].b<<a[i].ch;}
    help++;
  }
}
for (int i=0; i<n; i++)
{
  if (a[i].b=='p')
  {
    if (help==0) {cout<<a[i].b<<a[i].ch;}
    else {cout<<" "<<a[i].b<<a[i].ch;}
    help++;
  }
}
 return 0;
}