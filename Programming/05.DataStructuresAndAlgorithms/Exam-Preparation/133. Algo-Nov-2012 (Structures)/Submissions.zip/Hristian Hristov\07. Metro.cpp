#include <iostream>
#include <string>
#include <cstring>
#include <windows.h>
#include <locale>
#include <cstdlib>
#define UNICODE
using namespace std;
int main()
{
    cout << "OK\n";
    return 0;
}
