#include<cstdio>
#include<set>
#include<utility>
#include<string.h>
#include<string>
#include<iostream>
#include<cstdlib>
//#include<exception>
using namespace std;
//void myexc() { printf("wfcwerfvsd"); }
 
struct classcomp
{
    bool operator() (const pair<unsigned long long, string>& lhs, const pair<unsigned long long, string>& rhs) const
    {
        if(lhs.first<rhs.first)return true;
        if(lhs.first==rhs.first)if(lhs.second<rhs.second)return true;
        return false;
    }
};
int main()
{
    //set_terminate(myexc);
    setvbuf(stdin, NULL, _IOFBF, 1<<20);
    setvbuf(stdout, NULL, _IOFBF, 1<<20);
    multiset<pair<unsigned long long, string>, classcomp> myset;
    unsigned long n;
    cin>>n;//scanf("%u", &n);
    string h, c;//char h[32], c[16];
    int j, k;
    getline(cin, h, '\n');//ignoring endter
    unsigned long long num;//try{
    for(unsigned long i(0); i<n; ++i)
    {
        getline(cin, h, '\n');
        if(h.substr(0, 3)=="New")
        {
            /*
            j=4;
            while(h[j]!=' '){ c[j-4]=h[j]; ++j; }
            c[j]='\0';
            num=atol(c);
            while(h[j]==' ')++j;
            k=j;
            while(h[j]!='\0'){ c[j-k]=h[j]; ++j; ++k; }
            c[k]='\0';
            */
            num=atol(h.substr(4).c_str());
            c=h.substr(h.find(' ', 5)+1);
            //cout<<"\""<<c<<"\""<<endl;
            myset.insert(pair<unsigned long long, string>(num, c));
        }
        if(h=="Solve")
        {
            if(myset.empty())printf("Rest\n");
            else
            {
                printf((*myset.begin()).second.c_str());
                printf("\n");
                myset.erase(myset.begin());
            }
        }
    } //}catch(exception &ex){printf(ex.what()); }
    return 0;
}