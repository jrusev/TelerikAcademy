#include<iostream>
#include<vector>
#include<algorithm>
#include<string>
using namespace std;
int main(){
	int N;
	cin>>N;
	string p,vm="",vk="",vp="";
	for(int i=0;i<N;i++){
		cin>>p;
		if(p[0]=='m'){
			vm+=p+" ";
		} else if(p[0]=='k'){
			vk+=p+" ";
		} else {
			vp+=p+" ";
		}
	}
	if (vm!=""){
		//cout<<vm[0];
		cout<<vm;
		}
	if (vk!=""){
		//cout<<vm[0];
		cout<<vk;
		}
	if (vp!=""){
		//cout<<vm[0];
		cout<<vp;
		}
	return 0;
}