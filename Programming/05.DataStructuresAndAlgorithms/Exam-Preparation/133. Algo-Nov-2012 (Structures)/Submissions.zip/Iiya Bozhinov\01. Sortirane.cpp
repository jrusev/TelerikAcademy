#include <iostream>
#include <map>
#include <set>
using namespace std;
typedef long long lng ;
int main() {
multimap<lng,lng> map = multimap<lng,lng>();
lng n, x;
cin>>n>>x;
lng xi;
for(lng i=0;i<n;i++){
   cin>>xi;
    map.insert(pair<lng,lng>(xi%x,xi)) ;
}//multimap<lng,lng>::iterator it ;
//for(it=map.begin();it!=map.end();it++)cout<<(*it).first<<"  "<<(*it).second<<"     " ;
//cout<<endl<<endl;;
for(multimap<lng,lng>::iterator i=map.begin();i!=map.end();i++){
    lng count=map.count((*i).first) ;
    //cout<<endl<<"count for "<<(*i).first<<"."<<(*i).second<<" : "<<count<<endl;;
    if(count>1){
        multiset<lng> set;
        multimap<lng,lng>::iterator it=map.lower_bound((*i).first) ;
        lng help=count ;
        while(help>0){
            set.insert((*it).second) ;help--;it++ ;
        }
        help=count ;
        multiset<lng>::iterator is=set.begin() ;
        while(help>0){cout<<*is<<" " ;is++;help--;}
        for(lng j=1;j<set.size();j++)i++ ;
    }
    else cout<<(*i).second<<" " ;
}
return 0;
}
