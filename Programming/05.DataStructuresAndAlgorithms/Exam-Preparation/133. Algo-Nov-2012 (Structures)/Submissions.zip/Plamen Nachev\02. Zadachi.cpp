#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;


int N;

struct list
{ 
  long long a;
  char S[7];
};
list p[50000];
int br;

void push_data( long long a1, char S1[7] )
{ 
  int i = 0;
  while( i < br && p[i].a < a1 )
  i++;
  
  if( i == br )
  { 
    p[br].a = a1;
    strcpy(p[br].S, S1);
    br++;
   }
  else if( p[i].a > a1)
  { 
    for( int j = br; j > i; j-- )
    p[j] = p[j-1];
    p[i].a = a1;
    strcpy(p[i].S, S1);
    br++;
   }
  else if( p[i].a == a1 )
  { 
    while( strcmp(S1, p[i].S) > 0 && i < br )
    i++;
    
    for( int j = br; j > i; j-- )
    p[j] = p[j-1];
    p[i].a = a1;
    strcpy(p[i].S, S1);
    br++;
   }
}


void solve()
{ 
  if( br == 0 )  printf("Rest\n");
  else
  { 
    printf("%s\n", p[0].S);
    
    for( int i = 0; i < br-1; i++ )
    p[i] = p[i+1];
    br--;
   }
}


int main()
{ 
  scanf("%d", &N);
  
  
  char com[10];
  long long a1;  char S1[10];
  
  for( int i = 0; i < N; i++ )
  { 
    scanf("\n%s", &com);
    //cin >> com;
    if( !strcmp(com, "New") )
    { 
      scanf("%I64d %s", &a1, &S1);
      //cin >> a1 >> S1;
      push_data(a1, S1);
     }
    else
    { 
      //for( int j = 0; j < br; j++ )
      //cout << p[j].a << " " << p[j].S << endl;
      solve();
     }
   }
  
  //scanf("%d", &N);
  return 0;
}
/*
10
New 5 tk
New 8 tn
New 8 taa
New 8 tb
New 8 t
Solve
Solve
Solve
Solve
New 1999999999 task

*/
