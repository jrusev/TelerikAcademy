#include<iostream>
#include<vector>
#include<algorithm>
#include<string>
#include<queue>
using namespace std;
struct Mine{
	long long x;
	string y;
};
struct intComparer{
	bool operator()(const Mine a,const Mine b){
		if (a.x<b.x){
			return false;
		} else if (a.x==b.x){
			return (a.y>b.y);
		} else return true;
	}
};
int main(){
	int N;
	cin>>N;
	string p,r,w;
	priority_queue<Mine,vector<Mine>,intComparer> q;
	vector <string> k;
	Mine temp;
	for(int i=0;i<N;i++){
		cin>>p;
		if (p=="New"){
			cin>>temp.x>>temp.y;
			q.push(temp);
		}
		else if (p=="Solve"){
			if(!q.empty()){
				k.push_back(q.top().y);
				q.pop();
			} else {
				k.push_back("Rest");
			}
		}
	}
	for(int i=0;i<k.size();i++){
		cout<<k[i]<<endl;
	}
	return 0;
}