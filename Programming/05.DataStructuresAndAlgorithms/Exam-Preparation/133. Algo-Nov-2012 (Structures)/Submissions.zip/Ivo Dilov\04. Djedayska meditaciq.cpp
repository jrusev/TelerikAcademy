#include <cstdio>
#include <iostream>
#include <string>
//#include <queue>
using namespace std;
int n;
string dz[100200];
//queue<string> knights,paduans;
int main(){
    scanf("%d",&n);
    for (int i=0;i<n;++i){
        cin>>dz[i];
        if (dz[i][0]=='m'){
            cout<<dz[i]<<" ";
        }
    }
    for (int i=0;i<n;++i){
        if (dz[i][0]=='k'){
            cout<<dz[i]<<" ";
        }
    }
    for (int i=0;i<n;++i){
        if (dz[i][0]=='p'){
            cout<<dz[i]<<" ";
        }
    }
    cout<<endl;
    //while (!knights.empty()){cout<<knights.front()<<" ";knights.pop();}
    //while (!paduans.empty()){cout<<paduans.front()<<" ";paduans.pop();}
    return 0;
}