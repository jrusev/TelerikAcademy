using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
 
namespace Tasks
{
    class Tasks
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            //string inputLine;
            string[] words = new string[3];
 
            List<Task> tasks = new List<Task>();
 
            for (int i = 0; i < n; i++)
            {
                //inputLine = Console.ReadLine();
                words = Regex.Split(Console.ReadLine(), " ");
 
                switch (words[0])
                {
                    case "New": tasks.Add(new Task(Convert.ToInt32(words[1]), words[2])); break;
                    case "Solve":
                        int min = int.MaxValue - 1, theTask = 0;
                        for (int j = 0; j < tasks.Count; j++)
                        {
                            if (tasks[j].complexity == min)
                            {
                                if (string.Compare(tasks[j].name, tasks[theTask].name) < 0)
                                {
                                    theTask = j;
                                    min = tasks[j].complexity;
                                }
                            }
                            if (tasks[j].complexity < min) { theTask = j; min = tasks[j].complexity; }
                             
                        }
                        if (min == int.MaxValue - 1)
                        {
                            Console.WriteLine("Rest");
                        }
                        else
                        {
                            Console.WriteLine(tasks[theTask].name);
                            tasks[theTask].complexity = int.MaxValue;
                        }
 
                        break;
                    default:
                        break;
                }
 
            }
 
        }
    }
 
    class Task
    {
        public int complexity;
        public string name;
 
        public Task(int comp, string name)
        {
            complexity = comp;
            this.name = name;
        }
 
    }
}