#include<iostream>
using namespace std;
unsigned long long a[20020];
int main ()
{
unsigned long long n,m,right,left,sum=0,s=0,h;
cin>>n>>m;
for (int i=0; i<n; i++)
{
 cin>>a[i];
 sum=sum+a[i];
}
left=0;
right=sum;
while (right!=left+1)
{
s=0;
h=(right+left)/2;
  for (int i=0; i<n; i++)
  {
    s=s+a[i]/h;
  }
  if (s>=m) {left=h;}
  else {right=h;}
}
cout<<left<<endl;
return 0;
}