#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
   
long long n, x, arr[100100];
   
bool cmp  (long long i, long long j){
    long long a = i % x;
    long long b = j % x;
    if (a == b) return (i<j);
    return (a < b);
}
int main (){
    scanf ("%lld %lld",&n,&x);
    for (long long i=0; i<n; i++)
        scanf ("%lld",&arr[i]);
    sort (arr, arr+n, cmp);
    for (long long i=0; i<n; i++)
        printf("%lld ",arr[i]);
    printf ("\n");
    return 0;
}