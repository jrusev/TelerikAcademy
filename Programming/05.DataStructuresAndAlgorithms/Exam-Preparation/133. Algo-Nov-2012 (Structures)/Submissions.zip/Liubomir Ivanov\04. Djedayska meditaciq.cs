using System;
using System.Collections.Generic;
using System.Linq;
using Wintellect.PowerCollections;
using System.Text;
using System.Threading.Tasks;

class JediMeditation
{
    class Jedi : IComparable<Jedi>
    {
        private string name;
        public Jedi(string name)
        {
            this.Name = name;
        }
        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }
        public int CompareTo(Jedi other)
        {
            if (this.Name[0] == 'k' && other.Name[0] == 'm')
            {
                return 1;
            }
            if (this.Name[0] == 'p' && other.Name[0] != 'p')
            {
                return 1;
            }
            if (this.Name[0] == other.Name[0])
            {
                return 0;
            }
            return -1;
        }
    }
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        string[] s = Console.ReadLine().Split(' ');
        OrderedBag<Jedi> priorityQueue = new OrderedBag<Jedi>();
        for (int i = 0; i < n; i++)
        {
            priorityQueue.Add(new Jedi(s[i]));
        }
        foreach (var item in priorityQueue)
        {
            Console.Write(item.Name + " ");
        }
    }
}