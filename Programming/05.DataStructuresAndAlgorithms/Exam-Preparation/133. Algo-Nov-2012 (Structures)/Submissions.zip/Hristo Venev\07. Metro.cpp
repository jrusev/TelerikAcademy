#include <iostream>
int main(){
    std::cout<<"OK\n";
    return 0;
}