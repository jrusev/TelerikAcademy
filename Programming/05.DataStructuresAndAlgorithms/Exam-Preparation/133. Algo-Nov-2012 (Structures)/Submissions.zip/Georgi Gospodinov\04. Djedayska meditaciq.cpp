# include <iostream>
# include <queue>

using namespace std;

struct jedi {

    char a;
    int b;

};

int main () {

    int n, i;
    cin >> n;

    char kind;
    int num;

    queue <jedi> m;
    queue <jedi> k;
    queue <jedi> p;
    jedi next;

    for ( i = 0 ; i < n ; i ++ ) {

         cin >> kind;
         cin >> num;

         next.a = kind;
         next.b = num;

         if ( kind == 'm' )
         m.push (next);

         else if ( kind == 'k' )
              k.push (next);

         else p.push (next);

    }

    while( !m.empty () ) {

         next = m.front ();

         cout << next.a << next.b << " ";

         m.pop ();

    }

    while( !k.empty () ) {

         next = k.front ();

         cout << next.a << next.b << " ";

         k.pop ();

    }

    while( !p.empty () ) {

         next = p.front ();

         cout << next.a << next.b << " ";

         p.pop ();

    }

    return 0;

}