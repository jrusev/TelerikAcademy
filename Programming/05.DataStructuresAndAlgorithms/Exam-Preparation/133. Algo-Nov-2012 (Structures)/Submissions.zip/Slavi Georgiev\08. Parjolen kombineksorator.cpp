#include<cstdio>
#include<bitset>
using namespace std;
int a[200001][6];
long n;
bitset<200001> b;
int x, y;
bool eq(long &i, long &j)
{
    if(a[i][0]==a[j][0] && a[i][1]==a[j][1] && a[i][2]==a[j][2] && a[i][3]==a[j][3] && a[i][4]==a[j][4] && a[i][5]==a[j][5])return true;
    if(a[i][0]==-a[j][0] && a[i][1]==a[j][1] && a[i][2]==-a[j][2] && a[i][3]==a[j][3] && a[i][4]==-a[j][4] && a[i][5]==a[j][5])return true;
    if(a[i][0]==a[j][0] && a[i][1]==-a[j][1] && a[i][2]==a[j][2] && a[i][3]==-a[j][3] && a[i][4]==a[j][4] && a[i][5]==-a[j][5])return true;
    if(a[i][0]==-a[j][0] && a[i][1]==-a[j][1] && a[i][2]==-a[j][2] && a[i][3]==-a[j][3] && a[i][4]==-a[j][4] && a[i][5]==-a[j][5])return true;
    x=a[i][0]-a[j][0];
    y=a[i][1]-a[j][1];
    if(a[i][2]-a[j][2]==x && a[i][3]-a[j][3]==y && a[i][4]-a[j][4]==x && a[i][5]-a[j][5]==y)return true;
    x=a[i][0]-a[j][0];
    y=a[i][1]+a[j][1];
    if(a[i][2]-a[j][2]==x && a[i][3]-a[j][3]==y && a[i][4]-a[j][4]==x && a[i][5]-a[j][5]==y)return true;
    x=a[i][0]+a[j][0];
    y=a[i][1]-a[j][1];
    if(a[i][2]-a[j][2]==x && a[i][3]-a[j][3]==y && a[i][4]-a[j][4]==x && a[i][5]-a[j][5]==y)return true;
    x=a[i][0]+a[j][0];
    y=a[i][1]+a[j][1];
    if(a[i][2]-a[j][2]==x && a[i][3]-a[j][3]==y && a[i][4]-a[j][4]==x && a[i][5]-a[j][5]==y)return true;
    return false;
}
int main()
{
    scanf("%d", &n);
    for(long i(0); i<n; ++i)scanf("%d %d %d %d %d %d", &a[i][0], &a[i][1], &a[i][2], &a[i][3], &a[i][4], &a[i][5]);
    for(long i(0); i<n-1; ++i)
    {
        if(!b[i])
        {
            for(long j(i+1); j<n; ++j)
            {
                if(eq(i, j)){ b[i]=b[j]=1; }
            }
        }
    }
    double area=0.;
    for(long i(0); i<n; ++i)
    {
        if(!b[i])
        {
            area=(a[i][0]*a[i][3]+a[i][1]*a[i][4]+a[i][2]*a[i][5]-a[i][3]*a[i][4]-a[i][0]*a[i][5]-a[i][1]*a[i][2])/2.;
            if(area<0.)area=-area;
            break;
        }
    }
    printf("%.6f\n", area);
    return 0;
}
