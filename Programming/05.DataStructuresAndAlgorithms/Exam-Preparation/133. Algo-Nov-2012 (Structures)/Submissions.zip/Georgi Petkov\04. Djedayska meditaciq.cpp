#include <iostream>
#include<set>
#include<iterator>
using namespace std;

enum jedi_rank{m, k, p};

struct jedi
{
	jedi_rank r;
	int id;
};

struct jediComparer
{
    bool operator()(jedi a, jedi b)
    {
		return a.r < b.r || a.r == b.r && a.id < a.id; 
    }
};

int main()
{
	multiset<jedi, jediComparer> s;
	int N;
	cin >> N;

	jedi j;
	char r;

	for (int i = 0; i < N; ++i)
	{
		cin >> r;
		switch (r)
		{
		case 'm': j.r = m; break;
		case 'k': j.r = k; break;
		case 'p': j.r = p;
		}
		cin >> j.id;
		s.insert(j);
	}

	for(multiset<jedi>::iterator start = s.begin(); start != s.end(); ++start)
	{
		switch (start->r)
		{
		case m: cout << 'm'; break;
		case k: cout << 'k'; break;
		case p: cout << 'p';
		}
		cout << start->id << ' ';
	}

	return 0;
}