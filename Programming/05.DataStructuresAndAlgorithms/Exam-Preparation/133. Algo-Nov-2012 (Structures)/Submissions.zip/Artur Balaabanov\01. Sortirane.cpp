#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
 
long long x;
 
struct Comp {
    bool operator()(long long, long long);
};
 
bool Comp::operator()(long long a, long long b) {
    if ((a % x) == (b % x)) {
        return a < b;
    }
    return (a % x) <= (b % x);
}
 
int main() {
    int n;
    cin>>n;
 
    cin>>x;
 
    vector<long long> numbers = vector<long long>();
    long long input = 0;
    for (int i = 0; i < n; i++) {
        cin>>input;
        numbers.push_back(input);
    }
 
    sort(numbers.begin(), numbers.end(), Comp());
 
    for (int i = 0; i<numbers.size(); i++)
    {
        cout<<numbers[i]<<" ";
    }
 
 
    return 0;
}