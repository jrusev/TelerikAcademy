using System;
using System.Linq;

class CuttingPipes
{
    static void Main()
    {
        ushort numberPipes = ushort.Parse(Console.ReadLine());
        uint numberPipesCut = uint.Parse(Console.ReadLine());

        uint[] pipesList = new uint[numberPipes];
        ulong totalPipesLength = 0;

        for (int i = 0; i < numberPipes; i++)
        {
            pipesList[i] = uint.Parse(Console.ReadLine());
            totalPipesLength += pipesList[i];
        }

        uint maxCutLength = (uint)(totalPipesLength / numberPipesCut);

    Lolcycle:
        uint numberPipesCutCurrent = 0;

        for (int i = 0; i < numberPipes; i++)
        {
            numberPipesCutCurrent += (uint)(pipesList[i] / maxCutLength);
        }

        if (numberPipesCutCurrent < numberPipesCut)
        {
            maxCutLength -= 1;
            goto Lolcycle;
        }
        else
        {
            Console.WriteLine(maxCutLength);
        }
    }
}