#include <iostream>
#include <numeric>
#include <vector>
#define nullptr NULL // fuck Telerik
size_t fuckTelerik;
unsigned fuckTelerik1(unsigned acc, unsigned a){
    return acc+a/fuckTelerik;
}
int main(){
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    size_t i, N, M;
    std::vector<unsigned> pipes;
    std::cin>>N>>M;
    pipes.resize(N);
    for(size_t fuckTelerik2=0;fuckTelerik2<N;fuckTelerik2++) std::cin>>pipes[fuckTelerik2];
    size_t begin=1, count=2000000000;
    while(count>0){
        size_t mid=begin+count/2;
        fuckTelerik=mid;
        unsigned res=std::accumulate(pipes.begin(), pipes.end(), 0u, fuckTelerik1);
        if(res>=M){
            begin=mid+1;
            count-=count/2;
        }else{
            count/=2;
        }
    }
    std::cout<<(begin-1?static_cast<int>(begin-1):-1)<<std::endl;
    return 0;
}
