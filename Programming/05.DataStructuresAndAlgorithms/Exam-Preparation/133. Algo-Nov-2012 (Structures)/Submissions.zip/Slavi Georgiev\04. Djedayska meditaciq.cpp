#include<cstdio>
#include<vector>
using namespace std;
class jedi
{
    public:
    char type;
    unsigned long num;
    jedi(char t, unsigned long& n) : type(t), num(n) { }
};
unsigned long n;
vector<jedi> v, r;
int main()
{
    scanf("%u\n", &n);
    unsigned long num;
    char c;
    v.reserve(n);
    for(unsigned long i(0); i<n-1; ++i)
    {
        scanf("%c%u ", &c, &num);
        v.push_back(jedi(c, num));
    }
    scanf("%c%u", &c, &num);
    v.push_back(jedi(c, num));
    num=v.size();
    for(unsigned long i(0); i<num; ++i)if(v[i].type=='m')r.push_back(v[i]);
    for(unsigned long i(0); i<num; ++i)if(v[i].type=='k')r.push_back(v[i]);
    for(unsigned long i(0); i<num; ++i)if(v[i].type=='p')r.push_back(v[i]);
    //string out("");
    //for(vector<jedi>::iterator i(v.begin()); i!=v.end(); ++i)if(i->type=='m')out+=(*i+" ");//cout<<*i<<" ";
    //for(vector<jedi>::iterator i(v.begin()); i!=v.end(); ++i)if(i->type=='k')out+=(*i+" ");//cout<<*i<<" ";
    //for(vector<jedi>::iterator i(v.begin()); i!=v.end(); ++i)if(i->type=='p')out+=(*i+" ");//cout<<*i<<" ";
    //out[out.length()-1]='\n';
    //printf(out);
    num=r.size()-1;
    for(unsigned long i(0); i<num; ++i)printf("%c%u ", r[i].type, r[i].num);
    printf("%c%u\n", r[num].type, r[num].num);
}
