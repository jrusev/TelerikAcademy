//
#include<iostream>
#include<queue>
#include<vector>
#include<algorithm>
#include<string>
using namespace std;
/*
class Compare {
public:
    bool operator()(string s, string s1)
    {
        //if(s[0]==s1[0]){return 1;}
        //cout<<s<<" "<<s1<<endl;
        if(s[0]=='m' && s1[0]!='m'){/*cout<<s<<" "<<s1<<" "<<"Yes1"<<endl;return 0;}
        if(s[0]=='k' && s1[0]=='p'){/*cout<<s<<" "<<s1<<" "<<"Yes1"<<endl;return 0;}
        if(s[0]=='k' && s1[0]=='m'){/*cout<<s<<" "<<s1<<" "<<"Yes1"<<endl;return 0;}        
        if(s[0]==s1[0]){/*cout<<s<<" "<<s1<<" "<<"Yes1"<<endl;return 1;}
        /*cout<<s<<" "<<s1<<" "<<"Yes1"<<endl;
        return 1;
    }
};*/
int main()
{
    //priority_queue<string, vector<string>, Compare> pq;
    queue<string>q1;
    queue<string>q2;
    queue<string>q3;
    int n,br1=0,br2=0,br3=0;
    cin>>n;
    string s;
    for(int i=0;i<n;i++)
    {
        cin>>s;
        if(s[0]=='m'){q1.push(s);br1++;}
        if(s[0]=='k'){q2.push(s);br2++;}
        if(s[0]=='p'){q3.push(s);br3++;}
    }
    //cout<<pq.top();
    //pq.pop();
    if(br1>0)
    {
        cout<<q1.front();
        q1.pop();
    }
    else
    {
        if(br2>0)
        {
            cout<<q2.front();
            q2.pop();
        }
        else{
        if(br3>0)
        {
            cout<<q3.front();
            q3.pop();
        }}
    }
    while(q1.empty()!=1)
    {
        cout<<" "<<q1.front();
        q1.pop();
    }
    while(q2.empty()!=1)
    {
        cout<<" "<<q2.front();
        q2.pop();
    }
    while(q3.empty()!=1)
    {
        cout<<" "<<q3.front();
        q3.pop();
    }
    return 0;
}