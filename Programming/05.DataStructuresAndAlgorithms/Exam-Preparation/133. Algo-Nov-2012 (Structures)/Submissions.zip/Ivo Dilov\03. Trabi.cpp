//#include <iostream>
#include <cstdio>
using namespace std;
unsigned long long sizes[20200],m,a;
int n;
bool num(unsigned long long tek){
    unsigned long long sum=0;
    for (int i=0;i<n;++i){
        sum+=(sizes[i]/tek);
    }
    return sum>=m;
}
unsigned long long ans(){
    unsigned long long l=2000000200,r=1,tek;
    while (l-r>1){
        tek=(l+r)/2;
        if (num(tek)){r=tek;}
        else{l=tek;}
    }
    if (num(l)){return l;}
    if (num(r)){return r;}
    return 0;
}
int main(){
    scanf("%d%llu",&n,&m);
    for (int i=0;i<n;++i){
        scanf("%llu",&sizes[i]);
    }
    a=ans();
    if (a==0){printf("-1\n");}
    else{printf("%llu\n",a);}
    return 0;
}
