#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>
using namespace std;
  long long a[1000001];
  long long x;
  long long n;
  int i;
bool f(long long p, long long q)
{
  if(p%x<q%x)return true;
  if(p%x==q%x && p<q)return true;
  return false;
}
int main()
{
  cin>>n>>x;
  for(i=0;i<n;++i)
    cin>>a[i];
    sort(a,a+n,f);
    for(i=0;i<n-1;++i)
    cout<<a[i]<<" ";
    cout<<a[n-1]<<endl;
    return 0;
}