#include<iostream>
#include<cstdio>
#include<algorithm>
#include<queue>
using namespace std;
typedef long long intt;

struct newtype{
    intt c;
    string name;
};

struct compare
{
  bool operator()(const newtype& l, const newtype& r)
  {
      if (l.c == r.c) return (l.name > r.name);
      return (l.c > r.c);
  }
};

priority_queue< newtype ,vector<newtype>, compare > pq;
intt n, complexity;
string comand, name;

int main (){
    cin>> n;
    for (intt i=0; i<n; i++){
        cin >> comand;
        if (comand == "Solve"){
            cout << pq.top().name << endl;
            pq.pop ();
            continue;
        }
        newtype newa;
        cin >> newa.c >> newa.name;

        pq.push(newa);


    }
    return 0;
}
