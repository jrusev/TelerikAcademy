#include<iostream>
#include<algorithm>
using namespace std;
unsigned long long d;
bool compar(const unsigned long long &x, const unsigned long long &y)
{
    if((x%d)<(y%d))return true;
    if((x%d)==(y%d))
    {
        if(x<y)return true;
    }
    return false;
}
int main()
{
    long long n;
    cin>>n>>d;
    long long a[100001];
    for(long long i(0); i<n; ++i)cin>>*(a+i);//scanf("%u", a+i);
    sort(a, a+n, compar);
    for(long long i(0); i<n-1; ++i)cout<<*(a+i)<<" ";//printf("%u ", *(a+i));
    //printf("%lld\n", *(a+(n-1)));
    cout<<*(a+(n-1))<<endl;
    return 0;
}
