#include <cstdio>
int main() {
    puts("OK");
    return 0;
}