using System;
using Wintellect.PowerCollections;
using System.Collections.Generic;

class JediMeditation
{
    class Jedi : IComparable<Jedi>
    {
        public int rank;
        public string name;

        public Jedi(int rank, string name)
        {
            this.rank = rank;
            this.name = name;
        }

        public Jedi()
        {
            new Jedi(0, "");
        }

        public int CompareTo(Jedi other)
        {
            if (this.rank == other.rank)
            {
                return 0;
            }
            else
            {
                return ((this.rank > other.rank) ? 1 : -1);
            }
        }
    }
    static void Main()
    {
        string input = Console.ReadLine();
        int n = int.Parse(input);
        Jedi currentJedi = new Jedi();
        OrderedBag<Jedi> jediQueue = new OrderedBag<Jedi>();
        string[] inputQueue = Console.ReadLine().Split();
        for (int i = 0; i < n; i++)
        {
            switch (inputQueue[i][0])
            {
                case 'm':
                    currentJedi.rank = 1;
                    currentJedi.name = inputQueue[i];
                    break;
                case 'k':
                    currentJedi.rank = 2;
                    currentJedi.name = inputQueue[i];
                    break;
                case 'p':
                    currentJedi.rank = 3;
                    currentJedi.name = inputQueue[i];
                    break;
            }
            jediQueue.Add(new Jedi(currentJedi.rank, currentJedi.name));
        }
        //jediQueue.Sort();
        foreach (Jedi jedi in jediQueue)
        {
            Console.Write(jedi.name + " ");
        }
    }
}