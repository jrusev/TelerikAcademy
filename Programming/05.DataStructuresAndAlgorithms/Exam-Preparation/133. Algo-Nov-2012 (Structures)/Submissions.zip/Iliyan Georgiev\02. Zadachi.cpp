#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<vector>
#include<set>
#include<algorithm>
using namespace std;
struct task
{
	string complexity;
	string name;
};
struct comp{
bool operator()( task t1, task t2 )
{
	if( t1.complexity < t2.complexity )
		return true;
	else if( t1.complexity == t2.complexity )
	{
		if( t1.name < t2.name )
			return true;
		return false;
	}
	return false;
}
};
int main()
{
	int n;
	scanf("%d", &n );
	multiset<task, comp> vec;
	task temp;
	string command,text;//int comp;
	char ch[100];
	for( int i = 0; i < n; i++ )
	{
		scanf("%s",ch);
		if( !strcmp(ch, "New" ))
		{
			scanf("%s",ch);
			temp.complexity = ch;
			scanf("%s",ch);
			temp.name=ch;
			vec.insert(temp);
		}
		else if( !strcmp(ch, "Solve") )
		{
			if( vec.empty() )
			    printf("Rest\n");
			else
			{
				printf("%s\n", (*(vec.begin())).name.c_str());
				vec.erase(vec.begin());
			}
		}
	}
	return 0;
}
