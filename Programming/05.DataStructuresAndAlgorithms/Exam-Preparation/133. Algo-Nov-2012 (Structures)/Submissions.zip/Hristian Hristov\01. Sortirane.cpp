#include <iostream>
#include<vector>
#include <algorithm>
using namespace std;

struct num
{
       long long v, r;
       num(){}
       num(long long _v, long long _r)
       {
                v=_v;
                r=_r;
       }
       bool operator<(const num &a)
       const {
             if(r<a.r) return true;
             if(r==a.r) return v<a.v;
             return false;
             }
}a[200000];
int main()
{
    long long n,x;
    cin >> n >> x;
    long long k;
    for(int i=0; i<n; i++)
    {
            cin >> k;
            a[i]=num(k,k%x);
    }
    
    sort(a,a+n);
    
    for(int i=0; i<n-1; i++)
    {
            cout << a[i].v << ' ';
    }
    
    cout << a[n-1].v << endl;
    return 0;
    
}
