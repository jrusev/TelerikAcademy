#include<iostream>
#include<stdio.h>
#include<algorithm>
using namespace std;
long long n, x, a[100001], b[100001], c[100001], y = 0, y1 = 0;
void in()
{ scanf("%llu %llu", &n, &x);
  for (int i = 0; i < n; i++)
  scanf("%llu", &a[i]);
}
 
void make()
{ for (int i = 0; i < n; i++)
  b[i] = a[i] % x;
   
  sort(b, b + n);
  for (int i = 0; i < n; i++)
  { if (i != 0 && b[i - 1] == b[i]) continue;
     
    for (int j = 0; j < n; j++)
    if (a[j] % x == b[i])
    c[y++] = a[j];
     
    sort(c + y1, c + y);
    y1 = y;
   }
   
  for (int i = 0; i < y - 1; i++)
  printf("%llu ", c[i]);
  printf("%llu\n", c[y - 1]);
}
 
int main()
{
  in();
  make();
   
  //cin >> n;
  return 0;
}