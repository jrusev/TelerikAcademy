#include<iostream>
using namespace std;
int main()
{
    long long n,x,zamestitel=0,ostatak_1=0,ostatak_2=0;
    cin>>n>>x;
    if(n>100000)
    {
        cout<<"please insert corect number"<<endl;
        return 1;
    }
    int spisak[n];
    for(int br=0;br<n;br++)
    {
        cin>>spisak[br];
    }

    for(int br=0;br<n;br++)
    {
        for(int br=0;br<n;br++)
        {

            ostatak_1=spisak[br+1]%x;
            ostatak_2=spisak[br]%x;
            if(ostatak_1<ostatak_2)
            {
                zamestitel=spisak[br];
                spisak[br]=spisak[br+1];
                spisak[br+1]=zamestitel;
            }
        }
    }
  for(int br=0;br<n;br++)
    for(int br=0;br<n;br++)
    {

      ostatak_1=spisak[br+1]%x;
      ostatak_2=spisak[br]%x;
      if(ostatak_1==ostatak_2)
      {
        if(spisak[br+1]<spisak[br])
        {
            zamestitel=spisak[br];
            spisak[br]=spisak[br+1];
            spisak[br+1]=zamestitel;
        }
      }
    }
        for(int br=0;br<n;br++)
    {
        cout<<spisak[br]<<" ";
    }


    return 0;
}#include<iostream>
using namespace std;
int main()
{
    long long n,x,zamestitel=0,ostatak_1=0,ostatak_2=0;
    cin>>n>>x;
    if(n>100000)
    {
        cout<<"please insert corect number"<<endl;
        return 1;
    }
    int spisak[n];
    for(int br=0;br<n;br++)
    {
        cin>>spisak[br];
    }

    for(int br=0;br<n;br++)
    {
        for(int br=0;br<n;br++)
        {

            ostatak_1=spisak[br+1]%x;
            ostatak_2=spisak[br]%x;
            if(ostatak_1<ostatak_2)
            {
                zamestitel=spisak[br];
                spisak[br]=spisak[br+1];
                spisak[br+1]=zamestitel;
            }
        }
    }
  for(int br=0;br<n;br++)
    for(int br=0;br<n;br++)
    {

      ostatak_1=spisak[br+1]%x;
      ostatak_2=spisak[br]%x;
      if(ostatak_1==ostatak_2)
      {
        if(spisak[br+1]<spisak[br])
        {
            zamestitel=spisak[br];
            spisak[br]=spisak[br+1];
            spisak[br+1]=zamestitel;
        }
      }
    }
        for(int br=0;br<n;br++)
    {
        cout<<spisak[br]<<" ";
    }


    return 0;
}