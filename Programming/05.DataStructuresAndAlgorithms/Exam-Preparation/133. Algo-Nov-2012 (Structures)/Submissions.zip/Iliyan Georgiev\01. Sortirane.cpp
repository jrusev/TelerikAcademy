#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>
using namespace std;
unsigned int x;

bool comp( unsigned int i1, unsigned int i2 )
{
	if( i1%x < i2%x )
	    return true;
	else if( i1%x == i2%x )
	{
		if( i1<i2 )
		    return true;
		return false;
	}
	return false;
}

int main()
{
	int n;
	unsigned int k;
	vector<unsigned int> vec;
	scanf("%d%u",&n,&x);
	for( int i = 0; i < n; i++ )
	{
		scanf("%u",&k);
		vec.push_back(k);
	}
	sort( vec.begin(), vec.begin()+n, comp );
	for( int i = 0; i < n; i++ )
	    printf("%u ", vec[i] );
	return 0;
}
