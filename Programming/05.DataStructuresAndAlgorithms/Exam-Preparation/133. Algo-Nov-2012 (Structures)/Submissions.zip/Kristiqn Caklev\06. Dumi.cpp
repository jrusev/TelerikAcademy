#include<cstdio>
#include<map>
#include<string>
#include<vector>
int t,w;
bool f;
char ch;
std::string word;
std::map<std::string,bool> mapo;
std::map<std::string,bool>::iterator it;
struct asdf{
	bool _[26];
}buhta;
std::vector<asdf> grah;
inline void s2s(const std::string &str,asdf &st)
{
	for(int i=0;i<str.size();++i)
		st._[(str[i]|0x20)-'a']=true;
}
int main()
{
	scanf("%d",&t);getchar();
	for(int i=0;i<t;++i)
	{
		asdf:
		ch=getchar();
		if(('A'<=ch&&ch<='Z')||('a'<=ch&&ch<='z'))
		{
			f=true;
			word+=(char)(ch|0x20);
		}
		else if(f)
		{
			f=false;
			mapo[word]=true;
			word="";
		}
		if(ch=='\n')continue;
		goto asdf;
	}
	grah.resize(mapo.size());
	it=mapo.begin();
	for(int i=0;it!=mapo.end();++i,++it)
		s2s(it->first,grah[i]);
	scanf("%d",&w);getchar();
	for(int i=0;i<w;++i)
	{
		word="";
		asdf2:
		ch=getchar();
		if(ch=='\n')goto asdf3;
		word+=ch;
		goto asdf2;
		asdf3:
		for(int i=0;i<26;++i)
			buhta._[i]=0;
		s2s(word,buhta);
		int br=0;
		for(int i=0;i<grah.size();++i)
		{
			for(int j=0;j<26;++j)
			{
				if(buhta._[j]&&!grah[i]._[j])
					goto skip;
			}
			++br;
			skip:;
		}
		printf("%s -> %d\n",word.c_str(),br);
	}
	return 0;
}
