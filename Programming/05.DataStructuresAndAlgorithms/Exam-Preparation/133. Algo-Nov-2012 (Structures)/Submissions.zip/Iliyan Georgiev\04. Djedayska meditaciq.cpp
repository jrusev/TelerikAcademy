#include<iostream>
#include<queue>
#include<string>
#include<cstdio>
using namespace std;
int main()
{
	queue<string> masters,knights,padawans;
	int n;
	string st;
	scanf("%d",&n);
	char ch[100];
	for(int i = 0; i < n; i++ )
	{
		scanf("%s", ch);
		st=ch;
		if( st[0]=='m' )
		    masters.push( st );
		else if(st[0]=='k')
			knights.push( st );
		else
		    padawans.push( st );
	}
	while( !masters.empty() )
	{
		printf("%s ", masters.front().c_str());
		masters.pop();
	}
	while( !knights.empty() )
	{
		printf("%s ", knights.front().c_str());
		knights.pop();
	}
	while( !padawans.empty() )
	{
		printf("%s ", padawans.front().c_str());
		padawans.pop();
	}
	return 0;
}
