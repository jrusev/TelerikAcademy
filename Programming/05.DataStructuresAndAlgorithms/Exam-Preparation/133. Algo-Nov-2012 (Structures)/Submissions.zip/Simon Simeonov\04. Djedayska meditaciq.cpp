#include <iostream>
#include <queue>
#include <string>
using namespace std;


queue <string> que[3];



int main(){
	string tek;
	int n;

	cin>>n;
	for(int i = 0; i<n; ++i){
		cin>>tek;
		if(tek[0] == 'm') que[0].push(tek);
		else if( tek[0] == 'k') que[1].push(tek);
		else que[2].push(tek);
	}

	for(int i = 0; i<3; ++i){

		while(!que[i].empty()){
			cout<<que[i].front();

			que[i].pop();
			i = 3;
			break;
		}
	}


	for(int i = 0; i<3; ++i){

		while(!que[i].empty()){
			cout<<" "<<que[i].front();
			que[i].pop();
		}
	}
	cout<<endl;







	return 0;

}
