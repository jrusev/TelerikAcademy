#include <iostream>
#include <limits>
using namespace std;

int N, M;
int* tubes;
int min_value = 2000000000;

bool isGood(int value)
{
	if(value == 0)
		return false;
	int num = 0;
	for (int i = 0; i < N; ++i)
	{
		num += tubes[i] / value;
	}
	return num >= M;
}

int binary_search(int lb, int ub)
{
	if(lb > ub)
	{
		return -1;
	}
	int mid = (lb + ub) / 2;
	if(isGood(mid))
	{
		int temp = binary_search(mid + 1, ub);
		return temp > mid ? temp : mid;
	}
	else
	{
		return binary_search(lb, mid - 1);
	}
}

int main()
{
	cin >> N >> M;

	tubes = new int[N];

	for (int i = 0; i < N; ++i)
	{
		cin >> tubes[i];
		if (tubes[i] < min_value)
		{
			min_value = tubes[i];
		}
	}
	cout << binary_search(0, 2000000000);
	return 0;
}