#include <stdio.h>
#include <queue>
#include <vector>
#include <string.h>

using namespace std;

struct task
{
    char name[7];
    unsigned int complexity;
};

/*!bool CompareStrings(char a[], char b[])
{
    int it = 0, v = strlen(a);
    if(strlen(b)>a)
    while ((a[it] == b[it]) && (it < 6)) it++;
    if ((it == 6) || (b[it] > a[it])) return false;
    else return true;
}*/

struct intComparer
{
	bool operator()(task a, task b)
	{
		return ((a.complexity > b.complexity) || ((a.complexity == b.complexity) && (/*!CompareStrings*/strcmp(a.name, b.name) > 0)));
	}
};

int n;
priority_queue <task, vector<task>, intComparer> tasksQueuery;

void Solve()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        char a[6];
        scanf("%s", a);
        if (a[0] == 'N')
        {
            //!printf("in New()\na = %s\n", a);
            task b;
            scanf("%u%s", &b.complexity, b.name);
            tasksQueuery.push(b);
        }
        else
        {
            //!printf("in Solve\na = %s\n", a);
            if (tasksQueuery.empty()) printf("Rest\n");
            else
            {
                printf("%s\n", tasksQueuery.top().name);
                tasksQueuery.pop();
            }
        }
    }
}

int main()
{
    Solve();

    return 0;
}
