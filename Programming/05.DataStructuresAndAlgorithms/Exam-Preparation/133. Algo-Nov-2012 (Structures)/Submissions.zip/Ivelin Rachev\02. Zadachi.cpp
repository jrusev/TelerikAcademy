#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>
#include<queue>
#include<string>
using namespace std;
struct task
{
  unsigned long long comp;
  string name;
};
class cmpTasks {
    public:
    bool operator()(task& t1, task& t2)
    {
      if(t2.comp < t1.comp) return 1;
      if(t1.comp==t2.comp)
        if(t2.name < t1.name) return 1;
       return 0;
    }
};
priority_queue <task, vector<task> ,cmpTasks> a;
int main()
{
  int n;
  cin>>n;
  for(int i=0;i<n;i++)
  {
    string s;
    cin>>s;
    if(s=="Solve")
    {
      if(a.size()==0)cout<<"Rest"<<endl;
      else
      {
        task x=a.top();
        a.pop();
        cout<<x.name<<endl;
      }
    }
    else
    {
      task o;
      cin>>o.comp;
      cin>>o.name;
      a.push(o);
    }
  }
  return 0;
}