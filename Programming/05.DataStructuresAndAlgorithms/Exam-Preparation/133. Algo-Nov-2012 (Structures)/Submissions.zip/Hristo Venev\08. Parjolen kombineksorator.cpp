#include <iostream>
unsigned dasXor=0;
unsigned abs(int x){
    return x<0?-x:x;
}
int main(){
    int x1, y1, x2, y2, x3, y3;
    unsigned N;
    std::ios::sync_with_stdio(0);
    std::cin.tie(0);
    std::cin>>N;
    for(unsigned i=0;i<N;i++){
        std::cin>>x1>>y1>>x2>>y2>>x3>>y3;
        x2-=x1;
        y2-=y1;
        x3-=x1;
        y3-=y1;
        dasXor^=abs(x2*y3-x3*y2);
    }
    if(dasXor%2==0){
        std::cout<<dasXor/2<<".000000\n";
    }else{
        std::cout<<dasXor/2<<".500000\n";
    }
    return 0;
}