#include <iostream>
#include<set>
#include<iterator>
using namespace std;

int N;
unsigned X;
struct unsignedComparer
{
    bool operator()(unsigned a, unsigned b)
    {
        return a % X < b % X || (a < b && a % X == b % X);
    }
};

int main()
{
	multiset<unsigned, unsignedComparer> ms;
	cin >> N >> X;

	unsigned value;
	for (int i = 0; i < N; ++i)
	{
		cin >> value;
		ms.insert(value);
	}

	copy(ms.begin(), ms.end(), ostream_iterator<unsigned>(cout, " "));

	return 0;
}