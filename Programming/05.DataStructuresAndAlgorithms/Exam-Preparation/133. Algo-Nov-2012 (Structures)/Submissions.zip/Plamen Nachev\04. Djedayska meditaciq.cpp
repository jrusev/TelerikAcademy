#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

int N;

struct list
{ 
  char name[10], c;
  int num;
};
list p[100000];


bool sort1( list l1, list l2 )
{ 
  if( l1.c == l2.c )  return l1.num < l2.num;
  return l1.c < l2.c;
}


int main()
{ 
  scanf("%d", &N);
  
  for( int i = 0; i < N; i++ )
  { 
    scanf("%s", &p[i].name);
    p[i].num = i;
    if( p[i].name[0] == 'm' )  p[i].c = 'a';
    if( p[i].name[0] == 'k' )  p[i].c = 'b';
    if( p[i].name[0] == 'p' )  p[i].c = 'c';
   }
  
  sort(p, p+N, sort1);
  
  for( int i = 0; i < N-1; i++ )
  printf("%s ", p[i].name);
  printf("%s\n", p[N-1].name);
  
  //scanf("%d", &N);
  return 0;
}
