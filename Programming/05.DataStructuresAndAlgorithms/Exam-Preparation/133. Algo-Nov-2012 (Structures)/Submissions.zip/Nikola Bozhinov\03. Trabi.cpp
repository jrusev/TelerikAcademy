#include<iostream>
#include<vector>
using namespace std;
int main(){
    vector <long long> v;
    long long N,M,k;
    long long sum=0;
    cin>>N>>M;
    for(int i=0;i<N;i++){
        cin>>k;
        sum+=k;
        v.push_back(k);
    }
    if (sum<M){
        int b=-1;
        cout<<b;
        return 0;
    }
    sum=sum/M;
    int j=0;
    while(sum>0 && j!=M){
        j=0;
        for(int i=0;i<N;i++)
            j+=v[i]/sum;
        sum=sum-1;
    }
    if (j==M)
        cout<<sum+1;
    return 0;
}