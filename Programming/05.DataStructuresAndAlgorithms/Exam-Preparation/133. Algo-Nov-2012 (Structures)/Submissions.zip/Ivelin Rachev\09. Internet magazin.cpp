#include<iostream>
#include<algorithm>
#include<string>
#include<cstdio>
#include<cmath>
#include<vector>
using namespace std;
struct product
{
  string name;
  double price;
  string pro;
};
vector <product> shop;
void add()
{
  product work;
  char c;
  cin.get(c);
  getline(cin,work.name,';');
  cin>>work.price;
  cin.get(c);
  getline(cin,work.pro,'\n');
  shop.push_back(work);
  cout<<"Product added"<<endl;
 // cout<<work.name<<" "<<work.price<<" "<<work.pro<<endl;
}
void deleteProduct()
{
  char c;
  cin.get(c);
  string by;
  getline(cin,by,'\n');
  string by1,by2;
  //cout<<by<<endl;
  if(by.find(';')==string::npos)
  {
  int br=0;
  for(int i=0;i<shop.size();i++)
    if(shop[i].pro==by)
    {
      br++;
      shop.erase(shop.begin()+i);
      i--;
    }
  if(br==0)cout<<"No products found"<<endl;else
  cout<<br<<" products deleted"<<endl;
  return ;
  }
  else
  {
    by1="";
    by2="";
    int t=0;
    while(by[t]!=';')
    {
      by1+=by[t];
      by.erase(0,1);
    }
    by.erase(0,1);
    by2+=by;
   // cout<<by1<<" "<<by2<<endl;
      int br=0;
   for(int i=0;i<shop.size();i++)
    if(shop[i].name==by1)
    if(shop[i].pro==by2)
    {
      br++;
      shop.erase(shop.begin()+i);
      i--;
    }
 /* for(int i=0;i<shop.size();i++)
    if(shop[i].pro==by2)
    {
      br++;
      shop.erase(shop.begin()+i);
      i--;
    }
    */
  if(br==0)cout<<"No products found"<<endl;
  else
  cout<<br<<" products deleted"<<endl;
  return ;
  }
}
bool f1(product a,product b)
{
  if(a.name>b.name)return 0;
 // if(a.name==b.name && a.pro>b.pro)return 0;
 // if(a.name==b.name && a.pro==b.pro && a.price>b.price)return 0;
  return 1;
}
void FindByName()
{
  string ime;
  char c;
  cin.get(c);
  getline(cin,ime);
 // cout<<ime<<endl;
  vector <product> out;
  for(int i=0;i<shop.size();i++)
    if(shop[i].name==ime)
      out.push_back(shop[i]);
  if(out.size()==0){
    cout<<"No products found"<<endl;
    return ;
    }
  sort(out.begin(),out.end(),f1);
 // cout<<out.size()<<" product found"<<endl;
  for(int i=0;i<out.size();i++){
    cout<<"{"<<out[i].name<<";"<<out[i].pro<<";";
    printf("%.2f}\n",out[i].price);}
}
void FindByPrice()
{
  double from,to;
  char c;
  cin>>from;
  cin.get(c);
  cin>>to;
 // cout<<from<<" "<<to<<endl;
  vector <product> out;
  //cout<<from<<to<<endl;
  for(int i=0;i<shop.size();i++)
    if(shop[i].price>=from && shop[i].price<=to)
      out.push_back(shop[i]);
  if(out.size()==0){ cout<<"No products found"<<endl; return ;}
  sort(out.begin(),out.end(),f1);
 // cout<<out.size()<<" product found"<<endl;
  for(int i=0;i<out.size();i++){
    cout<<"{"<<out[i].name<<";"<<out[i].pro<<";";
    printf("%.2f}\n",out[i].price);}
}
void FindByProducer()
{
  string ime;
  char c;
  cin.get(c);
  getline(cin,ime);
  vector <product> out;
  for(int i=0;i<shop.size();i++)
    if(shop[i].pro==ime)
      out.push_back(shop[i]);
  if(out.size()==0){ cout<<"No products found"<<endl; return ;}
  sort(out.begin(),out.end(),f1);
  //cout<<out.size()<<" product found"<<endl;
  for(int i=0;i<out.size();i++){
    cout<<"{"<<out[i].name<<";"<<out[i].pro<<";";
    printf("%.2f}\n",out[i].price);}
}
int main()
{
  int n;
  cin>>n;
  string t;
  for(int i=0;i<n;i++)
    {
      cin>>t;
      if(t=="AddProduct")add();
      else
      if(t=="DeleteProducts")deleteProduct();
      else
      if(t=="FindProductsByName")FindByName();
      else
      if(t=="FindProductsByPriceRange")FindByPrice();
      else
      FindByProducer();
    }
    return 0;
}