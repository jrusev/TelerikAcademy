#include<iostream>
using namespace std;
int n;
int main(){
    cin>>n;
    char a[n],i;
    unsigned long long a1[n],f=0;
    for(i=0;i<n;i++){
        cin>>a[i]>>a1[i];
    }
    for(i=0;i<n;i++){
        if(a[i]=='m'){
            if(f==0){cout<<a[i]<<a1[i];f++;}
            else cout<<" "<<a[i]<<a1[i];
        }
    }
    for(i=0;i<n;i++){
        if(a[i]=='k'){
            if(f==0){cout<<a[i]<<a1[i];f++;}
            else cout<<" "<<a[i]<<a1[i];
        }
    }
    for(i=0;i<n;i++){
        if(a[i]=='p'){
            if(f==0){cout<<a[i]<<a1[i];f++;}
            else cout<<" "<<a[i]<<a1[i];
        }
    }
    cout<<endl;
    return 0;
}
