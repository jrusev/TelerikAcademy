#include<cstdio>
#include<algorithm>
unsigned n,x;
struct asdf{
	unsigned _;
}A[100042];
inline bool operator<(const asdf &a,const asdf &b)
{
	if(a._%x==b._%x)
		return a._<b._;
	return a._%x<b._%x;
}
int main()
{
	scanf("%u%u",&n,&x);
	for(int i=0;i<n;++i)
		scanf("%u",&A[i]._);
	std::sort(A,A+n);
	printf("%u",A[0]._);
	for(int i=1;i<n;++i)
		printf(" %u",A[i]._);
	puts("");
	return 0;
}
