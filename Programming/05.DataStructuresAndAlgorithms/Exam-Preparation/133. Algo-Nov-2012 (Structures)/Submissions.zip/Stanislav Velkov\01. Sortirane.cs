using System;

class RemainderSort
{
    static void Main()
    {
        string[] inputString1 = Console.ReadLine().Split();

        int totalN = int.Parse(inputString1[0]);

        uint divisorX = uint.Parse(inputString1[1]);

        string[] numbersListString = Console.ReadLine().Split();

        uint[] numbersList = new uint[totalN];
        uint[] remaindersList = new uint[totalN];

        for (uint i = 0; i < totalN; i++)
        {
            numbersList[i] = uint.Parse(numbersListString[i]);
            remaindersList[i] = numbersList[i] % divisorX;
        }

        Array.Sort(numbersList);

        Array.Sort(remaindersList, numbersList);

        for (int i = 0; i < totalN; i++)
        {
            Console.Write("{0} ", numbersList[i]);
        }
        Console.WriteLine();
    }
}