#include<iostream>
#include<vector>
#include<cmath>
#include<cstdio>
using namespace std;
struct tria
{
  int x1,x2,x3,y1,y2,y3;
  int br;
};
double dist (int xa,int xb,int ya,int yb)
{
  return sqrt((xa-xb)*(xa-xb)+(ya-yb)*(ya-yb));
}
vector <tria> a;
bool same (tria x,tria y)
{
  if(dist(x.x1,x.x2,x.y1,x.y2)==dist(y.x1,y.x2,y.y1,y.y2))
  if(dist(x.x1,x.x3,x.y1,x.y3)==dist(y.x1,y.x3,y.y1,y.y3))
  if(dist(x.x2,x.x3,x.y2,x.y3)==dist(y.x2,y.x3,y.y2,y.y3))
    return 1;
  return 0;
}
int main()
{
  int n;
  cin>>n;
  for(int i=0;i<n;i++)
  {
    tria work;
    cin>>work.x1>>work.y1>>work.x2>>work.y2>>work.x3>>work.y3;
    bool k=0;
    for(int i=0;i<a.size();i++)
      if(same(work,a[i])){a[i].br++;k=1;break;}
    if(k==0)
    {
      work.br=1;
      a.push_back(work);}
  }
  double ans=0;
  for(int i=0;i<a.size();i++)
  {
   // cout<<a[i].x1<<" "<<a[i].y1<<" "<<a[i].br<<endl;
    if(a[i].br%2==1)
      {
        ans=a[i].x1*a[i].y2+a[i].x3*a[i].y1+a[i].x2*a[i].y3-a[i].y2*a[i].x3-a[i].y3*a[i].x1-a[i].y1*a[i].x2;
        ans=fabs(ans);
        ans/=2;
      }
  }
  printf("%.6f",ans);
  cout<<endl;
}