#include <iostream>
#include <string>
#include <vector>
#include <iterator>
#define emplace_back push_back // fuck Telerik
namespace std{ // fuck Telerik
    std::string move(std::string &x){
        std::string y;
        y.swap(x);
        return y;
    }
}
int main(){
    std::vector<std::string> people[3];
    size_t N;
    std::ios::sync_with_stdio(0);
    std::cin>>N;
    while(N--){
        std::string x;
        std::cin>>x;
        if(x[0]=='m') people[0].emplace_back(std::move(x));
        else if(x[0]=='k') people[1].emplace_back(std::move(x));
        else if(x[0]=='p') people[2].emplace_back(std::move(x));
    }
    std::copy(people[0].begin(), people[0].end(), std::ostream_iterator<std::string>(std::cout, " "));
    std::copy(people[1].begin(), people[1].end(), std::ostream_iterator<std::string>(std::cout, " "));
    std::copy(people[2].begin(), people[2].end()-1, std::ostream_iterator<std::string>(std::cout, " "));
    std::cout<<people[2].back()<<'\n';
    return 0;
}
