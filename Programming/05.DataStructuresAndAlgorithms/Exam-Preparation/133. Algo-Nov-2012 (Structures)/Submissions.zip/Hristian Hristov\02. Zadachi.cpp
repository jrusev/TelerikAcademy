#include <iostream>
#include <cmath>
#include <vector>
#include <stack>
#include <cstdio>
#include <queue>
using namespace std;

struct task
{
       int comp;
       string name;
       task(){}
       task(int _comp, string _name)
       {
                comp=_comp;
                name=_name;
       }
       
       bool operator<(const task &a)
       const {
            if(comp>a.comp) return true;
            if(comp==a.comp) return name>a.name;
            return false;
       }
};

priority_queue<task> q;

int main()
{
    setvbuf ( stdin , NULL , _IOFBF , 1<<20 );
    setvbuf ( stdout , NULL , _IOFBF , 1<<20 );
    int n;
    scanf("%d", &n);
    string s;
    int c; 
    string nm;
    string t;
    int k1=0, k2=0;
    for(int i=0; i<n; i++)
    {
            cin >> s;
            if(s[0]=='N'){
                          k1++;
                          scanf("%d", &c);
                       cin >> nm;
                         q.push(task(c,nm));
                         }
            else {
                 if(k1==0) printf("Rest\n");
                 else {
                      k1--;
                      t=q.top().name;
                      q.pop();
                      cout << t << endl;
                      }
                 }
    }
    return 0;
    
}
