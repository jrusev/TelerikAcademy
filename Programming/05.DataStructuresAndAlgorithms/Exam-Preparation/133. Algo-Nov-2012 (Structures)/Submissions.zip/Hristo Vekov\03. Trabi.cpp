#include <cstdio>
using namespace std;
long long p[20001],k,q;
int n;
bool num(long long usage)
{long long sum=0;
    for(int i=0;i<n;i++)
{sum+=(p[i]/usage);

}
 return sum>=k;

}

long long ans()
{long long l=2000000000,r=1,usage;
while(l-r>1)
{usage=(l+r)/2;
if(num(usage)) {r=usage;} else l=usage;
}
 if(num(l)) return l;
 if(num(r)) return r;
 return 0;
}
int main()
{scanf("%d%llu",&n,&k);
for(int i=0;i<n;i++)
    {scanf("%llu",&p[i]);

    }
  q=ans();
  if(q==0) printf("-1\n");
  else printf("%llu\n",q);
    return 0;
}
