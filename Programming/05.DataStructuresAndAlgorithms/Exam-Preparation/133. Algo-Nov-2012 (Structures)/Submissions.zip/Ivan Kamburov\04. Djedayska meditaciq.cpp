#include <stdio.h>
#include <vector>
#include <string>
#include <iostream>
 
using namespace std;
 
int n, mastersSize, knightsSize, padawansSize;
vector <string> masters, knights, padawans;
 
void Solve()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        string a;
        cin >> a;
        if (a[0] == 'm')
        {
            masters.push_back(a);
            mastersSize++;
        }
        else if (a[0] == 'k')
        {
            knights.push_back(a);
            knightsSize++;
        }
        else
        {
            padawans.push_back(a);
            padawansSize++;
        }
    }
}
 
void Output()
{
    bool mastersEmpty = mastersSize, knightsEmpty = knightsSize, padawansEmpty = padawansSize;
    if (mastersEmpty)
    {
        cout << masters[0];
        for (int i = 1; i < mastersSize; i++) cout << ' ' << masters[i];
    }
    if (knightsEmpty)
    {
        if (mastersEmpty) for (int i = 0; i < knightsSize; i++) cout << ' ' << knights[i];
        else
        {
            cout << knights[0];
            for (int i = 1; i < knightsSize; i++) cout << ' ' << knights[i];
        }
    }
    if (padawansEmpty)
    {
        if ((knightsEmpty) || (mastersEmpty)) for (int i = 0; i < padawansSize; i++) cout << ' ' << padawans[i];
        else
        {
            cout << padawans[0];
            for (int i = 1; i < padawansSize; i++) cout << ' ' << padawans[i];
        }
    }
    cout << endl;
}
 
int main()
{
    Solve();
    Output();
 
    return 0;
}