#include<cstdio>
#include <algorithm>
#define maxn 100010
using namespace std;
 
 
int n, x;
 
 
bool cmp(unsigned long long a, unsigned long long b){
 
 
 
    if(a%x < b%x) return true;
        else if(a%x == b%x) return a<b;
        else return false;
 
}
 
 
unsigned long long a[maxn];
 
int main(){
 
    scanf("%d %d", &n, &x);
    for(int i = 0; i<n; ++i){
        scanf("%llu", a+i);
    }
 
    sort(a, a+n, cmp);
 
    for(int i = 0; i<n-1; ++i){
        printf("%llu ", a[i]);
    }
 
    printf("%llu\n", a[n-1]);
 
    return 0;
}