using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tubes
{
    class Tubes
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int m = int.Parse(Console.ReadLine());

            int sumOfTubes = 0, length = 0;
            int[] arrTubes = new int[n];

            int tMin = int.MaxValue;
            for (int i = 0; i < n; i++)
            {
                length = int.Parse(Console.ReadLine());
                arrTubes[i] = length;

                if (length < tMin)
                {
                    tMin = length;
                }

                sumOfTubes += length;
            }

            int maxLForEach = tMin;
            int tube = sumOfTubes;
            do
            {
                if (tube < 0)
                {
                    tube = sumOfTubes;
                    for (int i = 0; i < m; i++)
                    {
                        tube -= maxLForEach;
                        if (tube < 0)
                        {
                            break;
                        }
                    }
                }
                int newM = 0;
                for (int i = 0; i < n; i++)
			    {
                        
                    newM += arrTubes[i] / maxLForEach;
			 
			    }
                if(newM >= m)
                {
                    break;
                }
                
                maxLForEach--;
            } while (true);

            Console.WriteLine((int)maxLForEach);
        }

    }



}
