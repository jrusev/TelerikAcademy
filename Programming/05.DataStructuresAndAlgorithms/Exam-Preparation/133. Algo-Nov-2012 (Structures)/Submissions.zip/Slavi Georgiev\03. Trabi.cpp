#include<cstdio>
//#include<iostream>
using namespace std;
int n;
 long long m, a[20001], mini=1;

bool canbe(const  long long &x)
{
    unsigned long long br=0;
    for(int i(0); i<n && br<m; ++i)br+=*(a+i)/x;
    if(br>=m)return true;
    return false;
}

 long long calc(const  long long &min, const  long long &max)
{
    unsigned long long mid=(min+max)/2;
    if(canbe(mid))
    {
        if(max-min<=1)if(canbe(max))return max; else if(canbe(min))return min; else return -1;
        else return calc(mid, max);
    }
    else return calc(min, mid-1);
}
int main()
{


    scanf("%d", &n);
    
    scanf("%u", &m);
    for(int i(0); i<n; ++i){ scanf("%u", a+i); if(*(a+i)>mini)mini=*(a+i); }
    //cout<<n<<" "<<m<<" "<<mini<<endl;
    //for(unsigned long long i(mini); i>0; --i)if(canbe(i)){ printf("%d\n", i); break; }
     long long res=calc(1LL, mini);
    printf("%lld\n", res);
    return 0;
}
