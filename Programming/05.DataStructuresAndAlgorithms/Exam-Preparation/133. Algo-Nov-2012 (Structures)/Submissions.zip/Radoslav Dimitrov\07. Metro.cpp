#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int main (){
    cout<<"OK"<<endl;
    return 0;
}
