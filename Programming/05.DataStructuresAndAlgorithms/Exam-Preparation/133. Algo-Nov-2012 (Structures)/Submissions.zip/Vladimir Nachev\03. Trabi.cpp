#include<iostream>
#include<stdio.h>
#include<algorithm>
using namespace std;
long long n, m, a[20001], b[20001], max1 = 0, s = 0, t = 0, y = 0, e = 0, ok = 0;
void in()
{ scanf("%llu", &n);
  scanf("%llu", &m);
  for (int i = 0; i < n; i++)
  { scanf("%llu", &a[i]); s += a[i]; }
}
 
void make()
{ sort(a, a + n);
  for (int i = n - 1; i >= 1; i--)
  if (a[i] % a[0] != 0)
  { ok++; break; }
   
  if (ok == 0) cout << a[0] << endl;
  else if (m > s) cout << "-1" << endl;
  else if (m == s) cout << "1" << endl;
  else
  { ok = 0;
    t = s / m;
    for (int i = t - 1; i >= 1; i--)
    { for (int j = n - 1; j >= 0; j--)
      { e += (a[j] / i);
        if (e > m)
        { ok++; break; }
         
        else if (e == m && j > 0)
        { if (a[j - 1] / i == 0)
          break;
          ok++; break;
         }
       }
       
      if (ok != 0 || e < m)
      { e = 0; ok = 0; }
       
      else if (e == m)
      { cout << i << endl; ok = -1; break; }
     }
     
    if (ok != -1) cout << "-1" << endl;
     
   }
}
 
int main()
{
  in();
  make();
   
  //cin >> n;
  return 0;
}
