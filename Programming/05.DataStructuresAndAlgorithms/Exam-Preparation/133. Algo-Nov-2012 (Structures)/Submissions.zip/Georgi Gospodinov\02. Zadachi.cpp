# include <iostream>
# include <vector>
# include <cstring>
# include <queue>

using namespace std;

struct task {

    int complexity;
    string name;
    bool issolved;

};

int main () {

    int n, i, j;
    cin >> n;

    vector <task> a;
    task t;

    queue <string> solved;
    string command;

    for ( i = 0 ; i < n ; i ++ ) {

         cin >> command;

         if ( command == "New" ) {

              cin >> t.complexity;
              cin >> t.name;

              t.issolved = 0;

              a.push_back (t);

         }

         else {

              int g = 0;

              for ( j = 0 ; j < a.size () ; j ++ )
              if ( !a[j].issolved ) {

                   g = 1;
                   break;

              }

              if ( g ) {

                   t.complexity = 2000000000;
                   t.name [0] = 'z' + 1;
                   t.name [1] = 'z' + 1;
                   t.name [2] = 'z' + 1;
                   t.name [4] = 'z' + 1;
                   t.name [5] = 'z' + 1;
                   t.name [6] = 'z' + 1;

                   for ( j = 0 ; j < a.size () ; j ++ )
                   if ( t.complexity > a[j].complexity && !a[j].issolved )
                   t = a [j];

                   for ( j = 0 ; j < a.size () ; j ++ )
                   if ( t.complexity == a[j].complexity && t.name > a[j].name && !a[j].issolved )
                   t = a [j];

                   solved.push ( t.name );

                   for ( j = 0 ; j < a.size () ; j ++ )
                   if ( t.complexity == a[j].complexity && t.name == a[j].name ) {

                        a [j].issolved = 1;
                        break;

                   }

              }

              else solved.push ( "Rest" );

         }

    }

    while ( solved.size ()) {

         cout << solved.front () << endl;
         solved.pop ();

    }

    return 0;

}