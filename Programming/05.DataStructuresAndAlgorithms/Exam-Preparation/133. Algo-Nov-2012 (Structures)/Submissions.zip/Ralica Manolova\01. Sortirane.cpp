#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
long long int n,x;
vector < long long > mv;
bool comp (long long i, long long j)
{
  if (i%x<j%x) {return true;}
  else
  if (i%x>j%x) {return false;}
  else{ if (i<j) return true; else return false;}
}
int main ()
{
 cin>>n>>x;
 for (int i=0; i<n; i++)
 {
   long long int v;
   cin>>v;
   mv.push_back (v);
 }
sort (mv.begin(), mv.end(), comp);
cout<<mv[0];
for (int i=1; i<mv.size(); i++)
{
  cout<<" "<<mv[i];
}
cout<<endl;
return 0;
}