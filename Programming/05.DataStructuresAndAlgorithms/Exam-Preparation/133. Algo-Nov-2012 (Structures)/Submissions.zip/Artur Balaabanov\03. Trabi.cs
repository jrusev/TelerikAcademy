using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tubes
{
    class Program
    {
        static void Main(string[] args)
        {
            long n = long.Parse(Console.ReadLine());
            long m = long.Parse(Console.ReadLine());

            List<long> tubes = new List<long>();
            long input = new long();

            decimal sum = 0;
            for (int i = 0; i < n; i++)
            {
                input = long.Parse(Console.ReadLine());
                tubes.Add(input);
                sum += input;
            }

            long theBiggest = tubes.Max();
            long average = (long)(sum / m);

            long result = -1L;
            long minR = average;
            long r;

            while (average > 0)
            {
                r = theBiggest % average;
                if (r < minR)
                {
                    minR = r;
                    result = average;
                }
                average--;
            }

            Console.WriteLine(result);
        }
    }
}
