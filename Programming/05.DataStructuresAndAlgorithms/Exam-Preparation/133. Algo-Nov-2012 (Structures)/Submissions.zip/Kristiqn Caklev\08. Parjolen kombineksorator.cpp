#include<cstdio>
int n,ans;
int A[6];
int _[4];
inline int abs(int A)
{return A<0?-A:A;}
int main()
{
	scanf("%d",&n);
	for(int i=0;i<n;++i)
	{
		for(int j=0;j<6;++j)
			scanf("%d",A+j);
		_[0]^=abs(A[2])-abs(A[0]);
		_[1]^=abs(A[3])-abs(A[1]);
		_[2]^=abs(A[4])-abs(A[0]);
		_[3]^=abs(A[5])-abs(A[1]);
	}
	printf("%d.%d00000\n",abs(_[0]*_[3]-_[1]*_[2])/2,abs(_[0]*_[3]-_[1]*_[2])%2*5);
	return 0;
}
