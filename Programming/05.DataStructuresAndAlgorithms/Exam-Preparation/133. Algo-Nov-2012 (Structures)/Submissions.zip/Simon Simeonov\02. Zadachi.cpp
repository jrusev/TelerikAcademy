#include <iostream>
#include <queue>
#include <string>
#include <vector>
#define maxn 50010

/*#include <windows.h>
#define stop system("pause");*/

using namespace std;
int br;

struct task{

	long long comp;
	string name;

	task();
	task(long long _comp, string _name){
		comp = _comp;
		name = _name;
	}


};

struct cmp{

	bool operator()( task a, task b ){
		if( a.comp > b.comp ) return true;
		else if(a.comp == b.comp) return a.name > b.name;
		else return false;
	}
};

queue <string> ans;

 priority_queue <task, vector<task>, cmp > taskque;


int main(){

	int n;

	string tek, tname;
	long long tcomp;

	cin>>n;

	for(int i = 0; i<n ; ++i){
		cin>>tek;
		if(tek[0] == 'N'){
			cin>>tcomp>>tname;
			taskque.push(task(tcomp, tname));
		}else{
			br++;
			if(taskque.empty()){
				ans.push("Rest");
			}else{
				ans.push(taskque.top().name);
				taskque.pop();
			}
		}

	}

	while(!ans.empty()){
		cout<<ans.front()<<endl;
		ans.pop();
	}

	return 0;

}
/*
15
New 5 tk
New 8 tn
New 8 taa
New 8 tb
New 8 t
Slove
Slove
Slove
Slove
New 1999999999 task
Slove
Slove
Slove
New 10 mine
Slove
*/
/*

10
New 4 tf
New 5 tfive
New 4 tff
Solve
Solve
Solve
Solve
New 1 t
New 1 t
Solve
*/









