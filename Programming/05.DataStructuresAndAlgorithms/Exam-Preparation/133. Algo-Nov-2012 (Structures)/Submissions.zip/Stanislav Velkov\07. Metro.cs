using System;

class Metrolol
{
    static void Main()
    {
        Console.WriteLine("OK");
    }
}