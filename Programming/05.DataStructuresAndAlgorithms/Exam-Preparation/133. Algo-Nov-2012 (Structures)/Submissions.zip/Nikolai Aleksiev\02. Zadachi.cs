using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    class GettingTasks
    {
        public int value { get; set; }
        public string name { get; set; }
    }

    //static List<string> Answers = new List<string>();
    static List<GettingTasks> allTasks = new List<GettingTasks>();
    static string finalOutput = "";
    private static void GetTask(string[] input)
    {
        GettingTasks newTask = new GettingTasks();
        newTask.value = int.Parse(input[1]);
        newTask.name = input[2];
        allTasks.Add(newTask);
    }

    private static void SolveProblem()
    {
        if (allTasks.Count > 0)
        {

            //allTasks = allTasks.OrderBy(si => si.name).ToList();
            allTasks = allTasks.OrderBy(si => si.value).ToList();
            finalOutput +=  allTasks[0].name.ToString() + "\n";
            allTasks.RemoveAt(0);
        }
        else
        {
            finalOutput += "Rest\n";
        }
        
    }

    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string[] input;
        for (int i = 0; i < n; i++)
        {
            input = Console.ReadLine().Split(' ');
            if (input.Length == 1)
            {
                SolveProblem();
            }
            else
            {
                GetTask(input);
            }
        }
        Console.WriteLine(finalOutput);
    }

       
}

