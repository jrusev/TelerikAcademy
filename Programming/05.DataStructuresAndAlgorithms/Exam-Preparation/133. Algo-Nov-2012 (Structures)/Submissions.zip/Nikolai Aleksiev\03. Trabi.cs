using System;

class Program
{
    static int n;
    static int m;
    static int[] pipes;
    //static int pipesSize = 0;
    static int count = 0;

    static void GetLongestSize(int size)
    {
        count = 0;
        for (int i = 0; i < n; i++)
        {
            count += (pipes[i] / size);
        }
        if (count < m)
        {
            Console.WriteLine(size - 1);
            return;
        }
        else
        {
            
            GetLongestSize(size + 1);
        }
    }
    static void Main()
    {
        n = int.Parse(Console.ReadLine());
        m = int.Parse(Console.ReadLine());
        pipes = new int[n];
        for (int i = 0; i < n; i++)
        {
            pipes[i] = int.Parse(Console.ReadLine());
        }
        int sumOfPipes = 0;
        for (int i = 0; i < n; i++)
        {
            sumOfPipes += pipes[i];
        }
        if (m > sumOfPipes)
        {
            Console.WriteLine("-1");
        }
        else
        {
            GetLongestSize(1);
        }
        
    }
}
