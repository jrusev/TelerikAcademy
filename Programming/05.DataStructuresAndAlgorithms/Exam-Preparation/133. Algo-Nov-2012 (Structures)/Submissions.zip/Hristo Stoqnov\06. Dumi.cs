using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Text;

namespace bgcoder
{
	class MainClass
	{
		List<string> lines;
		List<string> words;

		int count (string word)
		{
			SortedSet<string> ans = new SortedSet<string>();
			for (int i = 0; i < lines.Count; ++i) {
				string[] line = lines[i].Split(' ');
				for (int j = 0; j < line.Length; ++j) {
					if (line[j] != "") {
						bool broken = false;
						for (int k = 0; k < word.Length && !broken; ++k) {
							if (!line[j].Contains(word[k].ToString())) {
								broken = true;
							}
						}
						if (!broken) {
							ans.Add(line[j]);
						}
					}
				}
			}
			return ans.Count;
		}

		public static void Main (string[] args)
		{
			MainClass m = new MainClass ();
			m.lines = new List<string> ();
			m.words = new List<string> ();
			string input = Console.ReadLine ();
			int linesCount = int.Parse (input);
			for (int i = 0; i < linesCount; ++i) {
				input = Console.ReadLine ();
				char[] filteredChars = {
					',',
					'-',
					'!',
					'@',
					'#',
					'$',
					'%',
					'^',
					'&',
					'*',
					'(',
					')',
					'_',
					'+',
					'=',
					'{',
					'}',
					'[',
					']',
					':',
					';',
					'"',
					'\'',
					'?',
					'/',
					'.',
					'<',
					'>',
					'\\',
					'|'
				};
				m.lines.Add (new string(input.ToLower().ToList().Where (x => ('a' <= x && x <= 'z') || x == ' ').ToArray()));
			//	Console.WriteLine(m.lines.Last ());
			}
			input = Console.ReadLine ();
			int wordsCount = int.Parse (input);
			for (int i = 0; i < wordsCount; ++i) {
				input = Console.ReadLine ();
				m.words.Add (input);
			}
			foreach (var w in m.words) {
				Console.WriteLine("{0} -> {1}", w, m.count(w.ToLower()));
			}
		}
	}
}
