#include <cstdio>
int face;
int abs(int a) {
    if (a < 0) return -a;
    return a;
}
int main() {
    int n;
    scanf("%d", &n);
    int x1, x2, x3, y1, y2, y3;
    for (int i = 0; i < n; ++i) {
        scanf("%d %d %d %d %d %d", &x1, &y1, &x2, &y2, &x3, &y3);
        x2 -= x1;
        x3 -= x1;
        y2 -= y1;
        y3 -= y1;
        int curr = x2 * y3 - x3 * y2;
        face ^= abs(curr);
    }
    printf("%lf\n", (double)face / 2);
    return 0;
}