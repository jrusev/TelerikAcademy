#include <cstdio>
#include <queue>
using namespace std;

queue<char*> m;
queue<char*> k;
queue<char*> p;

char str[1 << 17][8];

int main() {
    int n;
    scanf("%d", &n);
    for (int i = 0;i < n; ++i) {
        scanf("%s", str[i]);
        if (str[i][0] == 'm') 
            m.push(str[i]);
        if (str[i][0] == 'k') 
            k.push(str[i]);
        if (str[i][0] == 'p') 
            p.push(str[i]);
    }
    bool firstGone = false;
    while (!m.empty()) {
        if (firstGone) printf(" ");
        printf("%s", m.front());
        firstGone = true;
        m.pop();
    }
    while (!k.empty()) {
        if (firstGone) printf(" ");
        printf("%s", k.front());
        firstGone = true;
        k.pop();
    }
    while (!p.empty()) {
        if (firstGone) printf(" ");
        printf("%s", p.front());
        firstGone = true;
        p.pop();
    }
    puts("");
    return 0;
}