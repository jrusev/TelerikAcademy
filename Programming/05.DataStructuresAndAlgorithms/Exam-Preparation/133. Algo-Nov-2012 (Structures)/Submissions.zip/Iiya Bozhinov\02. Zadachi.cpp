#include <iostream>
#include <map>
#include <string>
#include <vector>
#include <set>
using namespace std;
typedef long long lng ;
int main() {

int n;
cin>>n;
string command;
lng complexity;
string name;
multimap<lng,string>map = multimap<lng,string>() ;
vector<string> couts ;
for(int dafuq=0;dafuq<n;dafuq++){
    cin>>command ;
    if(command=="New"){
        cin>>complexity ;
        cin>>name ;
        map.insert(pair<lng,string>(complexity,name)) ;
    }else if(!map.empty()){
        multimap<lng,string>::iterator it=map.begin() ;
        if(map.count((*it).first)>1){
            multiset<string> set=multiset<string>() ;
            lng countOfEqual=map.count((*it).first);
            lng max=countOfEqual ;
            while(max>0){
                set.insert((*it).second) ;
                max-- ;it++ ;
            }max=(*map.begin()).first ;
            couts.push_back(*set.begin()) ;
            map.erase(max) ;
            multiset<string>::iterator is=set.begin() ;
            is++ ;
            for(int i=0;i<countOfEqual-1;i++){
                map.insert(pair<lng,string>(max,*is)) ;is++ ;
            }
        }else
        {
            couts.push_back((*map.begin()).second) ;
            map.erase((*map.begin()).first) ;
        }
    }else couts.push_back("Rest") ;


}for(int i=0;i<couts.size();i++)cout<<couts[i]<<endl;
return 0;
}
/*
10
New 5 tk
New 8 tn
New 8 taa
New 8 tb
New 8 t
Solve
Solve
Solve
Solve
New 1999999999 task
*/
