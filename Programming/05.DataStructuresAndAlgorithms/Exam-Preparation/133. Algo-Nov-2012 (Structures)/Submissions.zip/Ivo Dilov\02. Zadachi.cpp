#include <iostream>
#include <cstdio>
#include <queue>
#include <string>
#include <vector>
using namespace std;
struct zad{
    int s;
    string name;
    bool operator()(zad a,zad b){
        if (a.s==b.s){return a.name>b.name;}
        return a.s>b.s;
    }
};
priority_queue<zad,vector<zad>,zad> a;
int n;
string op;
zad tek;
int main(){
    cin>>n;
    for (int i=0;i<n;++i){
        //scanf("%s",&op);
        cin>>op;
        if (op[0]=='N'){

            cin>>tek.s>>tek.name;
            //cin>>tek.s>>tek.name;
            a.push(tek);
        }
        else{
            if (a.empty()){cout<<"Rest\n";}
            else{cout<<a.top().name<<endl;a.pop();}
        }
    }
    return 0;
}
