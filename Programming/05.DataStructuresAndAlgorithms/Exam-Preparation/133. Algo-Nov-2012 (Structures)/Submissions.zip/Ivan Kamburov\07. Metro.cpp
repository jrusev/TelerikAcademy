#include <stdio.h>
 
using namespace std;
 
int main()
{
    printf("OK\n");
 
    return 0;
}
