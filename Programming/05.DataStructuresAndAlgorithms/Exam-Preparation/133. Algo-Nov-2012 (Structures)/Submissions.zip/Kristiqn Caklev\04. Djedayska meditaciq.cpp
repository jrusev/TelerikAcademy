#include<cstdio>
#include<queue>
int n;
char A[100042][16];
std::queue<int> m,k,p;
int main()
{
	scanf("%d",&n);
	for(int i=0;i<n;++i)
	{
		scanf("%s",A[i]);
		if(A[i][0]=='m')m.push(i);
		else if(A[i][0]=='k')k.push(i);
		else p.push(i);
	}
	bool f=false;
	while(!m.empty())
	{
		if(f)putchar(32);
		f=true;
		printf("%s",A[m.front()]);
		m.pop();
	}
	while(!k.empty())
	{
		if(f)putchar(32);
		f=true;
		printf("%s",A[k.front()]);
		k.pop();
	}
	while(!p.empty())
	{
		if(f)putchar(32);
		f=true;
		printf("%s",A[p.front()]);
		p.pop();
	}
	puts("");
	return 0;
}
