# include <iostream>
# include <algorithm>

using namespace std;

unsigned long x;

bool f ( unsigned long a, unsigned long b ) {

    return a < b;

}

bool f2 ( unsigned long a, unsigned long b ) {

    return a%x < b%x;

}

int main () {

    unsigned long n, i;
    cin >> n >> x;

    unsigned long num [n];

    for ( i = 0 ; i < n ; i ++ )
    cin >> num [i];

    sort ( num, num + n, f );
    sort ( num, num + n, f2 );

    for ( i = 0 ; i < n ; i ++ )
    cout << num [i] << " ";

    cout << endl;

    return 0;

}