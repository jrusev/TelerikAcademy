#include <iostream>
#include <string>
using namespace std;
string s;
long long n,m,i;
int main () {
    cin>>n;
   for(i=1;i<=n/2;i++) {
    cin>>s;
   }
   cin>>n;

   for(i=1;i<=n;i++) {
    cin>>s;
   }
   cout<<"OK"<<endl;
  return 0;
}
