#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
string a[10000], b[1000], d[1000], c, gl;
bool ins(string d, string e)
{
     int i, x=d.size(), br=0, y, z=e.size();
     sort (e.begin(), e.end());
     for (i=0;i<x;i++)
     {
         y=e.find(d[i], br);
         if (y==-1) return false;
         else br=y;
     }
     return true;
}
int main ()
{
    int T, W, i, x, j;
    unsigned long long br[1001]={0};
    char h;
    cin>>T;
    for (i=0;i<=T;i++)
    {
        getline(cin, a[i]);
        x=a[i].size();
        for (j=0;j<x;j++)
            if (a[i][j]>='A'&&a[i][j]<='Z') a[i][j]=a[i][j]-'A'+'a';
        a[i]=a[i]+' ';
    }
    cin>>W;
    for (i=0;i<=W;i++)
    {
        getline(cin, b[i]);
        d[i]=b[i];
        x=b[i].size();
        for (j=0;j<x;j++)
            if (b[i][j]>='A'&&b[i][j]<='Z') b[i][j]=b[i][j]-'A'+'a';
        sort (b[i].begin(), b[i].end());
    }
    for (i=1;i<=T;i++)
        while (a[i].find(' ')!=-1)
        {
              c=a[i].substr(0, a[i].find(' '));
              if (gl.find(c)==-1) {for (j=1;j<=W;j++)
                                      if (ins(b[j], c)==1) br[j]++;
                                   gl=gl+" "+c;}
              a[i].erase(0, a[i].find(' ')+1);
        }
    for (i=1;i<=W;i++)
        cout<<d[i]<<" -> "<<br[i]<<endl;
    //system ("pause");
    return 0;
}