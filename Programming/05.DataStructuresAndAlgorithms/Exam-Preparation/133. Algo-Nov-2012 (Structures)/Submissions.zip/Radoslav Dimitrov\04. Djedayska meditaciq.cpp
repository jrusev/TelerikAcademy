#include<iostream>
#include<queue>
using namespace std;
int main()
{
    long n;
    queue<int> m;
    queue<int> k;
    queue<int> p;
    char c;
    int a;
    cin>>n;
    for(int i=0;i<n;i++)
    {
            cin>>c>>a;
            if(c=='m')m.push(a);
            if(c=='k')k.push(a);
            if(c=='p')p.push(a);
    }
    while(!m.empty())
    {
          cout<<"m"<<m.front()<< " ";
          m.pop();
    }
    while(!k.empty())
    {
          cout<<"k"<<k.front()<< " ";
          k.pop();
    }
    while(!p.empty())
    {
          cout<<"p"<<p.front()<< " ";
          p.pop();
    }
    cout<<endl;
    //system("pause");
    return 0;
}
