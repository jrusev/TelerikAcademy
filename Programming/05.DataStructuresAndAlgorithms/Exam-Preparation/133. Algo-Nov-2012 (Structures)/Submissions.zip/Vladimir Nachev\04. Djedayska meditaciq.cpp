#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<string.h>
using namespace std;
int n, br = 0, ok = 0, t = 0, y = 0, y1 = 0, y2 = 0;
char a[100000][101], b[100000][101], c[100000][101], d[100000][101];
void in()
{ scanf("%d", &n);
  for (int i = 0; i < n; i++)
  cin >> a[i];
}
 
void make()
{ for (int i = 0; i < n; i++)
  { if (a[i][0] == 'p')
    strcpy(b[y++], a[i]);
     
    else if (a[i][0] == 'm')
    strcpy(c[y1++], a[i]);
    
    else if (a[i][0] == 'k')
    strcpy(d[y2++], a[i]);
   }
   
  for (int i = 0; i < y1; i++)
  printf("%s ", c[i]);
   
  for (int i = 0; i < y2; i++)
  printf("%s ", d[i]);
   
  for (int i = 0; i < y - 1; i++)
  printf("%s ", b[i]);
  printf("%s\n", b[y - 1]);
}

int main()
{ 
  in();
  make();
  
  //cin >> n;
  return 0;
}
