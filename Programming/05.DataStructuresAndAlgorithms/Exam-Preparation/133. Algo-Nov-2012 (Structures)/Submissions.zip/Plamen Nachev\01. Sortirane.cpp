#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

int N;
long long X;

struct list
{ 
  long long a, b;
};
list p[100000];


bool sort1( list l1, list l2 )
{ 
  if( l1.b == l2.b )  return l1.a < l2.a;
  return l1.b < l2.b;
}


int main()
{ 
  scanf("%d %I64d", &N, &X);
  
  for( int i = 0; i < N; i++ )
  { 
    scanf("%I64d", &p[i].a);
    p[i].b = p[i].a%X;
   }
  
  sort(p, p+N, sort1);
  
  for( int i = 0; i < N-1; i++ )
  printf("%I64d ", p[i].a);
  printf("%I64d\n", p[N-1].a);
  
  //scanf("%d", &N);
  return 0;
}
