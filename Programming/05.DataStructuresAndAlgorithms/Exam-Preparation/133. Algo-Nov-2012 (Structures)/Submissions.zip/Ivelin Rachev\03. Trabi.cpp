#include<iostream>
#include<vector>
using namespace std;
int n;
unsigned long long m;
unsigned long long a[30000];
bool good (unsigned long long len)
{
  unsigned long long all=0;
  for(int i=0;i<n;i++)all+=a[i]/len;
  if(all>=m)return 1;
  return 0;
}
int main()
{
  cin>>n>>m;
  unsigned long long l=1,r=0;
  for(int i=0;i<n;i++)
    {cin>>a[i];r+=a[i];}
  if(good(1)==0)cout<<"-1"<<endl;
  r/=m;
  r++;
  while(r>l+1)
  {
  //  cout<<l<<" "<<r<<endl;
    if(good((l+r)/2))l=(l+r)/2;
    else
    r=(l+r)/2;
  }
  cout<<(r+l)/2<<endl;
  return 0;
}
