#include <cstdio>
#include <cstring>
#include <queue>
using namespace std;
int n;
struct Task {
    char name[8];
    int nameLen;
    int complexity;
};
bool operator<(Task a, Task b) {
    if (a.complexity < b.complexity) return false;
    if (b.complexity < a.complexity) return true;

    int len = min(a.nameLen, b.nameLen) + 1;
    for (int i = 0; i < len; ++i) {
        if (a.name[i] < b.name[i]) return false;
        if (b.name[i] < a.name[i]) return true;
    }
    return true;
}
priority_queue<Task> que;
int main() {
    setvbuf(stdin, NULL, _IOFBF, 1 << 20);
    setvbuf(stdout, NULL, _IOFBF, 1 << 20);
    scanf("%d", &n);
    char q[8];
    Task t;
    for (int i = 0; i < n; ++i) {
        scanf("%s", q);
        if ('N' == q[0]) {
            scanf("%d %s", &t.complexity, t.name);
            t.nameLen = strlen(t.name);
            que.push(t);
        } else {
            if (que.empty()) {
                puts("Rest");
            } else {
                printf("%s\n", que.top().name);
                que.pop();
            }
        }
    }
    return 0;
}