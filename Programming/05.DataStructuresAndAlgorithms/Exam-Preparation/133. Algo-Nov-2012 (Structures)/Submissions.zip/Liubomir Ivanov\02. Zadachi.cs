using System;
using System.Collections.Generic;
using System.Linq;
using Wintellect.PowerCollections;
using System.Text;
using System.Threading.Tasks;

class Tasks 
{
    class Commands : IComparable<Commands>
    {
        private string command;
        public Commands(string s)
        {
            this.command = s;
        }
        public string Command
        {
            get
            {
                return this.command;
            }
            set
            {
                this.command = value;
            }
        }
        public int CompareTo(Commands other)
        {
            string[] a = this.Command.Split(' ');
            string[] b = other.Command.Split(' ');
            int complexityA = int.Parse(a[1]);
            int complexityB = int.Parse(b[1]);
            if ( complexityA < complexityB)
            {
                return -1;
            }
            else if (complexityA > complexityB)
            {
                return 1;
            }
            else
            {
                return a[2].CompareTo(b[2]);
            }
        }
    }
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        OrderedBag<Commands> priorityQueue = new OrderedBag<Commands>();
        string result = "";
        for (int i = 0; i < n; i++)
        {
            string s = Console.ReadLine();
            if (s == "Solve")
            {
                if (priorityQueue.Count == 0)
                {
                    result += "Rest\n";
                }
                else
                {
                    string[] x = priorityQueue.RemoveFirst().Command.Split(' ');
                    result += x[2];
                    result += "\n";
                }
            }
            else
            {
                priorityQueue.Add(new Commands(s));
            }
        }
        Console.Write(result);
    }
}
