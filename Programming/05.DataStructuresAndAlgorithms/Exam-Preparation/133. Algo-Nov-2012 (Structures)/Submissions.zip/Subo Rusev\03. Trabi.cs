using System;
using System.Collections.Generic;

class Pipes
{
    static uint check(uint[] arr, uint n, uint d)
    {
        uint count = 0;

        for (int i = 0; i < n; i++)
            count += (arr[i] / d);

        return count;
    }

    static uint binarySearch(uint[] arr, uint n, uint k)
    {
        uint left = 0;
        uint right = uint.MaxValue;

        while (left < right)
        {
            uint mid = (left + right) / 2;
            if (check(arr, n, mid) >= k)
                left = mid + 1;
            else
                right = mid;
        }

        return left - 1;
    }
    static void Main()
    {
        ushort numOfPipes = ushort.Parse(Console.ReadLine()); //number of pipes
        uint sizeOfPipes = uint.Parse(Console.ReadLine());
        uint[] pipes = new uint[numOfPipes];
        for (int i = 0; i < numOfPipes; i++)
        {
            pipes[i] = uint.Parse(Console.ReadLine());
        }




        uint result;

        result = binarySearch(pipes, numOfPipes, sizeOfPipes);

        Console.WriteLine(result);

    }

}
