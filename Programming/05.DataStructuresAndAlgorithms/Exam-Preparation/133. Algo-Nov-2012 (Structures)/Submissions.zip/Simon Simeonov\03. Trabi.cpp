#include<cstdio>
#define maxn 20010
using namespace std;

int n, m;
int a[maxn];

int equip(int s){
	int br = 0;
	for(int i = 0; i<n; ++i){
		br += a[i] / s;
	}
	return br;
}


int main(){
	int l, r, max = 0, mid;


	scanf("%d %d", &n, &m);

	for(int i = 0; i<n; ++i){
		scanf("%d", a+i);
		if(a[i] > max) max= a[i];


	}

	//printf("%d\n", equip(100));

	l = 1;
	r = max;
	while(r - l > 3){
		mid = (l+r) >> 1;
		if(equip(mid) >= m){
			l = mid;
		}else r = mid;
	}
	for(int i = r; i>=l; --i){
		if(equip(i) == m){
			printf("%d\n", i);
			break;
		}
	}

	return 0;
}
