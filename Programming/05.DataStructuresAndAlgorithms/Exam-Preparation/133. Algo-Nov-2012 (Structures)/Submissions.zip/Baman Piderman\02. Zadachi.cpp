#include <iostream>
using namespace std;
struct wii {string name;unsigned long time;};
wii b[50001];
int main ()
{
    unsigned int N, i, j, k, x, br=0, z, l;
    string a;
    string y;
    cin>>N;
    for (i=0;i<N;i++)
    {
        cin>>a;
        if (a=="New") {cin>>x>>y;
                       j=0;
                       while (j<br&&x>b[j].time)
                             j++;
                       if (j!=br) {for (k=N;k>j;k--)
                                   {
                                       b[k+1].name=b[k].name;
                                       b[k+1].time=b[k].time;
                                   }
                                   b[j+1].name=y;
                                   b[j+1].time=x;
                                   if (b[j+1].time==b[j].time) {l=0;x=b[j+1].name.size();z=b[j].name.size();
                                                                while (b[j].name[l]==b[j+1].name[l]&&l<x&&l<z)
                                                                      l++;
                                                                if (l==x) {swap (b[j].name, b[j+1].name);
                                                                           swap (b[j].time, b[j+1].time);}
                                                                else if (l!=z&&b[j].name[l]>b[j+1].name[l]) {swap (b[j].name, b[j+1].name);
                                                                                                             swap (b[j].time, b[j+1].time);}
                                                               }
                                                                                    
                                  }
                       else {b[br].time=x;b[br].name=y;}
                       br++;
                      }
        else {if (br>0) {cout<<b[0].name<<endl;
                         for (j=0;j<br;j++)
                         {
                             b[j].name=b[j+1].name;
                             b[j].time=b[j+1].time;
                         }
                         br--;
                        }
               else cout<<"Rest"<<endl;
              }
    }
    //system ("pause");
    return 0;
}