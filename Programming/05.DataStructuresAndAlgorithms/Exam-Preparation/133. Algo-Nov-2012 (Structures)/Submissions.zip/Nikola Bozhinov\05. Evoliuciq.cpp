#include<iostream>
#include<vector>
#include<cmath>
#include<algorithm>
using namespace std;
struct Mine{
    int a;
    int b;
};
struct Comparer{
    bool operator()(Mine one,Mine two){
        return one.a<two.a;
    }
};
struct intComparer{
    bool operator()(Mine one,Mine two){
        return ((one.b==two.b && one.a<two.a) || one.b<two.b);
    }
};
struct Point{
    int x;
    int y;
    int aver(Point p[],int n){
        int min=120;
        for (int i=0;i<n;i++){
            if((abs(x-p[i].x)+abs(y-p[i].y))<min)
                min=abs(x-p[i].x)+abs(y-p[i].y);
        }
        return min;
    }
};
int main(){
    int N,Kmin,Kmax,R,T,vod,hr,av;
    cin>>N>>Kmin>>Kmax;
    char c;
    vector <Mine> v;
    Mine res;
    for(int i=0;i<N;i++){
        cin>>R>>T;
        vod=0;
        hr=0;
        Point tempzv[10];
        Point tempdi[10];
        for (int j=0;j<R;j++)
            for(int t=0;t<T;t++){
                cin>>c;
                if(c=='*'){
                    tempzv[vod].x=j;
                    tempzv[vod].y=t;
                    vod++;
                } else if(c=='#'){
                    tempdi[hr].x=j;
                    tempdi[hr].y=t;
                    hr++;
                }
            }
            av=0;
        for(int temp=0;temp<vod;temp++){
            av+=tempzv[temp].aver(tempdi,hr);
        }
        res.a=i+1;
        res.b=av/vod;
        if (vod-1>2*(hr-1))
            res.b=100000;
        else if(hr-1>2*(vod-1))
            res.b=0;
        v.push_back(res);
    }
    sort(v.begin(),v.end(),intComparer());
    sort(v.begin(),v.begin()+Kmax,Comparer());
    sort(v.end()-Kmin,v.end(),Comparer());
    for(int i=0;i<Kmax;i++){
        cout<<v[i].a<<" ";
    }
    cout<<endl;
    for(int i=v.size()-Kmin;i<v.size();i++){
        cout<<v[i].a<<" ";
    }
    return 0;
}