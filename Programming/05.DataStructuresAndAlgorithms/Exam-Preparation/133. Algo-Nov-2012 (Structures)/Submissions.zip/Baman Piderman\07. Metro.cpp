#include<iostream>
using namespace std;
int main()
{
    long long n;
    cout<<"OK"<<endl;
    return 0;
}