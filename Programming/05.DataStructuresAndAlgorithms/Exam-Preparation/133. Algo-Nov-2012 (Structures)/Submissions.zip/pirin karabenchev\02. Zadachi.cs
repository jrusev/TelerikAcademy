using System;
using Wintellect.PowerCollections;
using System.Collections.Generic;

class Tasks
{
    class Task : IComparable<Task>
    {
        public int complexity;
        public string name;

        public Task(int complexity, string name)
        {
            this.complexity = complexity;
            this.name = name;
        }

        public Task()
        {
            new Task(0, "");
        }

        public int CompareTo(Task other)
        {
            if (this.complexity == other.complexity)
            {
                return this.name.CompareTo(other.name);
            }
            else
            {
                return ((this.complexity > other.complexity) ? 1 : -1);
            }
        }
    }

    static void Main()
    {
        string input = Console.ReadLine();
        string[] command;
        int n = int.Parse(input);
        Task currentTask = new Task();
        OrderedBag<Task> tasks = new OrderedBag<Task>();
        for (int i = 0; i < n; i++)
        {
            input = Console.ReadLine();
            command = input.Split();
            if (command[0] == "New")
            {
                currentTask.complexity = int.Parse(command[1]);
                currentTask.name = command[2];
                tasks.Add(new Task(currentTask.complexity, currentTask.name));
            }
            if (command[0] == "Solve")
            {
                if (tasks.Count > 0)
                {
                    Console.WriteLine(tasks.RemoveFirst().name);
                }
                else
                {
                    Console.WriteLine("Rest");
                }
            }
        }
    }
}