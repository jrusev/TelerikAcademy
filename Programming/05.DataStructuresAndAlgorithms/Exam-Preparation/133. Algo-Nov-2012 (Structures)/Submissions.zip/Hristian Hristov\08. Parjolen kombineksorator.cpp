#include <iostream>
#include <map>
#include <cstdio>
using namespace std;


float area(int a, int b, int c, int d, int e, int f)
{
      return (a*d+b*e+c*f-d*e-a*f-b*c)/2.0;
}
map<float,int> m;
float s[200000];
int main()
{
    int n;
    scanf("%d", &n);
    
    int a,b,c,d,e,f;
    //float s;
    for(int i=0; i<n; i++)
    {
            scanf("%d%d%d%d%d%d", &a, &b, &c, &d, &e, &f);
            s[i]=area(a,b,c,d,e,f);
            m[s[i]]++;
    }
    
    for(int i=0; i<n; i++)
    {
            if(m[s[i]]==1){ printf("%.6f\n", s[i]);  return 0; }
    }
    
    printf("%.6f\n", s[0]);
    return 0;
}
    
