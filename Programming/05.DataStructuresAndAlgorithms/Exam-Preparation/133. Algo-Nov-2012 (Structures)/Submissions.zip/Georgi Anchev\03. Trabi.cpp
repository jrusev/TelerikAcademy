#include<iostream>
using namespace std;
unsigned long long n,m,trubi[20000];
int broi(int stoinost){
    unsigned long long sum=0;
    for(int br=0;br<n;br++){
        sum+=trubi[br]/stoinost;
    }
    return sum;
}
int main(){
    cin>>n>>m;
    int i;
    unsigned long long  min=1,max=0;
    for(i=0;i<n;i++){
        cin>>trubi[i];
        if(trubi[i]>max)max=trubi[i];
    }
    //dvoi4no
//cout<<endl<<min<<endl<<max<<endl;
    for(i=0;max-min>5;i++){
        if(broi((min+max)/2)<m)max=(min+max)/2;
        else min=(min+max)/2;
        //cout<<min<<endl<<max<<endl;
    }
    int otg=0;
    for(i=min;i<=max;i++){
        //if(i==m)cout<<"da\n";
        if(broi(i)==m&&i>otg){otg=i;}
    }
    cout<<otg<<endl;
    return 0;
}
