#include <iostream>
#include <algorithm>
#include <queue>
#include<string>
using namespace std;
long long d,n,it;
char a;
queue<long long> p,m,k;
int main () {

   cin>>n;

  for(it=1;it<=n;it++) {

    cin>>a>>d;
    if(a=='m') {
     m.push(d);
    }
    else {
    if(a=='k') {
     k.push(d);
    }

    if(a=='p') {
     p.push(d);
    }
    }




  }

 while(!m.empty()) {
  cout<<'m'<<m.front()<<" ";
  m.pop();
 }

 while(!k.empty()) {
  cout<<'k'<<k.front()<<" ";
  k.pop();
 }

 while(!p.empty()) {
  cout<<'p'<<p.front()<<" ";
  p.pop();
 }
  return 0;

}
