using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Sort
{
    public static uint x;
    public static int CustomCompare(uint a, uint b)
    {
        int result = (a%x).CompareTo(b%x);
        if (result == 0)
        {
            result = a.CompareTo(b);
        }
        return result;
    }
    static void Main(string[] args)
    {
        List<uint> numbers = new List<uint>();
        uint n;
        //uint x;
        {
            string[] s = Console.ReadLine().Split(' ');
            n = uint.Parse(s[0]);
            x = uint.Parse(s[1]);
        }
        {
            string[] s = Console.ReadLine().Split(' ');
            for (uint i = 0; i < n; i++)
            {
                numbers.Add(uint.Parse(s[i]));
            }
        }
        //numbers.Sort();
        //numbers.Sort((a, b) => (a % x).CompareTo(b % x));
        numbers.Sort(CustomCompare);
        foreach (var item in numbers)
        {
            Console.Write("{0} ", item);
        }
    }
}