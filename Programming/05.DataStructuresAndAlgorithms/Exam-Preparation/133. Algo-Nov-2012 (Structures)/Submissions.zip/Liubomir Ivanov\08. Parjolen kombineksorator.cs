using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Stakes
{
    //class Triangles
    //{
    //    double[] sides;
    //    Triangles(double[] sides)
    //    {
    //        this.sides = sides;
    //    }
    //}
    public static double[] getInput()
    { 
        double[] sides = new double[3];
        string[] s = Console.ReadLine().Split(' ');
        int xA = int.Parse(s[0]);
        int yA = int.Parse(s[1]);
        int xB = int.Parse(s[2]);
        int yB = int.Parse(s[3]);
        int xC = int.Parse(s[4]);
        int yC = int.Parse(s[5]);
        sides[0] = Math.Sqrt((xB - xC) * (xB - xC) + (yB - yC) * (yB - yC));
        sides[1] = Math.Sqrt((xA - xC) * (xA - xC) + (yA - yC) * (yA - yC));
        sides[2] = Math.Sqrt((xB - xA) * (xB - xA) + (yB - yA) * (yB - yA));
        Array.Sort(sides);
        return sides;
    }
    
    static void Main(string[] args)
    {
        List<double[]> list = new List<double[]>();
        double area=0;
        double perim;
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            list.Add(getInput());
        }
        double[] triangle;
        do
        {
            int p = list.Count - 1;
            triangle = list[p];
            list.RemoveAt(p);
            bool flag = true;
            for (int i = 0; i < p ; i++)
            {
                if (triangle[0] == list[i][0] && triangle[1] == list[i][1] && triangle[2] == list[i][2])
                {
                    list.RemoveAt(i);
                    flag = false;
                    break;
                }
            }
            if (flag == true)
            {
                perim = triangle[0] + triangle[1] + triangle[2];
                perim /= 2;
                area = Math.Sqrt(perim * (perim - triangle[0]) * (perim - triangle[1]) * (perim - triangle[2]));
                break;
            }
        } while (list.Count != 0);
        //if (iter == 1)
        //{
        //    p = sides2[0] + sides2[1] + sides2[2];
        //    p /= 2;
        //    area = Math.Sqrt(p * (p - sides2[0]) * (p - sides2[1]) * (p - sides2[2]));
        //    Console.WriteLine(area);
        //    return;
        //}
        //p = sides1[0] + sides1[1] + sides1[2];
        //p /= 2;
        //area = Math.Sqrt(p * (p - sides1[0]) * (p - sides1[1]) * (p - sides1[2]));
        Console.WriteLine("{0:0.000000}",area);
    }
}