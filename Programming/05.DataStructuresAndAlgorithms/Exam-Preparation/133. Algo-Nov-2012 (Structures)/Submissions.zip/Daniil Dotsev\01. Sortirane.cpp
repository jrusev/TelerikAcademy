#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
long long n,x,i;
pair<long long, long long> a[131072];
bool cmp(pair<long long, long long> a, pair<long long, long long> b)
{
    if(a.second<b.second) return 1;
    if(a.second>b.second)return 0;
    if(a.first>b.first) return 0;
    return 1;
}
int main()
{
    scanf("%lld%lld",&n,&x);
    for(i=1;i<=n;i++)
    {
        scanf("%lld",&a[i].first);
        a[i].second=a[i].first%x;
    }
    sort(a+1,a+n+1,cmp);
    for(i=1;i<n;i++)
    {
        printf("%lld ",a[i].first);
    }
    printf("%lld\n",a[n].first-1);
    return 0;
}
//Почнах късно