#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
long long n,m,a,it;
vector<long long > myvector;
bool myfunction (long long i,long long j) {
     if (i%m==j%m) {
      return i<j;
     }
      return i%m<j%m;
}

int main () {
   cin>>n>>m;
  for(it=1;it<=n;it++) {
   cin >> a;
    myvector.push_back (a);

  }
vector<int>::size_type  sz=myvector.size();
if(m!=1) {
 sort (myvector.begin(), myvector.end(), myfunction);
 }
if(m==1) {
 sort (myvector.begin(), myvector.end());
 }

if(m==1) {
 sort (myvector.begin(), myvector.end());
 }
 for (it=0; it<=sz-1;++it)
    cout <<myvector[it]<<" ";
  cout<<endl;
  return 0;
}
