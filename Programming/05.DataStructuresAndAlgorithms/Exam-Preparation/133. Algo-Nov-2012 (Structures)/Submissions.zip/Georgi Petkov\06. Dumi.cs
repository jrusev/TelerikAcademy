using System;
using System.Collections.Generic;

class Words
{
    static void Main()
    {
        HashSet<string> uniqueWords = new HashSet<string>();
        int T = Int32.Parse(Console.ReadLine());
        for (int i = 0; i < T; ++i)
        {
            string[] words = Console.ReadLine().Split(' ');
            for (int j = 0; j < words.Length; ++j)
            {
                uniqueWords.Add(words[j].Trim().ToLower());
            }
        }

        int W = Int32.Parse(Console.ReadLine());

        for (int i = 0; i < W; ++i)
        {
            string input = Console.ReadLine().Trim();
            string lowerInput = input.ToLower();
            int count = 0;
            bool flag;
            foreach (string word in uniqueWords)
            {
                flag = true;
                foreach (char c in lowerInput)
                //for(int k = 0; k < lowerInput.Length; ++k)
                 {
                    if (word.IndexOf(c/*lowerInput[k]*/) == -1)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag)
                {
                    ++count;
                }
            }

            Console.Write(input);
            Console.Write(" -> ");
            Console.WriteLine(count);
        }

        /*foreach (string word in uniqueWords)
        {
            Console.WriteLine(word);
        }*/
    }
}