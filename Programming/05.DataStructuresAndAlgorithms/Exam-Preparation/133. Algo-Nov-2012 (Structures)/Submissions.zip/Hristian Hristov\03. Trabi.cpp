#include <iostream>
#include <vector>
#include <queue>
#include <stack>
#include <cmath>
#include <cstdio>
using namespace std;

long long n,m;
long long a[1<<16];


bool go(long long g)
{
     long long res=0;
     for(int i=0; i<n; i++)
     {
             res+=a[i]/g;
             if(res>=m) return true;
     }
     
     return false;
}
int main()
{
    cin >> n >> m;
    for(int i=0; i<n; i++) cin >> a[i];
    
    long long res=-1;
    
    long long l=1, r=20*n*2000000+1;
    long long mid;
    bool ok;
    do
    {
         mid=(l+r)/2;
         ok=go(mid);
         //cout << l  << ' ' << r << ' ' <<  mid << ' ' << ok << endl;
         if(ok){
                res=mid;
                l=mid+1;
                }
         else {
              r=mid-1;
              }
    }
    while(l<=r);
    
    cout << res << endl;
    return 0;
}
         
         
    
