# include <iostream>

using namespace std;

int main () {

    unsigned long n, m, i, sum = 0, t;
    cin >> n >> m;

    for ( i = 0 ; i < n ; i ++, sum += t )
    cin >> t;

    sum /= m;

    cout << sum << endl;

    return 0;

}