using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Text;

namespace JediMeditation
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<Jedi> line = new List<Jedi>();
            StringBuilder sb = new StringBuilder();
            string input;
            string[] inputs;

            input = Console.ReadLine();
            inputs = Regex.Split(input, " ");
            foreach (var item in inputs)
            {


                switch (item[0])
                {
                    case 'm': line.Add(new Jedi()); line[line.Count - 1].degree = 1; break; // master
                    case 'k': line.Add(new Jedi()); line[line.Count - 1].degree = 2; break; //knight
                    case 'p': line.Add(new Jedi()); line[line.Count - 1].degree = 3; break; //padawan
                    default: break;
                }

                for (int j = 1; j < item.Length; j++)
                {
                    sb.Append(item[j]);
                }
                line[line.Count - 1].rank = Convert.ToInt32(sb.ToString());
                sb.Clear();

            }

            int mastery = 1, rank = 1;

            for (int i = 1; i <= 3 ; i++)//mastery
            {
                for (int k = 0; k < n; k++)//number jedis
                {
                    for (int j = 0; j < n; j++)//line of jedis
                    {
                        if (line[j].degree == mastery && line[j].rank == rank)
                        {

                            switch (mastery)
                            {
                                case 1: sb.Append("m"); break;//Console.Write("m"); break;
                                case 2: sb.Append("k"); break;//Console.Write("k"); break;
                                case 3: sb.Append("p"); break;//Console.Write("p"); break;
                                default: break;
                            }
                            sb.Append(rank.ToString());
                            sb.Append(" ");
                            //Console.Write(rank + " ");
                            rank++;
                        }
                    }
                }

                mastery++; rank = 1;
            }
            Console.WriteLine(sb.ToString());
        }
        
        
    }

    class Jedi
    {
        public int degree { set; get; } //1 - master 2 - knight 3 - padawan
        public int rank { get; set; }
    }
}
