#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
long long N,X;
struct intComparer{
	bool operator()(long long a,long long b){
		return ((a%X)<(b%X) || ((a%X)==(b%X) && a<b));
	}
};
int main(){
	cin>>N>>X;
	long long p;
	vector<long long> v;
	for(int i=0;i<N;i++){
		cin>>p;
		v.push_back(p);
	}
	sort(v.begin(),v.end(),intComparer());
	//sort(v.begin(),v.end(),extraComparer());
	for(int i=0;i<N;i++){
		cout<<v[i]<<" ";
	}
	return 0;
}