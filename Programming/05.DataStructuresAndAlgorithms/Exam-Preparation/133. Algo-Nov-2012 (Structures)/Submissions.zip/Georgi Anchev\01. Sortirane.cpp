#include<iostream>
#include<algorithm>
#include <stdio.h>
using namespace std;
unsigned long long x;

bool myfunc(unsigned long long a,unsigned long long b){
    if((a%x<b%x)||((a%x==b%x)&&a<b))return true;

    return false;
}

int main(){
    unsigned long long n,i;
    cin>>n>>x;
    unsigned long long A[n];
    for(i=0;i<n;i++)scanf("%llu",&A[i]);
    sort(A,A+n,myfunc);
    cout<<A[0];
    for(i=1;i<n;i++)printf(" %llu",A[i]);
    cout<<endl;
    return 0;
}
