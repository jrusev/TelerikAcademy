using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
  
namespace Words
{
    class Program
    {
        static bool ContainsTheSameLetters(string a, string b)
        {
            if (a.Equals(b))
            {
                return true;
            }
  
            if (a.Length < b.Length)
            {
                return false;
            }
  
            int res = 0;
            for (int i = 0; i < b.Length; i++)
            {
                if (a.Contains(b[i]))
                {
                    res++;
                }
            }
            if (res == b.Length)
            {
                return true;
            }
            return false;
        }
  
        static void Main(string[] args)
        {
            int t = int.Parse(Console.ReadLine());
            string text = "";
            for (int i = 0; i < t; i++)
            {
                string str = Console.ReadLine();
                text += str + " ";
            }
            //string text = "Telerik Software Academy has several divisions: Telerik Kids Academy - free training in C++ programming basics in 15 Bulgarian towns Telerik School Academy - trains school students in software development, 3 full days every month Telerik Algo Academy - trains school students in algorithms, 3 full days every month Telerik Software Academy - trains anyone interested in modern software development Telerik Software Academy is based in Sofia, Bulgaria.";
            string[] words = text.Split(' ', ',', '.', '!', '-', '+', '#', ':', '\n', '\t',
                '@', '$', '%', '^', '&', '*', '(', ')', '=', '|', '\\', '/', '\'', '\"', '`', '~');
  
            int w = int.Parse(Console.ReadLine());
            string[] findWords = new string[w];
            for (int i = 0; i < w; i++)
            {
                findWords[i] = Console.ReadLine();
            }
  
  
            Dictionary<string, int> numberUniqueWords = new Dictionary<string, int>();
  
            foreach (string findWord in findWords)
            {
                HashSet<string> uniqueWords = new HashSet<string>();
                foreach (string word in words)
                {
                    if (ContainsTheSameLetters(word.ToLower(), findWord.ToLower()))
                    {
                        uniqueWords.Add(word.ToLower());
                    }
                }
                numberUniqueWords[findWord] = uniqueWords.Count;
            }
  
            foreach (KeyValuePair<string, int> word in numberUniqueWords)
            {
                Console.WriteLine(word.Key + " -> " + word.Value);
            }
        }
    }
}