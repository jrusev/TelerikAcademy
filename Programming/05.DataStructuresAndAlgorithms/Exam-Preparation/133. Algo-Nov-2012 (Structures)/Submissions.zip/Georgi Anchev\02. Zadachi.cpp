#include<iostream>
#include<list>
using namespace std;
typedef struct ivan4o{
    string komanda;
    long long slojnost;
    string ime;
};
int main(){
    string vhod;
    int br,i;
    cin>>br;
    list<ivan4o> zada4i[br];
    for(i=0;i<br;i++){
        //cin>>vhod;
        //cin>>zada4i[i].komanda>>zada4i[i].slojnost>>zada4i[i].ime;
    }



    return 0;
}
