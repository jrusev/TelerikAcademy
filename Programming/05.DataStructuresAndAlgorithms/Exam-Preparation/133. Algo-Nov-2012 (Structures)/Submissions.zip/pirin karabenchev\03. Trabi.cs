using System;
using Wintellect.PowerCollections;
using System.Collections.Generic;

class Tubes
{
    static void Main()
    {
        string input = Console.ReadLine();
        int n = int.Parse(input);
        input = Console.ReadLine();
        int m = int.Parse(input);
        int tubeLength = 0;
        int tubeCount = 0;
        long sum = 0;
        int[] tubes = new int[n];
        for (int i = 0; i < n; i++)
        {
            input = Console.ReadLine();
            tubes[i] = int.Parse(input);
            sum += tubes[i];
        }
        tubeLength = (int) sum / m + 1;
        while (tubeCount < m)
        {
            tubeCount = 0;
            tubeLength--;
            for (int i = 0; i < n; i++)
            {
                tubeCount += tubes[i] / tubeLength;
            }
        }
        Console.WriteLine(tubeLength);
    }
}