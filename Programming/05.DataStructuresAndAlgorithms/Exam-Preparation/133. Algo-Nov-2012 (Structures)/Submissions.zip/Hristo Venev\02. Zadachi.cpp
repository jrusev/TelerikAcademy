#include <cstdio>
#include <algorithm>
#include <cstring>
char str[16]; // fuck Telerik
struct FuckTelerik{
    unsigned first, second;
};
char names[1<<16][8];
typedef unsigned long long ull;
ull speedstr[1<<16];
struct Compare{
    inline bool operator()(const FuckTelerik &a, const FuckTelerik &b){
        if(a.first<b.first) return 0;
        if(a.first>b.first) return 1;
        return speedstr[a.second]>speedstr[b.second];
    }
};

FuckTelerik tasks[1<<16], *tasksEnd=tasks;
int main(){
    setvbuf(stdin, NULL, _IOFBF, 1<<20);
    setvbuf(stdout, NULL, _IOFBF, 1<<20);
    size_t i, k=0;
    scanf("%lu", &i);
    while(i--){
        FuckTelerik t;
        scanf("%s", str);
        if(str[0]=='N'){
            scanf("%u %s", &t.first, names[t.second=k]);
            speedstr[k]=ull(names[k][0])<<40
                       |ull(names[k][1])<<32
                       |ull(names[k][2])<<24
                       |ull(names[k][3])<<16
                       |ull(names[k][4])<<8
                       |ull(names[k][5]);
            k++;
            *tasksEnd++=t;
            std::push_heap(tasks, tasksEnd, Compare());
        }else if(tasks!=tasksEnd){
            puts(names[tasks[0].second]);
            std::pop_heap(tasks, tasksEnd, Compare());
            --tasksEnd;
        }else{
            puts("Rest");
        }
    }
    return 0;
}