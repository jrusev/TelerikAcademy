#include<cstdio>
#include<queue>
int n;
char cmd[8];
struct task{
    int comp;
    char name[8];
}buhta;
inline bool operator<(const task &A,const task &B)
{
    if(A.comp==B.comp)
        for(int i=0;A.name[i]||B.name[i];++i)
            if(A.name[i]!=B.name[i])
                return A.name[i]>B.name[i];
    return A.comp>B.comp;
}
std::priority_queue<task> q;
int main()
{
	setvbuf(stdin,NULL,_IOFBF,1<<20);
	setvbuf(stdout,NULL,_IOFBF,1<<20);
	scanf("%d",&n);
    for(int i=0;i<n;++i)
    {
        scanf("%s",cmd);
        if(cmd[0]=='N')
        {
            scanf("%d%s",&buhta.comp,buhta.name);
            q.push(buhta);
        }
        else if(q.empty())
            puts("Rest");
        else
        {
            buhta=q.top();
            q.pop();
            puts(buhta.name);
        }
    }
    return 0;
}
