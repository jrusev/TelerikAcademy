#include<iostream>
#include<cmath>
#include<algorithm>
#include<vector>
using namespace std;
struct colony
{
  double avg;
  int ind;
}a[100002];
bool f(colony x,colony y)
{
  if(x.avg>y.avg)return 1;
  if(x.avg==y.avg && x.ind>y.ind)return 1;
  return 0;
}
struct point
{
  int x,y;
};
int n,kmin,kmax;
int main()
{
  cin>>n>>kmin>>kmax;
  for(int i=0;i<n;i++)
    {
      vector <point> food;
      vector <point> ameb;
      int q,w;
      cin>>q>>w;
      char c;
      point work;
      for(int e=0;e<q;e++)
        for(int r=0;r<w;r++)
        {
          cin>>c;
          if(c=='*')
            {
              work.x=e;
              work.y=r;
              ameb.push_back(work);
            }
          else
          if(c=='#')
          {
            {
              work.x=e;
              work.y=r;
              food.push_back(work);
            }
          }
        }
      if(food.size()*2<ameb.size())a[i].avg=10000;
      else
      if(food.size()>ameb.size()*2)a[i].avg=-1;
      else
      {
        double sum=0;
        for(int t=0;t<ameb.size();t++)
        {
          int minn=0,mindist=abs(ameb[t].x-food[0].x)+abs(ameb[t].y-food[0].y);
          for(int r=1;r<food.size();r++)
          {
            if(mindist>abs(ameb[t].x-food[r].x)+abs(ameb[t].y-food[r].y))
                {
                  minn=r;
                  mindist=abs(ameb[t].x-food[r].x)+abs(ameb[t].y-food[r].y);
                }
          }
            sum+=mindist;
        }
        a[i].avg=(double)sum/ameb.size();
      }
      a[i].ind=i;
    }
    sort(a,a+n,f);
    //for(int i=0;i<n;i++)cout<<a[i].ind+1<<" "<<a[i].avg<<endl;
    vector <int> pros;
    vector <int> notpros;
    for(int i=0;i<kmin;i++)notpros.push_back(a[i].ind);
    for(int i=n-1;i>=n-kmax;i--)pros.push_back(a[i].ind);
    sort(notpros.begin(),notpros.end());
    sort(pros.begin(),pros.end());
    for(int i=0;i<pros.size()-1;i++)
      cout<<pros[i]+1<<" ";
      cout<<pros[pros.size()-1]+1<<endl;
    for(int i=0;i<notpros.size()-1;i++)
      cout<<notpros[i]+1<<" ";
      cout<<notpros[notpros.size()-1]+1<<endl;
    return 0;
}