using System;
using System.Linq;

class JediQueue
{
    static void Main()
    {
        uint numberJedi = uint.Parse(Console.ReadLine());
        string[] jediList = Console.ReadLine().Split();
        string[] masterList = new string[jediList.Length];
        string[] knightList = new string[jediList.Length];
        string[] padawanList = new string[jediList.Length];

        for (int i = 0; i < jediList.Length; i++)
        {
            if(jediList[i].Contains("m"))
            {
                masterList[i] = jediList[i];
            }
            if(jediList[i].Contains("k"))
            {
                knightList[i] = jediList[i];
            }      
            if(jediList[i].Contains("p"))
            {
                padawanList[i] = jediList[i];
            }
        }
        
        masterList = masterList.Where(x => !string.IsNullOrEmpty(x)).ToArray();

        for (int i = 0; i < masterList.Length; i++)
        {
            Console.Write("{0} ", masterList[i]);
        }

        knightList = knightList.Where(x => !string.IsNullOrEmpty(x)).ToArray();

        for (int i = 0; i < knightList.Length; i++)
        {
            Console.Write("{0} ", knightList[i]);
        }

        padawanList = padawanList.Where(x => !string.IsNullOrEmpty(x)).ToArray();

        for (int i = 0; i < padawanList.Length; i++)
        {
            Console.Write("{0} ", padawanList[i]);
        }

        Console.WriteLine();
    }
}