#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <algorithm>

#include <cstdio>
#include <cstdlib>

using namespace std;

class Product {
public:
    string Name;
    string Producer;
    double Price;
};

int n;

map<string, vector<Product*> > byProducer;
map<double, vector<Product*> > byPrice;
map<string, vector<Product*> > byName;

bool compByName(Product* a, Product* b) {
    return a->Name < b->Name;
}
bool compByProducer(Product* a, Product* b) {
    return a->Name < b->Name;
}

char name[256];
char price[16];
char prod[256];
void add() {
    cin.getline(name, 256, ';');
    cin.getline(price, 16, ';');
    cin.getline(prod, 256);
    Product* t = new Product();
    t->Name = string(name + 1);
    t->Price = atof(price);
    t->Producer = string(prod);
    byName[t->Name].push_back(t);
    byPrice[t->Price].push_back(t);
    byProducer[t->Producer].push_back(t);
    puts("Product added");
}
void del() {
    char shit[128];
    cin.getline(shit, 128);
    string p(shit + 1);
    if (byProducer.find(p) == byProducer.end()) {
        puts("No products found");
        return;
    }
    vector<Product*> toDel;
    for (vector<Product*>::iterator i = byProducer[p].begin(); i != byProducer[p].end(); ++i) {
        toDel.push_back(*i);
    }
    printf("%lu products deleted\n", toDel.size());
    for (unsigned int i = 0; i < toDel.size(); ++i) {
        for (unsigned int j = 0;j < byName[toDel[i]->Name].size(); ++j) {
            if (byName[toDel[i]->Name][j]->Producer == p) {
                byName[toDel[i]->Name].erase(byName[toDel[i]->Name].begin() + j);
            }
            if (byName[toDel[i]->Name].size() == 0) {
                byName.erase(toDel[i]->Name);
            }
            j--;
        }
    }
    byProducer.erase(p);
}
void findByName() {
    char producer[128];
    cin.getline(producer, 100);
    string p(producer + 1);
    if (byName.find(p) != byName.end()) {
        if (byName[p].size() == 0) goto shit;
        sort(byName[p].begin(), byName[p].end(), compByProducer);
        for (vector<Product*>::iterator i = byName[p].begin(); i != byName[p].end(); ++i) {
            printf("{%s;%s;%.2lf}\n", (*i)->Name.c_str(), producer + 1, (*i)->Price);
        }
    } else {
        shit:
        puts("No products found");
    }
}
void findByPriceRange() {
    double from, to;
    char fromC[32], toC[32];
    cin.getline(fromC, 32, ';');
    cin.getline(toC, 32);
    from = atof(fromC + 1);
    to = atof(toC);
    map<double, vector<Product*> >::iterator first = byPrice.lower_bound(from);
    vector<Product*> result;

    while ((*first).first <= to) {
        for (unsigned int i = 0; i < (*first).second.size(); ++i) {
            result.push_back((*first).second[i]);
        }
        first++;
        if (first == byPrice.end()) break;
    }

    if (result.size() == 0) {
        puts("No products found");
        return;
    }

    sort(result.begin(), result.end(), compByName);
    for (vector<Product*>::iterator i = result.begin(); i != result.end(); ++i) {
        printf("{%s;%s;%.2lf}\n", (*i)->Name.c_str(), (*i)->Producer.c_str(), (*i)->Price);
    }
}
void findByProducer() {
    char producer[128];
    cin.getline(producer, 100);
    string p(producer + 1);
    if (byProducer.find(p) != byProducer.end()) {
        if (byProducer[p].size() == 0) goto shit1;
        sort(byProducer[p].begin(), byProducer[p].end(), compByName);
        for (vector<Product*>::iterator i = byProducer[p].begin(); i != byProducer[p].end(); ++i) {
            printf("{%s;%s;%.2lf}\n", (*i)->Name.c_str(), producer + 1, (*i)->Price);
        }
    } else {
        shit1:
        puts("No products found");
    }
}

int main() {
    cin >> n;
    string c;
    for (int i = 0; i < n; ++i) {
        cin >> c;
        if (c[0] == 'A') {
            add();
        }
        if (c[0] == 'D') {
            del();
        }
        if (c[0] == 'F') {
            if (c[14] == 'N') {
                findByName();
            }
            if (c[16] == 'i') {
                findByPriceRange();
            }
            if (c[16] == 'o') {
                findByProducer();
            }
        }
    }
    return 0;
}