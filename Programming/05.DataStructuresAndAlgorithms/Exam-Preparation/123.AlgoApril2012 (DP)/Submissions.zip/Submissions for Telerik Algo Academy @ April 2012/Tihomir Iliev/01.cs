using System;
using System.Linq;

namespace Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split();

            long first = long.Parse(input[0]);
            long second = long.Parse(input[1]);
            long third = long.Parse(input[2]);
            int target = int.Parse(input[3]);

            if (target == 1)
            {
                Console.WriteLine(first);
                return;
            }
            else if (target == 2)
            {
                Console.WriteLine(second);
                return;
            }
            else if (target == 3)
            {
                Console.WriteLine(third);
                return;
            }
            for (int i = 3; i < target; i++)
            {
                long currentTribonacci = first + second + third;
                first = second;
                second = third;
                third = currentTribonacci;
            }

            Console.WriteLine(third);
        }
    }
}
