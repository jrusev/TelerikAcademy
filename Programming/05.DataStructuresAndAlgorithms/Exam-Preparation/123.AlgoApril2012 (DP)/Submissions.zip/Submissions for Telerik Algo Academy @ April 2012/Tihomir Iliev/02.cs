using System;
using System.Collections.Generic;
  
namespace _2.SuperSum
{
    class SuperSum
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split();
            int k = int.Parse(input[0]);
            int n = int.Parse(input[1]);
            Console.WriteLine(BFS(k, n));          
        }
  
        static int BFS(int k, int n)
        {
            Function func = new Function(k, n);
            Queue<Function> functions = new Queue<Function>();
            functions.Enqueue(func);
            int sum = 0;
            while (functions.Count > 0)
            {
                Function current = functions.Dequeue();
                if (current.k == 1)
                {
                    sum += CalculateZeroKFunction(current.n);
                }
                else
                {
                    current.k--;
                    for (int i = 1; i <= current.n; i++)
                    {
                        functions.Enqueue(new Function(current.k, i));
                    }
                }
            }
            return sum;
        }
  
        static int CalculateZeroKFunction(int n)
        {
            int sum = 0;
            for (int i = 1; i <= n; i++)
            {
                sum += i;
            }
            return sum; 
        }
    }
  
    struct Function
    {
        public int k;
        public int n;
        public Function(int k, int n)
        {
            this.k = k;
            this.n = n;
        }
    }
}