using System;
using System.Collections.Generic;

namespace Guitar
{
    class Guitar
    {
        static string[] input;
        static ushort[] intervals;
        static ushort start;
        static ushort max;
        static int length;

        static void Main(string[] args)
        {
            length = int.Parse(Console.ReadLine());
            input = Console.ReadLine().Split();
            intervals = new ushort[length];
            for (int i = 0; i < length; i++)
            {
                intervals[i] = ushort.Parse(input[i]);
            }            
            start = ushort.Parse(Console.ReadLine());
            max = ushort.Parse(Console.ReadLine());            
            Console.WriteLine(FindHighestVolume());
        }

        static short FindHighestVolume()
        {
            Queue<ushort> volumes = new Queue<ushort>();
            volumes.Enqueue(start);

            for (ushort interval = 0; interval < intervals.Length; interval++)
            {
                int limit = volumes.Count;
                for (int song = 0; song < limit; song++)
                {
                    int currentVolume = volumes.Dequeue();
                    int candidate = currentVolume + intervals[interval];
                    if ((candidate >= 0) && (candidate <= max))
                    {
                        volumes.Enqueue((ushort)candidate);
                    }
                    candidate = currentVolume - intervals[interval];
                    if ((candidate >= 0) && (candidate <= max))
                    {
                        volumes.Enqueue((ushort)candidate);
                    }
                }
            }            

            if (volumes.Count == 0)
            {
                return -1;
            }
            else
            {
                int max = volumes.Dequeue();
                int end = volumes.Count;
                for (int finalCandidate = 0; finalCandidate < end; finalCandidate++)
                {
                    int candidate = volumes.Dequeue();
                    if (candidate > max)
                    {
                        max = candidate;
                    }
                }
                return (short)max;
            }
        }
    }
}