using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _4.Liar
{
    class Liar
    {
        static void Main(string[] args)
        {
            string[] input =Console.ReadLine().Split();
            string lies = Console.ReadLine();
            int defaultR = int.Parse(input[0]);
            int RLeft = defaultR;
            int correctLies = 0;
            for (int lie = 0; lie < lies.Length; lie++)
            {
                if (lies[lie] == 'G')
                {
                    if (RLeft > 0)
                    {
                        RLeft--;
                        correctLies++;
                    }
                    else
                    {
                        RLeft = defaultR;
                    }
                }
            }
            Console.WriteLine(correctLies);
        }
    }
}
