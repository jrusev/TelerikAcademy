using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _6.SecretLanguage
{
    class SecretLanguage
    {
        static string message;
        static string[] words;
        static string[] sortedWords;

        static void Main(string[] args)
        {
            ReadInput();
            Console.WriteLine(CalculatePrice());
        }

        static void ReadInput()
        {
            message = Console.ReadLine();
            int wordsCount = int.Parse(Console.ReadLine());
            words = Console.ReadLine().Split();
            sortedWords = new string[wordsCount];
            for (int word = 0; word < wordsCount; word++)
            {
                sortedWords[word] = SortStringChars(words[word]);
            }
        }

        static string SortStringChars(string s)
        {
            char[] c = s.ToCharArray();
            Array.Sort(c);
            return new String(c);
        }

        static int CalculatePrice()
        {
            int[] price = new int[message.Length];
            for (int i = 0; i < price.Length; i++)
            {
                price[i] = -1;
            }
            for (int letter = 0; letter < message.Length; letter++)
            {
                for (int word = 0; word < sortedWords.Length; word++)
                {
                    int startingIndex = letter - sortedWords[word].Length + 1;
                    if (startingIndex >= 0)
                    {
                        string possibleMsg = message.Substring(startingIndex, sortedWords[word].Length);
                        string sortedPossibleMsg = SortStringChars(possibleMsg);
                        if (sortedPossibleMsg.Equals(sortedWords[word]))
                        {
                            int differece = FindDifference(possibleMsg, words[word]);
                            if (startingIndex == 0)
                            {
                                price[letter] = differece;
                            }
                            else if(startingIndex - 1 >= 0)
                            {
                                if (price[startingIndex - 1] != -1)
                                {
                                    if (price[letter] == -1 ||
                                        price[startingIndex - 1] + differece < price[letter])
                                    {
                                        price[letter] = price[startingIndex - 1] + differece;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return price[message.Length - 1];
        }

        static int FindDifference(string first, string second)
        {
            int difference = 0;
            for (int i = 0; i < first.Length; i++)
            {
                if (first[i] != second[i])
                {
                    difference ++;
                }
            }
            return difference;
        }
    }
}
