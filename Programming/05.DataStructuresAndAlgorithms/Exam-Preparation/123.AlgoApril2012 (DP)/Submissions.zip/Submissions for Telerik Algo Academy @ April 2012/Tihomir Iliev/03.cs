using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.Brackets
{
    class Program
    {
        static void Main(string[] args)
        {
            string brackets = Console.ReadLine();
            if (brackets.Length == 1)
            {
                Console.WriteLine(0);
                return;
            }
            int N = brackets.Length;
            brackets = " " + brackets;
            int[,] f = new int[N + 1, N + 2];
            f[0, 0] = 1;
            int c = 0;
            for (int k = 1; k <= N; k++)
            {
                c = 0;
                if (brackets[k] == '(')
                {
                    f[k, c] = 0;
                }
                else
                {
                    f[k, c] = f[k - 1, c + 1];
                }

                for (c = 1; c <= N; c++)
                {
                    if (brackets[k] == '(')
                    {
                        f[k, c] = f[k - 1, c - 1];
                    }
                    else if (brackets[k] == ')')
                    {
                        f[k, c] = f[k - 1, c + 1];
                    }
                    else
                    {
                        f[k, c] = f[k - 1, c - 1] + f[k - 1, c + 1];                           
                    }
                }
            }
            Console.WriteLine(f[N, 0]);
        }
    }
}
