#include<cstdio>
using namespace std;
int tt[20];
int tri(int n,int t1,int t2,int t3)
{
    
     for(int i=4;i<=n;i++)
     {
          tt[i]=tri(i-1,t1,t2,t3)+tri(i-2,t1,t2,t3)+tri(i-3,t1,t2,t3);
          }
     return tt[n];
     }
int main()
{
    int t1,t2,t3,n;
    scanf("%d",&t1);
    scanf("%d",&t2);
    scanf("%d",&t3);
    scanf("%d",&n);
    tt[1]=t1;
    tt[2]=t2;
    tt[3]=t3;
    printf("%d",tri(n,t1,t2,t3));
    
    return 0;
}
