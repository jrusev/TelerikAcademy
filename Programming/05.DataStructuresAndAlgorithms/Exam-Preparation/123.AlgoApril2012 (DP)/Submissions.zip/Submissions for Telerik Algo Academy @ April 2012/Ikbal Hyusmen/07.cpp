#include<cstdio>
using namespace std;

int main()
{
    int n,br=1;
    scanf("%d", n);
    int p[n];
    for(int i=1;i<=n;i++)
    {
         scanf("%d", p[i]);
         }
         int r,maxp=p[1],minp=p[1];
         scanf("%d", r);
         for(int i=0;i<=n;i++)
         {
              if(maxp<p[i])
              {
               maxp=p[i];
                  }
                  if(minp>p[i])
                  {
                      minp=p[i];
                      }
              }
         for(int i=0;i<=n;i++)
         {
                 br++;
                 if(maxp-minp>=r)
                 {
                     printf("%d", br);
                     i=n;
                     }
                      if(((p[i]-p[i+2])>(p[i]-p[i+1]))||((p[i+2]-p[i])>(p[i+1]-p[i])))
                      {
                          i++;
                          }
                          
              }
         return 0;
}
