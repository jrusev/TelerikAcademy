#include<stdio.h>
using namespace std;
unsigned supersum(unsigned k,unsigned n)
{
         int sum=0;
         if(k-1<=0)
         {
                   for(int i=0;i<=n;i++)
                   {
                        sum = i +sum;
                        }
                        return sum;
                   }
          else for(int i=0;i<=n;i++)
          {
               sum = supersum(k-1, i)+sum;
               }
               return sum;
          }
int main()
{
    int k,n;
    scanf("%u", &k);scanf("%u", &n);
    printf("%u", supersum(k,n));
    return 0;  
}
