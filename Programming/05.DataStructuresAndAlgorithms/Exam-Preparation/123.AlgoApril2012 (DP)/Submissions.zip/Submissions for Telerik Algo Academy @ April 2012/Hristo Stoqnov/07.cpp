/*
 * =====================================================================================
 *
 *       Filename:  07.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  26/04/12 15:22:25
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *        Company:  
 *
 * =====================================================================================
 */
#include <cstdio>
int count;
int nums[64];
int diff;
int main() {
    scanf("%d", &count);
    scanf("%d", nums);
    int min = nums[0], max = nums[0];
    for (int i = 1;i < count; ++i) {
        scanf("%d", nums + i);
        if (min > nums[i])
            min = nums[i];
        if (max < nums[i])
            max = nums[i];
    }
    scanf("%d", &diff);
    if (max - min < diff) {
        printf("%d\n", count);
        return 0;
    }
    int ans = 1;
    int current = 0;
    min = nums[0];
    max = nums[0];
    int bigger, lower;
    while (max - min < diff) {
        bigger = (nums[current + 1] > nums[current + 2]) ? nums[current + 1] : nums[current + 2];
        lower = (nums[current + 1] < nums[current + 2]) ? nums[current + 1] : nums[current + 2];
        if (lower < min) {
            /* 
            if (bigger > max) {
                if (bigger - min >= diff || max - lower >= diff) {
                    printf("%d\n", ans + 1);
                    return 0;
                }
                current += 2;
                max = bigger;
                min = lower;
                ans += 2;
                continue;
            }
            */
            if (bigger - min >= diff || max - lower >= diff) {
                printf("%d\n", ans + 1);
                return 0;
            }
            if (bigger - lower >= diff) {
                printf("%d\n", ans + 2);
                return 0;
            }
            if (min - lower < bigger - max) {
                max = bigger;
                current = (nums[current + 1] > nums[current + 2]) ? current + 1 : current + 2;
            } else if (min - lower > bigger - max) {
                min = lower;
                current = (nums[current + 1] < nums[current + 2]) ? current + 1 : current + 2;
            } else {
                current += 2;
                if (max < nums[current])
                    max = nums[current];
                if (min > nums[current])
                    min = nums[current];
            }
        } else if (bigger > max) {
            max = bigger;
            current = (nums[current + 1] > nums[current + 2]) ? current + 1 : current + 2;
        } else {
            current += 2;
            if (max < nums[current])
                max = nums[current];
            if (min > nums[current])
                min = nums[current];
        }
        ans++;
    }
    printf("%d\n", ans);
    return 0;
}