#include <cstdio>
#include <cstring>
char str[128];
int len;
int ans[2][128][128];
int main() {
    scanf("%s", str + 1);
    len = strlen(str + 1);
    if (1 == len % 2 || str[1] == ')' || str[len] == '(') {
        puts("0");
        return 0;
    }
    ans[0][1][1] = 1;
    for (int i = 2;i <= len; ++i) {
        if (str[i] == '?') {
            for (int j = (i + 1) / 2; j <= i; ++j) {
                ans[0][i][j] = ans[0][i - 1][j - 1] + ans[1][i - 1][j - 1];
                ans[1][i][j] = ans[0][i - 1][j] + ans[1][i - 1][j];
            }
        }
        if (str[i] == '(') {
            for (int j = (i + 1) / 2; j <= i; ++j) {
                ans[0][i][j] = ans[0][i - 1][j - 1] + ans[1][i - 1][j - 1];
            }
        }
        if (str[i] == ')') {
            for (int j = (i + 1) / 2; j < i; ++j) {
                ans[1][i][j] = ans[0][i - 1][j] + ans[1][i - 1][j];
            }
        }
//        for (int j = (i + 1) / 2; j <= i; ++j) {
//            if (str[i] == '(' || str[i] == '?')
//                ans[0][i][j] = ans[0][i - 1][j - 1] + ans[1][i - 1][j - 1];
//            if (str[i] == ')' || str[i] == '?')
//            ans[1][i][j] = ans[0][i - 1][j] + ans[1][i - 1][j];
//        }
    }
    printf("%d\n", ans[1][len][len / 2]);
    return 0;
}