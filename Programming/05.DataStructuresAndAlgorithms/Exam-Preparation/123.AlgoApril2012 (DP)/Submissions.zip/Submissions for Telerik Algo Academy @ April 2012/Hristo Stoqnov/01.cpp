/*
 * =====================================================================================
 *
 *       Filename:  tribonacci.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  26/04/12 12:38:56
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *        Company:  
 *
 * =====================================================================================
 */
#include <cstdio>
typedef long long ll;
int main() {
    ll t1, t2, t3, n;
    scanf("%lld %lld %lld %lld", &t1, &t2, &t3, &n);
    for (int i = 4; i <= n; ++i) {
        ll newNum = t1 + t2 + t3;
        t1 = t2;
        t2 = t3;
        t3 = newNum;
    }
    if (n == 1) printf("%lld\n", t1);
    if (n == 2) printf("%lld\n", t2);
    if (n >= 3) printf("%lld\n", t3);
    return 0;
}