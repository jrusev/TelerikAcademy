/*
 * =====================================================================================
 *
 *       Filename:  04.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  26/04/12 13:01:19
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *        Company:  
 *
 * =====================================================================================
 */
#include <cstdio>
int starting, max;
int count;
bool dp[2][1 << 10];
int volumes[64];
int main() {
    scanf("%d", &count);
    for (int i = 0;i < count; ++i) {
        scanf("%d", volumes + i);
    }
    scanf("%d %d", &starting, &max);
    bool curr = 0;
    dp[curr][starting] = 1;
    for (int i = 0;i < count; ++i) {
        for (int j = 0;j <= max; ++j) dp[!curr][j] = 0;
        for (int j = 0;j <= max; ++j) {
            if (dp[curr][j] && j + volumes[i] <= max) {
                dp[!curr][j + volumes[i]] = true;
            }
            if (dp[curr][j] && j - volumes[i] >= 0) {
                dp[!curr][j - volumes[i]] = true;
            }
        }
        curr = !curr;
    }
    for (int i = max; i >= 0; --i) {
        if (dp[curr][i]) {
            printf("%d\n", i);
            return 0;
        }
    }
    puts("-1");
    return 0;
}
