/*
 * =====================================================================================
 *
 *       Filename:  08.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  26/04/12 16:36:24
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *        Company:  
 *
 * =====================================================================================
 */
#include <cstdio>
int r, w;
char s[1 << 12];
int dp[2][1 << 12];
int main() {
    scanf("%d %d", &r, &w);
    scanf("%s", s + 1);
    int i;
    if (s[1] == 'G')
        dp[1][1] = 1;
    else dp[0][1] = 1;
    for (i = 2;s[i] != '\0'; ++i) {
        int count = 0;
        for (int j = 0;j < r; ++j) {
            if (i - j < 1) break;

            count += (s[i - j] == 'G') ? 1 : 0;
            if (dp[1][i] < dp[0][i - j - 1] + count) {
                dp[1][i] = dp[0][i - j - 1] + count;
            }
        }
        count = 0;
        for (int j = 0;j < w; ++j) {
            if (i - j < 0) break;

            count += (s[i - j] == 'B') ? 1 : 0;
            if (dp[0][i] < dp[1][i - j - 1] + count) {
                dp[0][i] = dp[1][i - j - 1] + count;
            }
        }
//        printf("%d: %d %d\n", i, dp[0][i], dp[1][i]);
    }
    printf("%d\n", (dp[0][i - 1] > dp[1][i - 1]) ? dp[0][i - 1] : dp[1][i - 1]);
    return 0;
}