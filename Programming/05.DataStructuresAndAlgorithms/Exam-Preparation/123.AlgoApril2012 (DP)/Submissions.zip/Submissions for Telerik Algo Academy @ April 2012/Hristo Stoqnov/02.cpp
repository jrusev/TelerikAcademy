/*
 * =====================================================================================
 *
 *       Filename:  superSum.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  26/04/12 12:51:10
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *        Company:  
 *
 * =====================================================================================
 */
#include <cstdio>
int mem[16][16];
int main() {
    int k, n;
    scanf("%d %d", &k, &n);
    for (int i = 0;i <= n; ++i) mem[0][i] = i;
    for (int i = 1;i <= k; ++i) {
        for (int j = 0;j <= n; ++j) {
            for (int t = 1; t <= j; ++t) {
                mem[i][j] += mem[i - 1][t];
            }
        }
    }
    printf("%d\n", mem[k][n]);
    return 0;
}