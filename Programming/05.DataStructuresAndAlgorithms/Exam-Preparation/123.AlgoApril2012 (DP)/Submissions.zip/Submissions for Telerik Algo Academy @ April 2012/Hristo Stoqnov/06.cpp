/*
 * =====================================================================================
 *
 *       Filename:  06.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  26/04/12 14:48:10
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *        Company:  
 *
 * =====================================================================================
 */
#include <cstdio>
#include <cstring>
#include <algorithm>
int len;
char string[64];
int wordCount;
char words[64][64];
int wordLens[64];
int dp[64];
bool areSame(int word, char* w2) {
    char w1cpy[64], w2cpy[64];
    int c = wordLens[word];
    for (int i = 0;i < c; ++i) w1cpy[i] = words[word][i];
    for (int i = 0;i < c; ++i) w2cpy[i] = w2[i];
    std::sort(w1cpy, w1cpy + wordLens[word]);
    std::sort(w2cpy, w2cpy + wordLens[word]);
/*
    printf("-- ");
    for (int i = 0;i < wordLens[word]; ++i) {
        printf("%c", w1cpy[i]);
    }
    printf(" ");
    for (int i = 0;i < wordLens[word]; ++i) {
        printf("%c", w2cpy[i]);
    }
    printf(" ");
    puts("");
*/
    for (int i = 0;i < c; ++i)
        if (w1cpy[i] != w2cpy[i])
            return false;
    return true;
}
int diff(int word, char* w2) {
    int ans = 0;
    int c = wordLens[word];
    for (int i = 0;i < c; ++i) {
        if (words[word][i] != w2[i])
            ans++;
    }
    return ans;
}
int main() {
    scanf("%s", string + 1);
    len = strlen(string + 1);
    for (int i = 1; i <= len; ++i) dp[i] = -1;
    scanf("%d", &wordCount);
    for (int i = 0; i < wordCount; ++i) {
        scanf("%s", words[i]);
        wordLens[i] = strlen(words[i]);
    }
    for (int i = 1;i <= len; ++i) {
        for (int w = 0; w < wordCount; ++w) {
            if (wordLens[w] <= i) {
                if (dp[i - wordLens[w]] != -1 && areSame(w, string + i + 1 - wordLens[w])) {
                    int d = diff(w, string + i + 1- wordLens[w]);
                    if (dp[i] == -1 || dp[i] > dp[i - wordLens[w]] + d) {
                        dp[i] = dp[i - wordLens[w]] + d;
                    }
                }
            }
        }
    }
    printf("%d\n", dp[len]);
    return 0;
}