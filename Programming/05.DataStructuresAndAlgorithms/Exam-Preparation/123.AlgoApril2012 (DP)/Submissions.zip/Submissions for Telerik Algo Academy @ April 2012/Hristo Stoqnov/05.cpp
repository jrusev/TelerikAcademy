/*
 * =====================================================================================
 *
 *       Filename:  05.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  26/04/12 13:27:09
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *        Company:  
 *
 * =====================================================================================
 */
#include <cstdio>
bool dp[2][128][128];
int d[8][2] = {{-1, -1}, {-1, 0}, {-1, 1},
               {0, -1},           {0, 1},
               {1, -1}, {1, 0}, {1, 1}
              };
int n, m;
int gene;
int main() {
    scanf("%d", &gene);
    scanf("%d %d", &n, &m);
    bool curr = 0;
    for (int i = 1;i <= n; ++i) {
        for (int j = 1;j <= m; ++j) {
            int x;
            scanf("%d", &x);
            dp[curr][i][j] = x;
        }
    }
    for (int generation = 0; generation < gene; ++generation) {
        for (int i = 1;i <= n; ++i) {
            for (int j = 1; j <= m; ++j) {
                dp[!curr][i][j] = false;
                int neigCount = 0;
                for (int t = 0; t < 8; ++t)
                    if (dp[curr][i + d[t][0]][j + d[t][1]]) neigCount++;
                if (!dp[curr][i][j] && neigCount == 3) {
                    dp[!curr][i][j] = true;
                }
                if (dp[curr][i][j]) {
                    if (neigCount == 2 || neigCount == 3)
                        dp[!curr][i][j] = true;
                    else
                        dp[!curr][i][j] = false;
                }
            }
        }
        curr = !curr;
    }
    int ans = 0;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
            ans += dp[curr][i][j];
    printf("%d\n", ans);
    return 0;
}