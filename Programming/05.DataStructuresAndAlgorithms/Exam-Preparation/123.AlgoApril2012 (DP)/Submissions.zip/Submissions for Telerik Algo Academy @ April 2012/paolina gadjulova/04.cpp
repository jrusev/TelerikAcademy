#include<cstdio>
#include<iostream>
using namespace std;

int C, B, M;
int masiv[64];
int F[51000];


void input (){
    cin >> C;
    for (int i=0; i<C; i++)
    cin >> masiv[i];
    cin >> B >> M;
}

void solve (){
    input ();
    int flag = 1;
    F[B] = 1;
    for (int i = 0; i < C; i++) {
        flag = 1;
        for (int j=0; j<=M; j++)
        if (F[j] == 1) {
            if (j - masiv[i] >= 0) { F[j - masiv[i]] = 1 ; flag = 0; }
            if (j + masiv[i] <= M) { F[j + masiv[i]] = 1 ; flag = 0; }
        }
        if (flag == 1){ cout << "-1\n"; return; }
    }
    for (int i = M; i >=0; i--)
    if (F[i] == 1){cout << i << "\n"; return;}
}

int main (){
    solve ();
    return 0;
}
