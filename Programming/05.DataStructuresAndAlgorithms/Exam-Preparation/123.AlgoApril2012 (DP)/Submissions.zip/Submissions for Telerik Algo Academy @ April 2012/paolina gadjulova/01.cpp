#include<iostream>
using namespace std;
int main (){
    long long a, b, c, d;
    int n;
    cin >> a >> b >> c >> n;

    for (int i=4; i<=n; i++){
    d = a + b + c;
    a = b;
    b = c;
    c = d;
    }
    cout << c << endl;
    return 0;
}
