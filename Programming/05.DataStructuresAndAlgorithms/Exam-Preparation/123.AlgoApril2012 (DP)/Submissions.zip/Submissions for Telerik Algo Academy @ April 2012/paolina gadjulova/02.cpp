#include<cstdio>
#include<iostream>
using namespace std;

int N, K;
int S;
int matrix[16][16];

void Suma (){
    int k, n;
    for (int i=1; i <=N; i++)
    matrix[0][i] = i;
    //for (int i=1; i<=n; )

    for (k=1; k<=K; k++)
    for (n=1; n<=N; n++){

        for (int i=1; i<=n; i++)
        matrix[k][n] += matrix[k-1][i];
    }
}

int main (){
    cin >> K >> N;
    Suma ();
    cout << matrix[K][N] << endl;
    return 0;
}
