#include<cstdio>
#include<iostream>
using namespace std;

int N, n, m, ANS = 0;
int matrix[128][128];
int matrix1[128][128];

void input (){
    scanf ("%d %d", &n, &m);
    for (int i=0; i < n; i++)
        for (int j=0; j < m; j++)
            scanf ("%d", &matrix[i][j]);
}

int izch (int masiv[][128],int index,int index1){
    int bla = 0;
    if (index1>0  && masiv[index][index1-1] == 1 ) bla++;
    if (index1<n && masiv[index][index1+1] == 1) bla++;
    if (index >0 && masiv[index-1][index1] == 1) bla++;
    if (index<n && masiv[index+1][index1] == 1) bla++;
    if (index>0 && index1>0 && masiv[index-1][index1-1] == 1) bla++;
    if (index>0 && index1<n && masiv[index-1][index1+1] == 1) bla++;
    if (index1>0 && index<n && masiv[index+1][index1-1] == 1) bla++;
    if (index<n && index1<n && masiv[index+1][index1+1]) bla++;
    return bla;
}

void proverka (int a[][128], int b[][128], int i, int j){
    int lala=izch (a, i, j);
    if (a[i][j]){
        if (lala == 2 || lala == 3) {
            b[i][j] = a[i][j]; return;}
        if (lala < 2) {
            b[i][j] = 0; return;}
        if (lala > 3) {
            b[i][j] = 0; return;}
    }
    else {
        if (lala == 3) {b[i][j] = 1; return;}
        else b[i][j] = 0;
    }
}

void solve (){
    int flag = 0;
    for (int k=0; k < N; k++){
        if (flag) flag = 0;
        else flag = 1;
        ANS = 0;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++){
                if (flag)
                {
                    proverka (matrix, matrix1, i, j);
                    if (matrix1[i][j] == 1) ANS++;
                }
                else {
                    proverka (matrix1, matrix, i, j);
                    if (matrix[i][j] == 1) ANS++;
                }
            }
    }
}

int main (){
    cin >> N;
    input ();
    solve ();

    /*for (int i=0; i<n; i++){
        for (int j=0; j<m; j++)
        cout << matrix[i][j] << " ";
        cout << endl;
    }

    for (int i=0; i<n; i++){
        for (int j=0; j<m; j++)
        cout << matrix1[i][j] << " ";
        cout << endl;
    }*/
    cout << ANS<< endl;
    return 0;
}
