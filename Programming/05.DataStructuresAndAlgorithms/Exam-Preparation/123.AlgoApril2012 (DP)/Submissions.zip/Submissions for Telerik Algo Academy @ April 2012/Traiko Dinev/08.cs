using System;
using System.Collections.Generic;

namespace TestProj
{
    class Program
    {

        public static void Main(string[] Args)
        {
            string[] input = Console.ReadLine().Split(' ');
            int maxGood = int.Parse(input[0]);
            int maxBad = int.Parse(input[1]);

            int good = 0;
            string days = Console.ReadLine();

            int cGood = 0, cBad = 0;
            for (int i = 0; i < days.Length; ++i)
            {
                if (days[i] == 'G')
                {
                    if (cGood < maxGood)
                    {
                        cGood++;
                        good++;
                    }
                    else
                    {
                        cGood = 0;
                        cBad++;
                    }
                }
                else
                {
                    if (cBad < maxGood)
                    {
                        cBad++;
                        good++;
                    }
                    else
                    {
                        cBad = 0;
                        cGood++;
                    }
                }
            }

            Console.WriteLine(good);
        }
    }
}
