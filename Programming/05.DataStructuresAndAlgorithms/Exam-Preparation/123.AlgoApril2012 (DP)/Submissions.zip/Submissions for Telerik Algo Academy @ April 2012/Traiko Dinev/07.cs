using System;
using System.Collections.Generic;

namespace TestProj
{
    class Program
    {
        struct task
        {
            public task(int a, int b, int c)
            {
                min = a;
                max = b;
                steps = c;
            }

            public int min, max, steps;
        }

        static int[] items;
        public static void Main(string[] Args)
        {
            int n = int.Parse(Console.ReadLine());
            items = new int[n];

            string[] input = Console.ReadLine().Split(' ');
            for (int i = 0; i < n; ++i)
                items[i] = int.Parse(input[i]);

            int target = int.Parse(Console.ReadLine());

            List<task> prev, way, cur;
            prev = new List<task>();
            way = new List<task>();
            cur = new List<task>();

            int best = 51;
            prev.Add(new task(items[0], items[0], 1));
            for (int i = 1; i < n; ++i)
            {
                foreach(var path in prev)
                {
                    int min = path.min < items[i] ? path.min : items[i];
                    int max = path.max > items[i] ? path.max : items[i];

                    if (max - min >= target && path.steps + 1 < best)
                        best = path.steps + 1;

                    cur.Add(new task(min, max, path.steps + 1));
                }

                foreach (var path in way)
                {
                    int min = path.min < items[i] ? path.min : items[i];
                    int max = path.max > items[i] ? path.max : items[i];

                    if (max - min >= target && path.steps + 1 < best)
                        best = path.steps + 1;

                    cur.Add(new task(min, max, path.steps + 1));
                }

                if(best != 51)
                {
                    Console.WriteLine(best);
                    return;
                }

                way = prev;
                prev = cur;
                cur = new List<task>();
            }

            best = 51;
            foreach (var path in prev)
                if (path.steps < best)
                    best = path.steps;
            Console.WriteLine(best);
        }
    }
}
