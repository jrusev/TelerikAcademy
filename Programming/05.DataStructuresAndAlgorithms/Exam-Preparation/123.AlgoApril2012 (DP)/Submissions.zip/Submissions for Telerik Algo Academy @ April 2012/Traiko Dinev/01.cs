using System;
using System.Collections.Generic;

namespace TestProj
{
    class Program
    {
        static int[] last;

        public static void Main(string[] Args)
        {
            last = new int[3];
            string[] input = Console.ReadLine().Split(' ');

            last[0] = int.Parse(input[0]);
            last[1] = int.Parse(input[1]);
            last[2] = int.Parse(input[2]);
            int n = int.Parse(input[3]);

            for (int i = 3; i < n; ++i)
            {
                int cur = last[0] + last[1] + last[2];
                last[0] = last[1];
                last[1] = last[2];
                last[2] = cur;
            }

            Console.WriteLine(last[2]);
        }
    }
}
