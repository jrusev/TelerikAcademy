using System;
using System.Collections.Generic;

namespace TestProj
{
    class Program
    {
        //how many open brackets
        static List<int> posb, next;
        public static void Main(string[] Args)
        {
            string input = Console.ReadLine();
            
            posb = new List<int>();
            next = new List<int>();

            posb.Add(0);
            bool used = false;
            for (int i = 0; i < input.Length; ++i)
            {
                var found = used ? next : posb;
                var newN = used ? posb : next;

                newN.Clear();
                foreach (int p in found)
                {
                    if (input[i] == '?')
                    {
                        if (p + 1 < input.Length - i + 1)
                            newN.Add(p + 1);

                        if (p - 1 >= 0)
                            newN.Add(p - 1);
                    }
                    else
                    {
                        if (input[i] == '(')
                        {
                            if (p + 1 < input.Length - i + 1) newN.Add(p + 1);
                        }
                        else if (p - 1 >= 0) newN.Add(p - 1);

                    }
                }

                used = used ? false : true;
            }

            var final = used ? next : posb;

            int num = 0;
            foreach (int p in final)
                if(p == 0)
                    num ++;

            Console.WriteLine(num);
        }
    }
}
