using System;
using System.Collections.Generic;

namespace TestProj
{
    class Program
    {
        struct block
        {
            public block(int a, int b, int c, int d,
                int f) { x = a; y = b; z = c; height = d; id = f; used = null; }
            public int x, y, z;

            public int id;
            public List<int> used;
            public int height;
        }
        static List<block> blocks;

        //b fits on a
        static bool Fits(block b, block a)
        {
            if ((a.x > b.x && a.y > b.y) ||
                (a.y > b.x && a.x > b.y))
                return true;
            return false;
        }

        public static void Main(string[] Args)
        {
            int n = int.Parse(Console.ReadLine());

            string[] input;

            blocks = new List<block>();
            for (int i = 0; i < n; ++i)
            {
                input = Console.ReadLine().Split(' ');
                var cb = new block(int.Parse(input[0]),
                    int.Parse(input[1]), int.Parse(input[2]), 0, i);
                cb.used = new List<int>();
                cb.height = cb.z;
                cb.used.Add(i);

                blocks.Add(cb);

                block block1 = new block(cb.y, cb.z, cb.x, cb.x, i);
                block1.used = new List<int>();
                block1.used.Add(i);

                block block2 = new block(cb.x, cb.z, cb.y, cb.y, i);
                block2.used = new List<int>();
                block2.used.Add(i);

                blocks.Add(block1);
                blocks.Add(block2);
            }

            var sols = new List<block>(blocks);
            var temp = new List<block>();

            int maxHeight = -1;

            for (int i = 0; i < n; ++i)
            {
                temp.Clear();
                foreach (var sol in sols)
                {
                    foreach (var cb in blocks)
                    {
                        if (Fits(cb, sol) && !sol.used.Contains(cb.id))
                        {
                            block newb = new block(cb.x, cb.y,
                                cb.z, sol.height + cb.z, 0);

                            newb.used = new List<int>(sol.used);
                            newb.used.Add(cb.id);

                            temp.Add(newb);

                            if (sol.height + cb.z > maxHeight)
                                maxHeight = sol.height + cb.z;
                        }
                    }
                }
                sols = new List<block>(temp);
            }

            Console.WriteLine(maxHeight);
        }
    }
}
