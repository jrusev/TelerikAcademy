using System;
using System.Collections.Generic;

namespace TestProj
{
    class Program
    {
        static int[,] sum;

        static int GetSum(int k, int n)
        {
            if (sum[k, n] != 0) return sum[k, n];
            int cs = 0;
            for (int i = 1; i <= n; ++i)
                cs += GetSum(k - 1, i);
            sum[k, n] = cs;

            return sum[k, n];
        }

        public static void Main(string[] Args)
        {
            string[] input = Console.ReadLine().Split(' ');
            int k = int.Parse(input[0]);
            int n = int.Parse(input[1]);

            sum = new int[k + 1, n + 1];
            for (int i = 0; i <= n; ++i)
                sum[0, i] = i;

            Console.WriteLine(GetSum(k, n));
        }
    }
}
