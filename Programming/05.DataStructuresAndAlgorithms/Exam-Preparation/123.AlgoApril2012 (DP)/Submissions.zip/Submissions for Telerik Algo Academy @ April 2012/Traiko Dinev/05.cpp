#include<cstdio>
#include<cstdlib>
#include<list>
using namespace std;

struct cell
{
    public:
		cell(int a, int b) { x = a; y = b; }
		int x, y;
};

bool** map;
int rows, cols;

bool lives(int x, int y)
{
    int nei = 0;
    if (x - 1 >= 0 && map[x - 1][y]) ++nei;
    if (x + 1 < rows && map[x + 1][y]) ++nei;
    if (y - 1 >= 0 && map[x][y - 1]) ++nei;
    if (y + 1 < cols && map[x][y + 1]) ++nei;

    if (x + 1 < rows && y + 1 < cols && map[x + 1][y + 1]) ++nei;
    if (x + 1 < rows && y - 1 >= 0 && map[x + 1][y - 1]) ++nei;

    if (x - 1 >= 0 && y + 1 < cols && map[x - 1][y + 1]) ++nei;
    if (x - 1 >= 0 && y - 1 >= 0 && map[x - 1][y - 1]) ++nei;

    if (!map[x][y] && nei == 3)
        return true;
    if (map[x][y] && nei < 2 || nei > 3)
        return false;

    return map[x][y];
}

int main()
{
    int n;
	scanf("%d%d%d", &n, &rows, &cols);
    
	map = new bool*[rows];
    int alive = 0;
            
    for (int i = 0; i < rows; ++i)
    {
		map[i] = new bool[cols];
        for (int j = 0; j < cols; ++j)
        {
			scanf("%d", &map[i][j]);

            if (map[i][j]) alive++;
        }
    }

	list<cell> upd;
    list<cell>::iterator it;
    for (int i = 0; i < n; ++i)
    {
        upd.clear();
        for(int x = 0; x < rows; ++ x)
            for (int y = 0; y < cols; ++y)
                if (lives(x, y) != map[x][y])
                    upd.push_back(cell(x, y));

		for(it = upd.begin(); it != upd.end(); ++ it)
        {
            if (map[it->x][it->y])
                alive--;
            else alive++;
            map[it->x][it->y] = 1- map[it->x][it->y];
                    
        }
    }
	
	printf("%d", alive);
	puts("");
}
