using System;
using System.Collections.Generic;

namespace TestProj
{
    class Program
    {
        static int[] freq;
        static List<int> posb, next;
        public static void Main(string[] Args)
        {
            int c = int.Parse(Console.ReadLine());
            string[] input = Console.ReadLine().Split(' ');
            int start = int.Parse(Console.ReadLine());
            int max = int.Parse(Console.ReadLine());

            posb = new List<int>();
            next = new List<int>();

            freq = new int[c];

            for (int i = 0; i < c; ++i)
                freq[i] = int.Parse(input[i]);

            bool usep = true;
            posb.Add(start);
            for (int i = 0; i < c; ++i)
            {
                List<int> cl = usep ? posb : next;
                List<int> add = usep ? next : posb;

                add.Clear();

                foreach (int p in cl)
                {
                    if (p + freq[i] <= max && !add.Contains(p + freq[i]))
                        add.Add(p + freq[i]);
                    if (p - freq[i] >= 0 && !add.Contains(p - freq[i]))
                        add.Add(p - freq[i]);
                }
                usep = usep ? false : true;
            }

            int cur = -1;

            List<int> search = usep ? posb : next;
            if (posb.Count == 0)
                Console.WriteLine(-1);
            else
            {
                foreach (int p in search)
                    if (p > cur) cur = p;
                Console.WriteLine(cur);
            }
        }
    }
}
