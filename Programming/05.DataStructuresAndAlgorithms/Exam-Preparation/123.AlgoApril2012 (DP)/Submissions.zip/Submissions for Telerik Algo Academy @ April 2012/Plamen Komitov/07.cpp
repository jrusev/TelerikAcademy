#include<iostream>
using namespace std;
long long n,r,p[105];
int main()
{
  long long i,j,pom,otg;


  cin>>n;
  for(i=1;i<=n;i++)
    cin>>p[i];
  cin>>r;


  for(i=2;i<=n;i++)
    for(j=1;j<=i;j++)
    {
      pom = p[i] - p[j];

      if(pom < 0)
        pom *= -1;

      if(pom >= r)
      {
        cout<<j/2 + 1 + (i-j+1)/2<<endl;
        return 0;
      }
    }


    cout<<n/2 + 1<<endl;
}
