#include<iostream>
#include<algorithm>
using namespace std;
long long n,Max,MaxH[2048];
bool a[2048][2048];


struct z
{
  int a,b,h;
};
z m[2048];


int DFS(int k)
{
    int i;

    if(MaxH[k]!=0)
      return MaxH[k];

    for(i=0;i<n;i++)
    {
      if(a[i][k])
        if(MaxH[k] < DFS(i))
          MaxH[k] = MaxH[i];
    }

    MaxH[k]+=m[k].h;

    if(MaxH[k]>Max)
      Max=MaxH[k];

    return MaxH[k];
}


int main()
{
  int i, j;
  cin>>n;
  n *= 3;
  for(j=1;j<=n;j+=3)
  {
    cin>>m[j].a>>m[j].b>>m[j].h;


    m[j+1] = m[j];
    swap(m[j+1].b, m[j+1].h);

    m[j+2] = m[j];
    swap(m[j+2].a, m[j+2].h);


    if(m[j].a > m[j].b)
      swap(m[j].a, m[j].b);

    if(m[j+1].a > m[j+1].b)
      swap(m[j+1].a, m[j+1].b);

    if(m[j+2].a > m[j+2].b)
      swap(m[j+2].a, m[j+2].b);
  }


  for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
      a[i][j] = m[i].a < m[j].a && m[i].b < m[j].b;


    for(i=1;i<=n;i++)
      DFS(i);


    cout<<Max<<endl;
    return 0;
}
