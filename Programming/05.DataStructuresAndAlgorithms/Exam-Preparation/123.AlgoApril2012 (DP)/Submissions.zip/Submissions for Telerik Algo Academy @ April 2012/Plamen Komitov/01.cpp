#include<iostream>
using namespace std;
long long a,b,c,n,m[105];
int main()
{
  long long i;
  cin>>a>>b>>c>>n;
  m[1] = a;
  m[2] = b;
  m[3] = c;
  if(n < 4)
    cout<<m[n]<<endl;
  else
  {
    for(i=4;i<=n;i++)
      m[i] = m[i-1] + m[i-2] + m[i-3];
    cout<<m[n]<<endl;
  }
}
