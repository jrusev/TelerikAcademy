#include<iostream>
using namespace std;
long long r,w;
long long g,b;
long long row;
string s;
int main()
{
  long long i,fl;


  cin>>r>>w;
  cin>>s;


  if(s[0] == 'G')
  {
    g = 1;
    fl = 1;
    row = 1;
  }
  else
  {
    g++;
    fl = 0;
    row = 1;
  }


  for(i=1;i<=s.length()-1;i++)
    if(s[i] == 'B')
      if(fl == 0)
        if(row == w)
        {
          b++;
          row = 1;
          fl = 1;
        }
        else
        {
          g++;
          row++;
        }
      else
        if(row == r)
        {
          g++;
          row = 1;
          fl = 0;
        }
        else
        {
          g++;
          row = 1;
          fl = 0;
        }
    else
      if(fl == 0)
        if(row == w)
        {
          g++;
          row = 1;
          fl = 1;
        }
        else
        {
          g++;
          row = 1;
          fl = 1;
        }
      else
        if(row == r)
        {
          b++;
          row = 1;
          fl = 0;
        }
        else
        {
          g++;
          row++;
        }


  cout<<g<<endl;
}
