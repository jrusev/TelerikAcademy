#include<iostream>
using namespace std;
long long n,r,c,br;
long long l[2055][155][155];
int main()
{
  long long i,j,p,pom;


  cin>>n>>r>>c;
  for(i=1;i<=r;i++)
    for(j=1;j<=c;j++)
      cin>>l[0][i][j];


  for(p=1;p<=n;p++)
    for(i=1;i<=r;i++)
      for(j=1;j<=c;j++)
      {
        pom = l[p-1][i-1][j-1] + l[p-1][i-1][j] + l[p-1][i-1][j+1] + l[p-1][i][j-1] + l[p-1][i][j+1] + l[p-1][i+1][j-1] + l[p-1][i+1][j] + l[p-1][i+1][j+1];
        if(l[p-1][i][j] == 0)
          if(pom == 3)
            l[p][i][j] = 1;
          else
            l[p][i][j] = 0;
        else
          if(pom == 2 || pom == 3)
            l[p][i][j] = 1;
          else
            l[p][i][j] = 0;
      }


  for(i=1;i<=r;i++)
    for(j=1;j<=c;j++)
      if(l[n][i][j] == 1)
        br++;


  cout<<br<<endl;
}
