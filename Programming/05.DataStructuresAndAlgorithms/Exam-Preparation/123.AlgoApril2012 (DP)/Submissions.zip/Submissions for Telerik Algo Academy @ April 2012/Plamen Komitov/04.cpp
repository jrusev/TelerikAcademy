#include<iostream>
using namespace std;
long long c,m,b;
long long a[105],p[105][1005];
int main()
{
  long long i,j;


  cin>>c;
  for(i=1;i<=c;i++)
    cin>>a[i];
  cin>>b>>m;


  if(a[1]+b > m && b-a[1] < 0)
  {
    cout<<-1<<endl;
    return 0;
  }
  else
  {
    if(a[i]+b <= m)
      p[0][a[i]+b] = 1;
    if(b-a[i] >= 0)
      p[0][b-a[i]] = 1;
  }


  for(i=1;i<=c;i++)
    for(j=0;j<=m;j++)
      if(p[i-1][j] == 1)
      {
        if(a[i]+j <= m)
          p[i][a[i]+j] = 1;
        if(j-a[i] >= 0)
          p[i][j-a[i]] = 1;
      }


  for(i=m;i>=0;i--)
    if(p[c][i] == 1)
    {
      cout<<i<<endl;
      return 0;
    }

  cout<<-1<<endl;
}
