#include<iostream>
using namespace std;
long long n,k,s;
long long a[105][105];
int main()
{
  long long i,j,z;

  cin>>k>>n;

  for(i=1;i<=n;i++)
    a[0][i] = i;


  for(i=1;i<=k;i++)
    for(j=1;j<=n;j++)
      for(z=1;z<=j;z++)
        a[i][j] += a[i-1][z];


  cout<<a[k][n]<<endl;
}
