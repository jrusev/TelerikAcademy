#include <iostream>
using namespace std;
 
string s;
int r,w,rr,ww;
 
int main()
{
    cin >> rr >> ww;
    cin >> s;
    int n=s.size();
    int res=0;
    r=rr; w=ww;
    for(int i=0; i<n; i++)
    {
            if(s[i]=='G' && r==0) { r=rr; w-=1; continue; }
            if(s[i]=='B' && w==0) { w=ww; r-=1; continue; }
            while(s[i]=='G' && i<n && r>0){
                            res++;
                            i++;
                            r--;
                            w=ww;
            }
            if(i>=n) break;
            while(s[i]=='B' && i<n && w>0)
            {
                            r=rr;
                            res++;
                            i++;
                            w--;
            }
            i--;
           // cout << i << ' ' << res << endl;
    }
    cout << res << endl;
    return 0;
}
