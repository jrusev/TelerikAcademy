#include <iostream>
using namespace std;

bool dp[64][1024];

int main()
{
    int c;
    int a[64];
    int b,m;
    cin >> c;
    for(int i=0; i<c; i++)
    cin >> a[i];
    cin >> b >> m;
    
    dp[0][b]=1;
    
    for(int i=1; i<=c; i++)
    for(int j=0; j<=m; j++)
    {
            if(j-a[i-1]>=0) if(dp[i-1][j-a[i-1]]) dp[i][j]=1;
            if(j+a[i-1]<=m) if(dp[i-1][j+a[i-1]]) dp[i][j]=1;
            //if(i==1) cout << j << ' ' << dp[i][j] << endl;
    }
    
    for(int i=m; i>=0; i--)
    {
            if(dp[c][i]){
                         cout << i << endl;
                         return 0;
                         }
    }
    cout << -1 << endl;
    return 0;
}
