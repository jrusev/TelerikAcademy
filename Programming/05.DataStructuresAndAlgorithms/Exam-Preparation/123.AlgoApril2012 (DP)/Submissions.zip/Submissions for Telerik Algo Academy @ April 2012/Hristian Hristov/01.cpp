#include <iostream>
using namespace std;
int main()
{
    int tr[64];
    int a,b,c;
    cin >> a >> b >>c;
    int n;
    cin >> n;
    tr[1]=a;
    tr[2]=b;
    tr[3]=c;
    for(int i=4; i<=n; i++) tr[i]=tr[i-1]+tr[i-2]+tr[i-3];
    cout << tr[n] << endl;
    return 0;
}
