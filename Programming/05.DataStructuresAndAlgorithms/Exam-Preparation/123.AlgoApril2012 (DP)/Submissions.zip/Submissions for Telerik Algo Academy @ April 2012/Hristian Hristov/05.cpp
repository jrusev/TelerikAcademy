#include <iostream>
#include <cstdio>
using namespace std;
int r,c;
int n;
int a[2050][128][128];
 
int calcs(int t, int i, int j)
{
    int res=0;
    if(a[t][i-1][j-1]==1) res++;
    if(a[t][i-1][j]==1) res++;
    if(a[t][i-1][j+1]==1) res++;
    if(a[t][i][j-1]==1) res++;
    if(a[t][i][j+1]==1) res++;
    if(a[t][i+1][j-1]==1) res++;
    if(a[t][i+1][j]==1) res++;
    if(a[t][i+1][j+1]==1) res++;
    return res;
}
     
 
int main()
{
    cin >> n;
    cin >> r >> c;
    for(int i=0; i<r; i++)
    for(int j=0; j<c; j++)
    {
            scanf("%d", &a[0][i][j]);
    }
    int res=0;
     
    for(int t=0; t<n; t++)
    {
            //res=0;
            for(int i=0; i<r; i++)
            for(int j=0; j<c; j++)
            {
                    int brs=calcs(t,i,j);
                    a[t+1][i][j]=0;
                    if(a[t][i][j]==0 && brs==3) a[t+1][i][j]=1;
                    if(a[t][i][j]==0 && brs<3) a[t+1][i][j]=0;
                    if(a[t][i][j]==1 && (brs==2 || brs==3)) a[t+1][i][j]=1;
                    if(a[t][i][j]==1 && brs<2) a[t+1][i][j]=0;
                    if(a[t][i][j]==1 && brs>3) a[t+1][i][j]=0;
                    //res+=a[t+1][i][j];
            }
    }
    for(int i=0; i<r; i++)
            for(int j=0; j<c; j++)
            res+=a[n][i][j];
    cout << res << endl;
    return 0;
}