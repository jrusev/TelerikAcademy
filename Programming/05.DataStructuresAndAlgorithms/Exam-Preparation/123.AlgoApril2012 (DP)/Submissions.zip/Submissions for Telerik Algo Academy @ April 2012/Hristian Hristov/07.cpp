#include <iostream>
using namespace std;

struct ppp
{
       int a,b;
       ppp(){}
       ppp(int _a, int _b)
       {
               a=_a;
               b=_b;
       }
}dp[64][64];

int n;
int a[64];
int p;

int main()
{
    cin >> n;
    for(int i=0; i<n; i++) cin >> a[i];
    cin >> p;
    for(int i=0; i<n; i++)
    for(int j=0; j<n; j++)
    dp[i][j]=ppp(-1,10003);
    
    dp[0][1]=ppp(a[0],a[0]);
    
    for(int i=1; i<n; i++)
    for(int j=i/2+i%2+1; j<=n; j++)
    {
            if(i==1) dp[i][j].a=dp[i-1][j-1].a;
            if(i==1) dp[i][j].b=dp[i-1][j-1].b;
            else {
            dp[i][j].a=max(dp[i-1][j-1].a,dp[i-2][j-1].a);
            dp[i][j].b=min(dp[i-1][j-1].b,dp[i-2][j-1].b);}
            
            /*if(a[i]>dp[i-1][j-1].a) dp[i][j].a=a[i];
            if(a[i]<dp[i-1][j-1].b) dp[i][j].b=a[i];
            if(i>1){
            if(a[i]>dp[i-2][j-1].a) dp[i][j].a=a[i];
            if(a[i]<dp[i-2][j-1].b) dp[i][j].b=a[i];}*/
            if(a[i]>dp[i][j].a) dp[i][j].a=a[i];
            if(a[i]<dp[i][j].b) dp[i][j].b=a[i];
            
            
            //cout << i << ' ' << j << ' ' << dp[i][j].a << ' ' << dp[i][j].b << endl;
            
            if(dp[i][j].a==-1 || dp[i][j].b>10000) continue;
            if(dp[i][j].a-dp[i][j].b>=p) { cout << j << endl; return 0; }
    }
    
    cout << n << endl;
    
    return 0;
}
            
