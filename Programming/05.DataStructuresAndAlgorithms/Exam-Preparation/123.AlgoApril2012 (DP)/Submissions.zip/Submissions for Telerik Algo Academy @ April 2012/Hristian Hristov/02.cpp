#include <iostream>
using namespace std;

int dp[32][32];

long long go(int k,int n)
{
     if(k==0) return dp[k][n]=n;
     if(dp[k][n]) return dp[k][n];
     long long sum=0;
     for(int i=1; i<=n; i++)
     sum+=go(k-1,i);
     
     return dp[k][n]=sum;
}

int main()
{
    int n,k;
    cin >> k >> n;
    cout << go(k,n) << endl;;
    
    return 0;
}
