#include <iostream>
#include <stack>
using namespace std;

bool valid(string s)
{
     int n=s.size();
     int br=0;
     for(int i=0; i<n; i++)
     {
             if(s[i]=='(') br++;
             if(s[i]==')') br--;
             if(br<0) return false;
     }
     if(br==0) return true;
     return false;
}

int res;
int n;
string s;

void go(int i, string curr)
{
    // cout << curr << endl;
     if(i==n){ res+=valid(curr); return;}
     string zz=curr; zz.insert(i,1,s[i]);
     if(s[i]=='?'){
                   string z=curr, z1=curr; z.insert(i,1,'('); z1.insert(i,1,')');
                   go(i+1,z);
                   go(i+1,z1);
                   }
     else go(i+1,zz);
}
     
int main()
{
    cin >> s;
    n=s.size();
    string ss="";
    go(0,ss);
    cout <<res <<endl;
    return 0;
}
