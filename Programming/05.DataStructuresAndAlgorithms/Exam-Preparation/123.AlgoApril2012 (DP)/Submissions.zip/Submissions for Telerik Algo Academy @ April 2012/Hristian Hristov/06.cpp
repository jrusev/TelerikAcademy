#include <iostream>
#include <string>
#include <cstring>
using namespace std;


bool comp(string s, string s1)
{
     int a[32],b[32];
     int n=s.size();
     int m=s1.size();
     if(n!=m) return false;
     for(int i=0; i<30; i++) { a[i]=0; b[i]=0;}
     
     for(int i=0; i<n; i++)
     {
             a[s[i]-'a']++;
             b[s1[i]-'a']++;
     }
     
     for(int i=0; i<30; i++) 
     if(a[i]!=b[i]) return false;
     return true;
}
     

int diff(string s, string s1)
{
    int n=s.size();
    int res=0;
    for(int i=0; i<n; i++)
    {
            if(s[i]!=s1[i]) res++;
    }
    return res;
}

string s;
string w[64];
int n;

int dp[64];

int main()
{
    cin >> s;
    cin >> n;
    for(int i=0; i<n; i++)
    cin >> w[i];
    
    int m=s.size();
    dp[0]=0;
    
    for(int i=0; i<m; i++)
    {
            dp[i]=50*50*50;
            string curr="";
                   int cp=0;
          for(int j=i; j>=0; j--)
          {
                    curr.insert(0,1,s[j]);
                    for(int k=0; k<n; k++)
                    {
                            if(comp(curr,w[k]))
                            {
                                               cp=diff(curr,w[k]);
                                               dp[i]=min(dp[i],dp[j-1]+cp);
                            }
                    }
          }
    }
    if(dp[m-1]==50*50*50) cout << -1 << endl;
    else cout << dp[m-1] << endl;
    return 0;
}
                                               
