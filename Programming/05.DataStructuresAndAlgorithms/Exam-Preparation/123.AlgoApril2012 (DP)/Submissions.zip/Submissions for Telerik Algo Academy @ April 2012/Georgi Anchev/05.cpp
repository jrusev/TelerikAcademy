#include<iostream>
using namespace std;
int n,c,r;
bool a[129][129],b[129][129];
void func(){
	for(int s=1;s<=r;s++){
		for(int t=1;t<=c;t++){
			a[s][t]=b[s][t];
		}
	}
	return;
}
int main(){
	int i,j,k;
	cin>>n>>r>>c;
	for(i=1;i<=r;i++)for(j=1;j<=c;j++)cin>>a[i][j];
	for(k=0;k<n;k++){
		for(i=1;i<=r;i++){
			for(j=1;j<=c;j++){
				int susedi=0,jiva=a[i][j];
				susedi+=a[i-1][j-1];
				susedi+=a[i-1][j];
				susedi+=a[i][j-1];
				susedi+=a[i+1][j+1];
				susedi+=a[i+1][j];
				susedi+=a[i-1][j+1];
				susedi+=a[i+1][j-1];
				susedi+=a[i][j+1];
				if(jiva==0){
					if(susedi==3)b[i][j]=1;
					else b[i][j]=0;
				}
				else {
					if(susedi<2 || susedi>3)b[i][j]=0;
					else b[i][j]=1;
				}
			}
		}
		func();
	}
	int otg=0;
	for(i=1;i<=r;i++)for(j=1;j<=c;j++)otg+=a[i][j];
	cout<<otg;
	return 0;
}
