#include<iostream>
using namespace std;
int main(){
	char a[60];
	cin>>a;
	int x;
	cin>>x;
	char b[x][50];
	for(int i=0;i<x;i++)cin>>b[i];
    cout<<"-1"<<endl;
    return 0;
}
