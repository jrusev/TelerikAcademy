#include<iostream>
#include<cmath>
using namespace std;
int main(){
	int n,raz,otg=0,lqv=-1,desen=-1;
	cin>>n;
	float pri[n];
	int i,j;
	for(i=0;i<n;i++)cin>>pri[i];
	cin>>raz;
	for(i=1;i<n;i++){
		for(j=0;j<i;j++){
			int sdf=pri[i]-pri[j];
			if(sdf<0)sdf*=-1;
			if(sdf>=raz){
				desen=i;
				lqv=j;
				i=n;
				break;
			}
		}
	}
	if(lqv==0){
		if(desen%2)desen++;
		cout<<desen/2+1<<endl;
		return 0;
	}
	if(lqv%2)otg+=(lqv+1)/2+1;
	else otg+=lqv/2+1;
	int z=desen-lqv;
	if(z%2)z++;
	otg+=z/2+1;
	cout<<otg<<endl;



	return 0;
}
