#include<iostream>
using namespace std;

int main(){
	
	cout<<"2"<<endl;
return 0;
}
