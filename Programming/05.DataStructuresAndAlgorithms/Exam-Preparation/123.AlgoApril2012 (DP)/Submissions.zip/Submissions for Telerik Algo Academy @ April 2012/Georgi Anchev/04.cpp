#include<iostream>
using namespace std;
int b,c,m,maxi=-1,a[50];
void rec(int cur,int br){
	if(cur<0)return;
	if(cur>m)return;
	if(br==c-1){
		if(maxi<cur)maxi=cur;
		return;
	}
	rec(cur+a[br+1],br+1);
	rec(cur-a[br+1],br+1);
	return ;
}
int main(){
	cin>>c;
	int i;
	for(i=0;i<c;i++)cin>>a[i];
	cin>>b>>m;
	rec(b+a[0],0);
	rec(b-a[0],0);
	cout<<maxi<<endl;
	return 0;
}
