#include<iostream>
using namespace std;
char a[2502];
int b[2502];
int main(){
	cin>>a;
	int j,i;
	for(j=1;a[j]>0;j++);
	for(i=1;i<=j;i++){
			b[i]+=b[i-1];
			if(a[i]=='?'&& i!=j)b[i]++;

	}
	for(i=1;i<=j;i++)cout<<b[i]<<endl;
	return 0;
}
