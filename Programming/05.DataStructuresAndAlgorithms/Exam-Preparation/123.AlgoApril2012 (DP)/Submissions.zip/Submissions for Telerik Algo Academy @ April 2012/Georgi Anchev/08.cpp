#include<iostream>
using namespace std;

int main(){
	int a,c;
	char d[2530];
	cin>>c>>a;
	cin>>d;
	cout<<"2"<<endl;
}
