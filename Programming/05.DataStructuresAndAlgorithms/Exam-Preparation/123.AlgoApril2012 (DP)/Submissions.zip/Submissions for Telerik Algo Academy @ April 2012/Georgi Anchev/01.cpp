#include<iostream>
using namespace std;
int main(){
    int a,b,c,n,x,i;
    cin>>c>>b>>a>>n;
    for(i=3;i<n;i++){
        x=a+b+c;
        c=b;
        b=a;
        a=x;
    }
    cout<<a<<endl;
    return 0;
}