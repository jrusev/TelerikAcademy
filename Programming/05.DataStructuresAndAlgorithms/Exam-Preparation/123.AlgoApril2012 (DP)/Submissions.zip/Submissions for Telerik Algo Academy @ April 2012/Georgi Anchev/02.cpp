#include<iostream>
using namespace std;
int a[15]={0,1,3, 6, 10, 15, 21, 28, 36, 45, 55, 66, 78, 91, 105};
int rec(int k,int n){
	int otg=0;
	if (k==1)return a[n];
	for(int i=1;i<=n;i++)otg+=rec(k-1,i);
	return otg;
}
int main(){
	int n,k,i,j;
	cin>>k>>n;
	cout<<rec(k,n)<<endl;
	return 0;
}
