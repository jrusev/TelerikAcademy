#include<iostream>
#include<cstring>
using namespace std;
char s[300];
long long int k,c,a[82][82],q;
int main()
{
    cin.getline(s,300);
    a[0][0]=1;
    int n=strlen(s);
    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<=n;j++)
        {
            if(s[i-1]=='(')
            {
                if(j==-1)q=0;
                else q=a[i-1][j-1];
            }
            if(s[i-1]==')')q=a[i-1][j+1];
            if(s[i-1]=='?')q=a[i-1][j+1]+a[i-1][j-1];
            a[i][j]=q;
        }
    }
     
    cout<<a[n][0]<<endl;
    return 0;
}