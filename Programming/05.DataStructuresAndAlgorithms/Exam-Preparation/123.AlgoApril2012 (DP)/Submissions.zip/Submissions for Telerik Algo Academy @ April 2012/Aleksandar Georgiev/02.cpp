#include<iostream>
using namespace std;
int n,k,q[30][30],a;
int main()
{
    cin>>n>>k;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=k;j++)
        {
            for(int t=1;t<=j;t++)
            {
                if(i-1==0)a=t;
                else a=q[i-1][t];
                q[i][j]=q[i][j]+a;
            }
        }
    }
    cout<<q[n][k]<<endl;
    return 0;
}