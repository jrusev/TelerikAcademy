#include<iostream>
#include<cstring>
using namespace std;
 
int main()
{
    int t,n,m;
    cin>>t;
    cin>>n>>m;
    int br=0,q;
    char a[50][50],sd='A';
    int br1=0,br2=0,q2;
    for(int i=0;i<=n;i++)
    {
        cin.getline(a[i],50);
    }
    if(t==1)
    {
        
    
    for(int i=0;i<=n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(a[i][j]=='.')
            {
                br++;
                br1=0;
                br2=0;
                q2=j;
                if(a[i][j+1]=='.')
                {
                    while(1)
                    {
                        q2++;
                        if(a[i][q2]=='#'||a[i][q2]=='\0'||q2>m)break;
                        br1++;
                         
                    }
                }
                else if(a[i+1][j]=='.')
                {
                    q=i;
                    while(1)
                    {
                        q++;
                        if(a[q][j]=='#'||a[i][j]=='\0'||q>n)break;
                        br2++; 
                    }
                }
                if(br1>br2)
                {
                    for(int z=j;z<=q2;z++)a[i][z]='#';
                }
                else
                {
                    for(int z=i;z<=q;z++)a[z][j]='#';
                }
            }
        }
        
    }
    cout<<br<<endl;
    }
    else
    {
        
    
    for(int i=0;i<=n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(a[i][j]=='.')
            {
                br++;
                br1=0;
                br2=0;
                q2=j;
                if(a[i][j+1]=='.')
                {
                    while(1)
                    {
                        q2++;
                        if(a[i][q2]=='#'||a[i][q2]=='\0'||q2>m)break;
                        br1++;
                         
                    }
                }
                else if(a[i+1][j]=='.')
                {
                    q=i;
                    while(1)
                    {
                        q++;
                        if(a[q][j]=='#'||a[i][j]=='\0'||q>n)break;
                        br2++; 
                    }
                }
                if(br1>br2)
                {
                    for(int z=j;z<q2;z++)a[i][z]=sd;
                }
                else
                {
                    for(int z=i;z<q;z++)a[z][j]=sd;
                }
                sd++;
            }
        }
        
    }
    for(int i=1;i<=n;i++)
    {
        cout<<a[i]<<endl;
    }
    }
    return 0;
}