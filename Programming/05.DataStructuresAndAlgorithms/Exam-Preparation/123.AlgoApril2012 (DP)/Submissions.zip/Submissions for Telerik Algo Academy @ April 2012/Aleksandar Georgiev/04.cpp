#include<iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int a[n+1];
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
    }
    int b,c;
    long long int s=0,s1=0;
    cin>>b;
    cin>>c;
    s=b;
    for(int i=1;i<=n;i++)
    {
        if(s1+a[i]>c&&s1-a[i]<0){s=-1;break;}
        if(s1+a[i]<=c)s1=s1+a[i];
        else s=s-a[i];
         
    }
    if(b-a[1]>=0){s1=b-a[1];
    for(int i=2;i<=n;i++)
    {
        if(s1+a[i]>c&&s1-a[i]<0){s=-1;break;}
        if(s1+a[i]<=c)s1=s1+a[i];
        else s=s-a[i];
         
    }}
    else s1=-1;
    if(s>s1)cout<<-1<<endl;
    else cout<<-1<<endl;
    return 0;
}