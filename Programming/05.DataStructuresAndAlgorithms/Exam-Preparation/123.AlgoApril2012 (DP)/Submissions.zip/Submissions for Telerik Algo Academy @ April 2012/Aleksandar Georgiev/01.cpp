#include<iostream>
using namespace std;
int main()
{
    long long int a,b,c,h,n;
    cin>>a>>b>>c>>n;
    if(n==1)cout<<a<<endl;
    else if(n==2)cout<<b<<endl;
    else if(n==3)cout<<c<<endl;
    else
    {
        
    
    for(int i=3;i<n;i++)
    {
        h=c;
        c=a+b+c;
        a=b;
        b=h;
    }
    cout<<c<<endl;
    }
    return 0;
}