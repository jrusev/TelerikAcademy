#include<iostream>
using namespace std;
int a[200][200];
int main()
{
    int n,c,b;
    cin>>n;
    cin>>c>>b;
    for(int i=1;i<=c;i++)
    {
        for(int j=1;j<=b;j++)
        {
            cin>>a[i][j];
        }
    }
    int br=0;
    for(int k=1;k<=n;k++)
    {
        
    
        for(int i=1;i<=c;i++)
        {
            for(int j=1;j<=b;j++)
            {
                br=0;
                if(a[i][j+1]==1||a[i][j+1]==2)br++;
                if(a[i][j-1]==1||a[i][j-1]==2)br++;
                if(a[i+1][j]==1||a[i+1][j]==2)br++;
                if(a[i-1][j]==1||a[i-1][j]==2)br++;
                if(a[i+1][j+1]==1||a[i+1][j+1]==2)br++;
                if(a[i-1][j+1]==1||a[i-1][j+1]==2)br++;
                if(a[i+1][j-1]==1||a[i+1][j-1]==2)br++;
                if(a[i-1][j-1]==1||a[i-1][j-1]==2)br++;
                if(a[i][j]==0)
                {
                    if(br==3)a[i][j]=3;
                }
                if(a[i][j]==1)
                {
                    if(br<2||br>3)a[i][j]=2;
                }
            }
        }
        for(int i=1;i<=c;i++)
        {
            for(int j=1;j<=b;j++)
            {
                if(a[i][j]==3)a[i][j]=1;
                if(a[i][j]==2)a[i][j]=0;
            }
        }
    }
    int brf=0;
    for(int i=1;i<=c;i++)
    {
        for(int j=1;j<=b;j++)
        {
            if(a[i][j]==1)brf++;
        }
    }
    cout<<brf<<endl;
    return 0;
}