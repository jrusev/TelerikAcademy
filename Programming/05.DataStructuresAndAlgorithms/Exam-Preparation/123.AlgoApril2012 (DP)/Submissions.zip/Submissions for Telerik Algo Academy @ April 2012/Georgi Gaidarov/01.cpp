#include <iostream>
#include <map>
#include <cstdio>
#include <string>
#include <queue>

using namespace std;

int main()
{
    long long t[25];
    int n;
    cin>>t[0]>>t[1]>>t[2]>>n;
    for(int i=3; i<n; i++)
        t[i] = t[i-1] + t[i-2] + t[i-3];

    cout<<t[n-1]<<endl;


}
