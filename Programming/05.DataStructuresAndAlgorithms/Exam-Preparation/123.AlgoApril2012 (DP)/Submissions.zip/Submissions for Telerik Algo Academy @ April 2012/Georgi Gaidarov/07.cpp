#include <iostream>
#include <map>
#include <cstdio>
#include <string>
#include <queue>

using namespace std;

int max(int a, int b)
{
    if(a>b) return a;
    return b;
}
int min(int a, int b)
{
    if(a<b) return a;
    return b;
}

int n;
int p[50];
int d;

int minnest = 60;


bool beenat[50][1000][5][26];
void dfs(int at, int ma, int mi, int sofar)
{
    if(beenat[at][ma-mi][mi%5][sofar-1]) return;
    beenat[at][ma-mi][mi%5][sofar-1] = 1;

    if(at == n-1)
    {
        if(minnest > sofar) minnest = sofar;
        return;
    }

    if(ma-mi >= d)
    {
        if(minnest > sofar) minnest = sofar;
        return;
    }

    if(sofar > 26) return;

    dfs(at+1, max(ma, p[at+1]), min(mi, p[at+1]), sofar+1);

    if(at+2<n)
    dfs(at+2, max(ma, p[at+2]), min(mi, p[at+2]), sofar+1);
}

int main()
{
    cin>>n;
    for(int i=0; i<n; i++)
        cin>>p[i];
    cin>>d;

    int mi = p[0];
    int ma = p[0];
    for(int i=1; i<n; i++)
    {
        mi = min(mi, p[i]);
        ma = max(ma, p[i]);
    }
    if(ma-mi < d)
    {
        cout<<n<<endl;
        return 0;
    }
    dfs(0, p[0], p[0], 1);

    cout<<minnest<<endl;

}
