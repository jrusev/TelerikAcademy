#include <iostream>
#include <map>
#include <cstdio>
#include <string>
#include <cstring>
#include <queue>

using namespace std;


char mat[10][10];
    int n, m;

int goleft(char mat[10][10], int x, int y)
{
    int res = 1;
    for(int i=x+1; i<m; i++)
        if(mat[y][i] == '.')
            res++;
        else
            break;
    return res;
}

void goleftW(char mat[10][10], int x, int y, char w)
{
    mat[y][x] = w;
    for(int i=x+1; i<m; i++)
        if(mat[y][i] == '.')
            mat[y][i] = w;
        else
            break;
}
void goleftU(char mat[10][10], int x, int y, char w)
{
    mat[y][x] = '.';
    for(int i=x+1; i<m; i++)
        if(mat[y][i] == w)
            mat[y][i] = '.';
        else
            break;
}

int godown(char mat[10][10], int x, int y)
{
    int res = 1;
    for(int i=y+1; i<n; i++)
        if(mat[i][x] == '.')
            res++;
        else
            break;
    return res;

}

void godownW(char mat[10][10], int x, int y, char w)
{
    mat[y][x] = w;
    for(int i=y+1; i<n; i++)
        if(mat[i][x] == '.')
            mat[i][x] = w;
        else
            break;

}
void godownU(char mat[10][10], int x, int y, char w)
{
    mat[y][x] = '.';
    for(int i=y+1; i<n; i++)
        if(mat[i][x] == w)
            mat[i][x] = '.';
        else
            break;

}


void printm(char ma[10][10])
{
    for(int i=0; i<n; i++){
    for(int j=0; j<m; j++)
        cout<<ma[i][j];
        cout<<endl;} cout<<endl;
}


int T;
int bestboardz = 9999;
char bestm[10][10];
int boardz = 0;
void dfs(char m2[10][10])
{
    char mm[10][10];
    memcpy(mm, m2, 100);

    bool touched = 0;
    for(int i=0; i<n; i++)
    for(int j=0; j<m; j++)
    {
        if(mm[i][j] == '.')
        {
            touched = 1;

            bool skipped = 1;
            if(goleft(mm, j, i) != 1)
            {
                skipped = 0;


            goleftW(mm, j, i, 'A'+boardz);
            boardz++;
            //printm(mm);
            dfs(mm);
            boardz--;
            goleftU(mm, j, i, 'A'+boardz);
            }

            if(godown(mm, j, i)!= 1 || skipped)
            {


            godownW(mm, j, i, 'A'+boardz);
            boardz++;
            //printm(mm);
            dfs(mm);
            boardz--;
            }
            //
            //godownU(mm, j, i, 'A'+boardz);
            //boardz--;

            return;
        }

    }
    if(!touched)
    {
        if(bestboardz > boardz)
        {
            bestboardz = boardz;
            if(T==2)
            {
                memcpy(bestm, mm, 100);
            }
        }
    }
}



int main()
{
    //freopen("zad10in.in", "r", stdin);
    cin>>T;


    cin>>n>>m;
    for(int i=0; i<n; i++)
    for(int j=0; j<m; j++)
    {
        cin>>mat[i][j];
    }

    dfs(mat);


    if(T==1) cout<<bestboardz<<endl;
    else
    {
        for(int i=0; i<n; i++){
        for(int j=0; j<m; j++)
            cout<<bestm[i][j];
            cout<<endl;}
    }

}
