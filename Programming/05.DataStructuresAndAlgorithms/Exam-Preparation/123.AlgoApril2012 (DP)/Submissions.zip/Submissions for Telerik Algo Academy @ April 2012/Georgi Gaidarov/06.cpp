#include <iostream>
#include <map>
#include <cstdio>
#include <string>
#include <cstring>
#include <queue>

using namespace std;


int msgl;
int dp[50][50];
int least = 9999;
int dp2[55];

void dfs(int at, int sofar)
{
    //cout<<"dfs at "<<at<<" with cost so far "<<sofar<<endl;
    dp2[at] = sofar;

    for(int i = at+1; i<=msgl; i++)
    {
        //cout<<"doing a check if dp["<<at<<"]["<<i<<"] is not -1 (="<<dp[at][i]<<")\n";
    if( dp[at][i] != -1 && dp2[i] > dp2[at]+dp[at][i] )
        dfs(i, dp2[at]+dp[at][i]);
    }

}

int canitbe(char* a, char* b, int l)
{
    int res = 0;
    bool usd[l];
    bool fnd[l];
    memset(fnd, 0, l);
    memset(usd, 0, l);


    for(int i=0; i<l; i++)
        if(a[i] == b[i])
        {
            usd[i] = 1;
            fnd[i] = 1;
        }

    for(int i=0; i<l; i++)
    {
        if(fnd[i]) continue;

        bool fnd = 0;
        for(int j=0; j<l; j++)
        {
            if(usd[j]) continue;
            if(a[i] == b[j])
            {
                usd[j] = 1;
                res++;
                fnd = 1;
                break;
            }
        }

        if(!fnd) return -1;
    }
    return res;
}

int main()
{
    //freopen("zad6in.in", "r", stdin);
    for(int i=0; i<50; i++)
    for(int j=0; j<50; j++) dp[i][j] = -1;
    for(int i=0; i<55; i++) dp2[i] = 55;

    char msg[51];
    cin>>msg;
    msgl = strlen(msg);
    int n;
    cin>>n;
    char word[n][51];
    int wordl[n];
    for(int i=0; i<n; i++)
    {
        cin>>word[i];
        wordl[i] = strlen(word[i]);
    }

    for(int i=0; i<msgl-1; i++)
    {
        for(int j=0; j<n; j++)
            if(i+wordl[j] <= msgl)
            {
                int resu = canitbe(msg+i, word[j], wordl[j]);
                if(dp[i][i+wordl[j]] == -1) dp[i][i+wordl[j]] = resu;
                else if(dp[i][i+wordl[j]] > resu && resu != -1) dp[i][i+wordl[j]] = resu;
                //cout<<"dp["<<i<<"]["<<i+wordl[j]<<"] is now "<<dp[i][i+wordl[j]]<<endl;
                //cout<<"canitbe returned "<<dp[i][i+wordl[j]]<<" ("<<i<<", "<<wordl[j]<<")\n";
            }
    }

    dfs(0, 0);

    //for(int i=0; i<55; i++) cout<<dp2[i]<<"   "<<i<<endl;
    if(dp2[msgl] == 55) cout<<-1<<endl;
    else cout<<dp2[msgl]<<endl;
}
