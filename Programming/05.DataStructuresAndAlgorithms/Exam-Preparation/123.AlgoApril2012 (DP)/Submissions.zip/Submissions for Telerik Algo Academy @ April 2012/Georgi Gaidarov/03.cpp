#include <iostream>
#include <map>
#include <cstdio>
#include <string>
#include <cstring>
#include <queue>
#include<cstring>

using namespace std;

int main()
{
    char exp[81];
    cin>>exp;
    int n = strlen(exp);

    long long dp[80][80];
    memset(dp, 0, 80*80*sizeof(long long));

    long long sum[n];
    sum[2] = 1;
    sum[4] = 2;
    sum[6] = sum[4] /* okolo tiah */ + sum[4] /* zad tiah */ + sum[4] -1 /* pred tiah */;
    for(int i=8; i<=n; i+=2)
        sum[i] = 3*sum[i-2] -1;






    cout<<sum[n]<<endl;


}
