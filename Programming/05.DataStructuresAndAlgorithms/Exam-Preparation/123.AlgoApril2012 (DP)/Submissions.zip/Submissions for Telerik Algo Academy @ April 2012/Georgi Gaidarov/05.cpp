#include <iostream>
#include <map>
#include <cstdio>
#include <string>
#include <cstring>
#include <queue>

using namespace std;

int n;
int r, c;

void work(bool a[128][128], bool b[128][128])
{
    bool res[128][128];
    for(int i=0; i<r; i++)
    for(int j=0; j<c; j++)
    {
        int cc = 0;
        if(i!=0)
        {
            if( j!=0 ) cc+= a[i-1][j-1];
            cc += a[i-1][j];
            if(j+1 < c) cc+= a[i-1][j+1];
        }
        if( j!=0 ) cc+= a[i][j-1];
        if(j+1 < c) cc+= a[i][j+1];
        if(i+1 < r)
        {
            if( j!=0 ) cc+= a[i+1][j-1];
            cc += a[i+1][j];
            if(j+1 < c) cc+= a[i+1][j+1];
        }

        if(!a[i][j])
        {
            if(cc==3) res[i][j] = 1;
            else res[i][j] = 0;
        }
        else
        {
            if( cc == 2 || cc == 3) res[i][j] = 1;
            else res[i][j] = 0;
        }
    }
    memcpy(b[0], res[0], 128*128);
}


int count(bool a[128][128])
{

    int res = 0;
    for(int i=0; i<r; i++)
    for(int j=0; j<c; j++)
        res+=a[i][j];
    return res;
}

bool same(bool a[128][128], bool b[128][128])
{
    for(int i=0; i<r; i++)
    for(int j=0; j<c; j++)
    if(a[i][j] != b[i][j])
        return 0;
    return 1;
}

int main()
{
    //freopen("zad5in.in", "r", stdin);
    cin>>n;
    cin>>r>>c;
    bool g[128][128];

    for(int i=0; i<r; i++)
    for(int j=0; j<c; j++)
        cin>>g[i][j];

    for(int i=1; i<=n; i++)
    {
        bool tmp[128][128];
        memcpy(tmp[0], g[0], 128*128 );
        work(g, g);
        if(same(tmp, g)) break;
    }


    cout<<count(g)<<endl;
}
