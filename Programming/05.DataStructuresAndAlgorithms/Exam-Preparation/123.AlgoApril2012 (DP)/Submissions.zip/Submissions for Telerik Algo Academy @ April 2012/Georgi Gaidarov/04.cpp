#include <iostream>
#include <map>
#include <cstdio>
#include <string>
#include <cstring>
#include <queue>
#include <vector>

using namespace std;

int c;
int ch[50];
int b, m;


int maxval = -1;
bool vis[55][1005];

void dfs(int at, int val)
{
    if(vis[at][val]) return;
    vis[at][val] = 1;

    if(at >= c+1)
    {
        if(val > maxval)
        {
            maxval = val;
        }
        return;
    }


    if(val + ch[at] <= m)
        dfs(at+1, val+ch[at]);

    if(val - ch[at] >=0)
        dfs(at+1, val-ch[at]);
}


int main()
{
    //memset(vis, 0, 55*1005);
    //freopen("zad4in.in", "r", stdin);
    cin>>c;
    for(int i = 0; i<c; i++)
        cin>>ch[i];


    cin>>b>>m;

    dfs(0, b);

    cout<<maxval<<endl;
}
