#include <iostream>
#include <map>
#include <cstdio>
#include <string>
#include <queue>

using namespace std;

long long memo[15][15];

long long ss(int k, int n)
{
    if(memo[k][n] != 0)
        return memo[k][n];

    long long calc = 0;

    if(!k)
    {
        calc = n;
    }
    else
    {
        for(int i=1; i<=n; i++)
            calc += ss(k-1, i);
    }

    memo[k][n] = calc;
    return calc;
}

int main()
{
    int n, k;
    cin>>k>>n;

    cout<<ss(k, n)<<endl;

}
