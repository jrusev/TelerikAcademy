#include <iostream>
#include <map>
#include <cstdio>
#include <string>
#include <queue>

using namespace std;


    int n;
    int x[15];
    int y[15];
    int z[15];

bool used[15];

map<int, int> bitmap;

int maxel = 0;
int thisbit = 0;

void dfs(int xx, int yy, int h)
{
    

    if(h > maxel)
    {
        maxel = h;
    }

    for(int i=0; i<n; i++)
    {
        if(used[i]) continue;

        used[i] = 1;
        thisbit = thisbit & 1<<i;

        if(xx >= x[i] && yy >= y[i])
        {
            dfs(x[i], y[i], h+z[i]);
        }
        else
        if(x[i] != y[i] &&  xx >= y[i] && yy >= x[i])
        {
            dfs(y[i], x[i], h+z[i]);
        }


        if(xx >= x[i] && yy >= z[i])
        {
            dfs(x[i], z[i], h+y[i]);
        }
        else
        if(x[i] != z[i] &&  xx >= z[i] && yy >= x[i])
        {
            dfs(z[i], x[i], h+y[i]);
        }


        if(xx >= y[i] && yy >= z[i])
        {
            dfs(y[i], z[i], h+x[i]);
        }
        else
        if(y[i] != z[i] && xx >= z[i] && yy >= y[i])
        {
            dfs(z[i], y[i], h+x[i]);
        }

        used[i] = 0;
        thisbit = thisbit & !(1<<i);
    }
}


int main()
{
    cin>>n;
    for(int i=0; i<n; i++)
        cin>>x[i]>>y[i]>>z[i];

    /*
    for(int i=0; i<n; i++)
        if(x[i] > y[i])
        {
            int swab = x[i];
            x[i] = y[i];
            y[i] = swab;
        }
        */

    dfs(10000000, 10000000, 0);

    cout<<maxel<<endl;

}
