#include <iostream>
#include <map>
#include <cstdio>
#include <string>
#include <cstring>
#include <queue>

using namespace std;

int main()
{
    int r, w;
    cin>>r>>w;
    char p[2501];
    cin>>p;
    int pl = strlen(p);

    int goodD = 0;

    int streak = p[0] == 'G' ? 1 : -1;
    int strc = 0;
    for(int i=0; i<pl; i++)
    {
        if(p[i] == 'G')
        {
            if(streak == 1)
            {
                if(strc+1 > r)
                {
                    streak = -1;
                    strc=1;
                }
                else
                {
                    strc++;
                    goodD++;
                }
            }
            else
            {
                streak = 1;
                strc = 1;
                goodD++;
            }
        }
        else // Bad day predicted
        {
            if(streak == -1)
            {
                if(strc+1 > w)
                {
                    streak = 1;
                    strc = 1;
                }
                else
                {
                    strc++;
                    goodD++;
                }
            }
            else
            {
                streak = -1;
                strc = 1;
                goodD++;
            }
        }
    }

    cout<<goodD<<endl;

}
