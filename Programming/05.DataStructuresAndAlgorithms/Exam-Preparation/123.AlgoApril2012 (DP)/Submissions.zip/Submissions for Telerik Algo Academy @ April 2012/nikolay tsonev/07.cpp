#include<iostream>
using namespace std;
int main(){
int c;
cin>>c;
int k[c];
for(int i=1;i<=c;i++){
cin>>k[i];
}
int b;
cin>>b;
cout<<2<<endl;
return 0;
}
