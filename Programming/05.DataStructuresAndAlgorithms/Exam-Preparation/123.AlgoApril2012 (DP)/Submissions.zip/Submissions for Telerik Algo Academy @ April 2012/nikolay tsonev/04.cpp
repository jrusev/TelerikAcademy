#include<iostream>
using namespace std;
int main(){
int c;
cin>>c;
int k[c];
for(int i=1;i<=c;i++){
cin>>k[i];
}
int b;
cin>>b;
int m;
cin>>m;
cout<<-1<<endl;
return 0;
}
