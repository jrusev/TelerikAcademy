#include<iostream>
using namespace std;
int main(){
	int K,N;
	cin>>K>>N;
	int x[K+1][N];
	for(int i=0; i<=K; i++){
		for(int j=1; j<=N; j++){
		x[i][j]=0;
		}
	}
	for(int i=0; i<=K; i++){
		if(i==0){
		for(int j=1; j<=N; j++){
		x[i][j]=j;
		}
		}
		else{
		for(int j=1; j<=N; j++){
			for(int y=1; y<=j; y++){
			x[i][j]=x[i][j]+x[i-1][y];
			}
		}
		}
	}
	cout<<x[K][N]<<endl;
	return 0;
}

