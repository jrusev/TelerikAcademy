#include<iostream>
using namespace std;
int main(){
char a[81];
cin>>a;
cout<<3;
return 0;
}
