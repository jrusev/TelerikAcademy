#include<iostream>
using namespace std;
int main(){
int N;
long long t1,t2,t3;
cin>>t1>>t2>>t3;
cin>>N;
long long T[N];
T[1]=t1;
T[2]=t2;
T[3]=t3;
for(int i=4; i<=N; i++){
	T[i]=T[i-1]+T[i-2]+T[i-3];
	}
	cout<<T[N]<<endl;
	return 0;
	}
