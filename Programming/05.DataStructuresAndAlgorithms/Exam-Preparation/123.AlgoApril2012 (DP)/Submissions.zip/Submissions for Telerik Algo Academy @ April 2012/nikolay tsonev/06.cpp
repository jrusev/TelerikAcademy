#include<iostream>
#include<string.h>
using namespace std;
int main(){
string a;
cin>>a;
int n;
cin>>n;
string b;
cin>>b;
cout<<-1<<endl;

return 0;
}
