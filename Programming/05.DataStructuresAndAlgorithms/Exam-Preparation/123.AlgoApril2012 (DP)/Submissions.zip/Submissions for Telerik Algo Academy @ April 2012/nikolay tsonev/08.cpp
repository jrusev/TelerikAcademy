#include<iostream>
#include<string.h>
using namespace std;
int main(){
int a;
cin>>a;
int n;
cin>>n;
string b;
cin>>b;
cout<<0<<endl;

return 0;
}
