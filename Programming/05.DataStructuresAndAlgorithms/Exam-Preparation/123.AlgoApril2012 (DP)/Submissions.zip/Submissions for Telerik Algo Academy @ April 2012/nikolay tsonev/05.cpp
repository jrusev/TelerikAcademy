#include<iostream>
using namespace std;
int main(){
int c;
cin>>c;
int a,b;
cin>>a>>b;
int k[a][b];
for(int i=1;i<=a;i++){
    for(int j=1;j<=b;j++){
cin>>k[i][j];
}
}
cout<<12<<endl;
return 0;
}
