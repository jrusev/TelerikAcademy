#include<iostream>
using namespace std;
int main(){
int n;
cin>>n;
int x,y,z,sum;
sum=0;
for(int i=0; i<n; i++){
	cin>>x>>y>>z;
	sum=sum+z;
}
cout<<sum<<endl;
return 0;
}
