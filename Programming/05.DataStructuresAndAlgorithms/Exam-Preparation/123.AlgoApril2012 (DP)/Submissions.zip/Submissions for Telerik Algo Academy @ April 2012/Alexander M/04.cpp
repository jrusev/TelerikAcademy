#include <iostream>
using namespace std;
 
int main()
{
    int C;
    int B;
    int M;
    cin>>C;
    int integers[C];
    for (int i = 0; i < C; ++i)
    {
        cin>>integers[i];
    }
    cin>>B;
    cin>>M;
    int currentVolume = B;
    for (int i = 0; i < (sizeof(integers) / sizeof(int) ); ++i)
    {
        if (currentVolume + integers[i] > M && currentVolume - integers[i] < 0)
        {
            currentVolume = -1;
            break;
        }
        if (currentVolume + integers[i] <= M)
        {
            currentVolume = currentVolume + integers[i];
            continue;
        }
        else
        {
            currentVolume = currentVolume - integers[i];
            continue;
        }
    }
    cout<<currentVolume;
 
 
    return 0;
}