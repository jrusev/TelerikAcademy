#include <iostream>
using namespace std;

int superSum(int k, int n)
{
    if (k == 0)
    {
        return n;
    }

    if (k != 1)
    {
        int sumTotal = 0;
        for (int i = n; i >= 1; --i)
        {
            sumTotal += superSum(k - 1, i);
        }
        return sumTotal;

    }
    else
    {

        int sum = 0;
        for (int i = 0; i <=n; ++i )
        {

            sum += i;
        }
        return sum;
    }


}
int main()
{
    int k, n;
    cin>>k>>n;
    cout<< superSum(k, n);
    return 0;
}



