#include <iostream>
using namespace std;

int tribonaci(int f0, int f1, int f2, int n)
{

    if ( n == 1) return f0;
    else if (n == 2) return f1;
    else if (n == 3) return f2;
    int count = 3;
    while (count < n)
    {
        int first = f0;
        f0 = f1;
        f1 = f2;
        f2 = first + f0 + f1;
        ++count;
    }
    return f2;
}
int main()
{
    int f0, f1, f2, n;
    cin>>f0>>f1>>f2>>n;
    cout <<tribonaci(f0, f1, f2, n);
    return 0;
}

