#include <iostream>
using namespace std;



int main()
{
    int nivoPokolenie = 0;
    int pokolenie, R, C;
    cin>>pokolenie>>R>>C;
    int array[R][C];
    for (int i = 0; i <= R-1; ++i)
    {
        for (int j = 0; j <= C-1; ++j)
        {
            cin>>array[i][j];

        }
    }
    while (nivoPokolenie < pokolenie)
     {
         int novoPokolenie[R][C];
            for (int i = 0; i <= R - 1; ++i)
            {
                for (int j = 0; j <= C-1; ++j)
                {
                    int susedi[8];
                    for (int k = 0; k < 8; ++k)
                    {
                        susedi[k] = 0;
                    }
                    susedi[0] = array[i-1][j-1];
                    susedi[1] = array[i-1][j];
                    susedi[2] = array[i-1][j+1];
                    susedi[3] = array[i][j-1];
                    susedi[4] = array[i][j+1];
                    susedi[5] = array[i+1][j-1];
                    susedi[6] = array[i+1][j];
                    susedi[7] = array[i+1][j+1];
                    int  alive = 0;
                    int dead  = 0;
                    for (int h = 0; h < 8; ++h)
                    {
                        if (susedi[h] == 0) ++dead;
                        else if(susedi[h] == 1) ++alive;
                    }
                    if (array[i][j] == 0 && alive == 3)
                    {
                        novoPokolenie[i][j] = 1;
                    }
                    else if(array[i][j] == 0 && alive != 3)
                    {
                        novoPokolenie[i][j] = 0;
                    }
                    else if (array[i][j] == 1 && (alive == 2 || alive == 3))
                    {
                        novoPokolenie[i][j] = 1;
                    }
                    else if(array[i][j] == 1 && alive < 2)
                    {
                        novoPokolenie[i][j] = 0;
                    }
                    else if(array[i][j] == 1 && alive > 3)
                    {
                        novoPokolenie[i][j] = 0;
                    }
                    array[i][j] = novoPokolenie[i][j];
                }
            }
         ++nivoPokolenie;
     }
     int  broi = 0;
    for (int i = 0; i <= R - 1; ++i)
            {
                for (int j = 0; j <= C-1; ++j)
                {
                    if (array[i][j] == 1)
                    ++broi;
                }

            }
            cout<< broi;


}


