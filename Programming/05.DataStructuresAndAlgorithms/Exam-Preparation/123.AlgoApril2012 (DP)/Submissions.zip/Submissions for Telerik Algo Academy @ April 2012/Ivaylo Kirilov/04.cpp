/*
ID: ivailok1
TASK: 4
LANG: C++
*/

#include <iostream>
#include <set>
#include <queue>
#include <vector>
#include <cstdio>
#include <cmath>
#include <string.h>

using namespace std;

#define ll long long

int C,B,M;
int changes[51];
bool dp[51][1001];
int best=-1;

int main(){
    //freopen("4.in","r",stdin);
    //freopen("4.out","w",stdout);
    scanf("%d",&C);
    for(int i=1; i<=C; i++){
        scanf("%d",&changes[i]);
    }
    scanf("%d",&B);
    scanf("%d",&M);
    dp[0][B]=true;
    for(int i=1; i<=C; i++){
        for(int j=0; j<=M; j++){
            if(dp[i-1][j]){
                if(j+changes[i]<=M){
                    dp[i][j+changes[i]]=true;
                    if(i==C){
                        best=max(best,j+changes[i]);
                    }
                }
                if(j-changes[i]>=0){
                    dp[i][j-changes[i]]=true;
                    if(i==C){
                        best=max(best,j-changes[i]);
                    }
                }
            }
        }
    }
    printf("%d\n",best);
    return 0;
}
