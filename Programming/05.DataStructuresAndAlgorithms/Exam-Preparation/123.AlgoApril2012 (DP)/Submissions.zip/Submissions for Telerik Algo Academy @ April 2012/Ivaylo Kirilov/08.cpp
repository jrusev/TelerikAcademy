/*
ID: ivailok1
TASK: 8
LANG: C++
*/

#include <iostream>
#include <set>
#include <queue>
#include <vector>
#include <cstdio>
#include <cmath>
#include <string.h>

using namespace std;

#define ll long long

int R,W;
string S;
int dpright[2501][2501];
int dpwrong[2501][2501];

int main(){
    //freopen("8.in","r",stdin);
    //freopen("8.out","w",stdout);
    memset(dpright,-1,sizeof(dpright));
    memset(dpwrong,-1,sizeof(dpwrong));
    cin>>R>>W;
    cin>>S;
    dpright[0][R]=0;
    dpwrong[0][W]=0;
    for(int i=1; i<=S.size(); i++){
        if(S[i-1]=='G'){
            for(int j=1; j<=R; j++){
                if(dpright[i-1][j]!=-1){
                    dpright[i][j-1]=max(dpright[i][j-1],dpright[i-1][j]+1);
                }
            }
            for(int j=0; j<=R; j++){
                if(dpright[i-1][j]!=-1){
                    dpwrong[i][W-1]=max(dpwrong[i][W-1],dpright[i-1][j]);
                }
            }
            for(int j=1; j<=W; j++){
                if(dpwrong[i-1][j]!=-1){
                    dpwrong[i][j-1]=max(dpwrong[i][j-1],dpwrong[i-1][j]);
                }
            }
            for(int j=0; j<=W; j++){
                if(dpwrong[i-1][j]!=-1){
                    dpright[i][R-1]=max(dpright[i][R-1],dpwrong[i-1][j]+1);
                }
            }
        }
        else{
            for(int j=1; j<=R; j++){
                if(dpright[i-1][j]!=-1){
                    dpright[i][j-1]=max(dpright[i][j-1],dpright[i-1][j]);
                }
            }
            for(int j=0; j<=R; j++){
                if(dpright[i-1][j]!=-1){
                    dpwrong[i][W-1]=max(dpwrong[i][W-1],dpright[i-1][j]+1);
                }
            }
            for(int j=1; j<=W; j++){
                if(dpwrong[i-1][j]!=-1){
                    dpwrong[i][j-1]=max(dpwrong[i][j-1],dpwrong[i-1][j]+1);
                }
            }
            for(int j=0; j<=W; j++){
                if(dpwrong[i-1][j]!=-1){
                    dpright[i][R-1]=max(dpright[i][R-1],dpwrong[i-1][j]);
                }
            }
        }
    }
    int best=0;
    for(int i=0; i<=R; i++){
        best=max(best,dpright[S.size()][i]);
    }
    for(int i=0; i<=W; i++){
        best=max(best,dpwrong[S.size()][i]);
    }
    printf("%d\n",best);
    return 0;
}
