/*
ID: ivailok1
TASK: 5
LANG: C++
*/

#include <iostream>
#include <set>
#include <queue>
#include <vector>
#include <cstdio>
#include <cmath>
#include <string.h>

using namespace std;

#define ll long long

int N,R,C;
bool table[2][130][130];
int d[8][2]={{-1,-1},{-1,0},{-1,1},{0,-1},{0,1},{1,-1},{1,0},{1,1}};

void print(int curr){
    for(int i=1; i<=R; i++){
        for(int j=1; j<=C; j++){
            cout<<table[curr][i][j]<<" ";
        }
        cout<<endl;
    }
}

int main(){
    //freopen("5.in","r",stdin);
    //freopen("5.out","w",stdout);
    scanf("%d",&N);
    scanf("%d %d",&R,&C);
    int at=0;
    int x;
    for(int i=1; i<=R; i++){
        for(int j=1; j<=C; j++){
            scanf("%d",&x);
            table[at][i][j]= x==1 ? true : false;
        }
    }
    for(int i=0; i<N; i++){
        for(int j=1; j<=R; j++){
            for(int k=1; k<=C; k++){
                int cnt=0;
                for(int l=0; l<8; l++){
                    if(table[at][j+d[l][0]][k+d[l][1]])
                        cnt++;
                }
                if(table[at][j][k]==0){
                    if(cnt==3){
                        table[!at][j][k]=true;
                    }
                    else{
                        table[!at][j][k]=false;
                    }
                }
                else{
                    if(cnt==2 || cnt==3){
                        table[!at][j][k]=true;
                    }
                    else{
                        table[!at][j][k]=false;
                    }
                }
            }
        }
        at=!at;
    }
    int cnt=0;
    for(int i=1; i<=R; i++){
        for(int j=1; j<=C; j++){
            if(table[at][i][j]){
                cnt++;
            }
        }
    }
    printf("%d\n",cnt);
    return 0;
}
