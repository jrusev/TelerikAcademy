/*
ID: ivailok1
TASK: 6
LANG: C++
*/

#include <iostream>
#include <set>
#include <queue>
#include <vector>
#include <cstdio>
#include <cmath>
#include <string.h>

using namespace std;

#define ll long long

string mess;
string word[51];
int N;
int dp[51];
int used[30];

int main(){
    //freopen("6.in","r",stdin);
    //freopen("6.out","w",stdout);
    memset(dp,-1,sizeof(dp));
    cin>>mess;
    scanf("%d",&N);
    char a;
    scanf("%c",&a);
    scanf("%c",&a);
    int at=0;
    while(a!='\n'){
        if(a==' '){
            at++;
        }
        else{
            word[at]+=a;
        }
        scanf("%c",&a);
    }
    dp[0]=0;
    for(int i=1; i<=mess.size(); i++){
        for(int j=0; j<N; j++){
            memset(used,0,sizeof(used));
            int k=word[j].size();
            if(i>=k && dp[i-k]!=-1){
                for(int l=i-k+1; l<=i; l++){
                    used[mess[l-1]-'a']++;
                }
                for(int l=0; l<k; l++){
                    used[word[j][l]-'a']--;
                }
                bool flag=1;
                for(int l=0; l<26; l++){
                    if(used[l]!=0){
                        flag=false;
                    }
                }
                if(flag){
                    int cnt=0;
                    for(int l=0; l<k; l++){
                        if(word[j][l]!=mess[l-1+i-k+1]){
                            cnt++;
                        }
                    }
                    if(dp[i]==-1){
                        dp[i]=dp[i-k]+cnt;
                    }
                    else{
                        dp[i]=min(dp[i],dp[i-k]+cnt);
                    }
                }
            }
        }
    }
    printf("%d\n",dp[mess.size()]);
    return 0;
}
