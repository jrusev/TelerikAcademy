/*
ID: ivailok1
TASK: 3
LANG: C++
*/

#include <iostream>
#include <set>
#include <queue>
#include <vector>
#include <cstdio>
#include <cmath>
#include <string.h>
#include <map>

using namespace std;

#define ll long long

string input;
map< pair<string,int>,ll > dp;
int N;

bool isValid(string curr){
    int val=0;
    for(int i=0; i<N; i++){
        if(curr[i]==')')
            val--;
        else
            val++;
        if(val<0)
            return false;
    }
    if(val!=0){
        return false;
    }
    return true;
}

ll get(int n,string curr){
    pair<string,int> state=make_pair(curr,n);
    if(dp.find(state)!=dp.end())
        return dp[state];
    if(n==0){
        if(isValid(curr)){
            return dp[state]=1;
        }
        else{
            return dp[state]=0;
        }
    }
    dp[state]=0;
    if(curr[n-1]=='?'){
        curr[n-1]=')';
        dp[state]+=get(n-1,curr);
        curr[n-1]='(';
        dp[state]+=get(n-1,curr);
    }
    else{
        dp[state]=get(n-1,curr);
    }
    return dp[state];
}

int main(){
    //freopen("3.in","r",stdin);
    //freopen("3.out","w",stdout);
    cin>>input;
    N=input.size();
    printf("%lld\n",get(N,input));
    return 0;
}
