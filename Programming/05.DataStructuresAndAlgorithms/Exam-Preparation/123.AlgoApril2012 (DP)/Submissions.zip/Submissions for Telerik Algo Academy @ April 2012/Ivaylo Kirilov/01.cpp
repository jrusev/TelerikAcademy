/*
ID: ivailok1
TASK: 1
LANG: C++
*/

#include <iostream>
#include <set>
#include <queue>
#include <vector>
#include <cstdio>
#include <cmath>
#include <string.h>

using namespace std;

#define ll long long

long long dp[21];
int N;

int main(){
    //freopen("1.in","r",stdin);
    //freopen("1.out","w",stdout);
    scanf("%lld %lld %lld %d",&dp[1],&dp[2],&dp[3],&N);
    for(int i=4; i<=N; i++){
        dp[i]=dp[i-1]+dp[i-2]+dp[i-3];
    }
    printf("%lld\n",dp[N]);
    return 0;
}
