/*
ID: ivailok1
TASK: 7
LANG: C++
*/

#include <iostream>
#include <set>
#include <queue>
#include <vector>
#include <cstdio>
#include <cmath>
#include <string.h>

using namespace std;

#define ll long long

int N;
int score[51];
int V;
int dp[51][51];

int get(int from,int to){
    if(dp[from][to]!=-1){
        return dp[from][to];
    }
    if(from>to){
        return 0;
    }
    if(to==from){
        dp[from][to]=1;
        return 1;
    }
    dp[from][to]=1;
    if(to-2>=from)
        dp[from][to]+=min(get(from,to-2),get(from,to-1));
    else
        dp[from][to]+=get(from,to-1);
    return dp[from][to];
}

int main(){
    //freopen("7.in","r",stdin);
    //freopen("7.out","w",stdout);
    memset(dp,-1,sizeof(dp));
    scanf("%d",&N);
    for(int i=1; i<=N; i++){
        scanf("%d",&score[i]);
    }
    scanf("%d",&V);

    int best=N;
    for(int i=1; i<=N; i++){
        for(int j=i+1; j<=N; j++){
            if(abs(score[i]-score[j])>=V){
                best=min(best,get(i,j)+get(1,i)-1);
            }
        }
    }
    printf("%d\n",best);
    return 0;
}
