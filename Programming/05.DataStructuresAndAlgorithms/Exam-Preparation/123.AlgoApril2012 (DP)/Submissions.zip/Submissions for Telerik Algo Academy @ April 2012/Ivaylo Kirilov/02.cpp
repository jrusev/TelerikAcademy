/*
ID: ivailok1
TASK: 2
LANG: C++
*/

#include <iostream>
#include <set>
#include <queue>
#include <vector>
#include <cstdio>
#include <cmath>
#include <string.h>

using namespace std;

#define ll long long

long long dp[15][15];
int K,N;

long long get(int k,int n){
    if(dp[k][n]!=-1){
        return dp[k][n];
    }
    if(k==0){
        return n;
    }
    dp[k][n]=0;
    for(int i=1; i<=n; i++){
        dp[k][n]+=get(k-1,i);
    }
    return dp[k][n];
}

int main(){
    //freopen("2.in","r",stdin);
    //freopen("2.out","w",stdout);
    memset(dp,-1,sizeof(dp));
    scanf("%d %d",&K,&N);
    printf("%lld\n",get(K,N));
    return 0;
}
