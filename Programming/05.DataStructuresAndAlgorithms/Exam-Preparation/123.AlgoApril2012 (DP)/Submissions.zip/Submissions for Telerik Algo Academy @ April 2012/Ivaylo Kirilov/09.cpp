/*
ID: ivailok1
TASK: 9
LANG: C++
*/

#include <iostream>
#include <set>
#include <queue>
#include <vector>
#include <cstdio>
#include <cmath>
#include <string.h>

using namespace std;

#define ll long long

const int INF=(1<<30);

struct RECT{
    int x,y,z;
};

RECT rect[16][7];
int used[16];
int N;
int dp[16][7];
int best;

void form(int a,int b,int h,int at,int n){
    rect[n][at].x=a;
    rect[n][at].y=b;
    rect[n][at].z=h;
}

int get(int at,int c){
    if(dp[at][c]!=-1){
        return dp[at][c];
    }
    if(at==0){
        return 0;
    }
    for(int i=0; i<=N; i++){
        if(used[i])
            continue;
        used[i]=1;
        for(int j=0; j<6; j++){
            if(rect[at][c].x<=rect[i][j].x && rect[at][c].y<=rect[i][j].y){
                dp[at][c]=max(dp[at][c],get(i,j)+rect[at][c].z);
            }
        }
        used[i]=0;
    }
    return dp[at][c];
}

int main(){
    //freopen("9.in","r",stdin);
    //freopen("9.out","w",stdout);
    memset(dp,-1,sizeof(dp));
    scanf("%d",&N);
    for(int i=0; i<6; i++){
        rect[0][i].x=INF;
        rect[0][i].y=INF;
        rect[0][i].z=0;
    }
    int x,y,z;
    for(int i=1; i<=N; i++){
        scanf("%d %d %d",&x,&y,&z);
        form(x,y,z,0,i);
        form(y,x,z,1,i);
        form(x,z,y,2,i);
        form(z,x,y,3,i);
        form(z,y,x,4,i);
        form(y,z,x,5,i);
    }
    dp[0][0]=0;
    for(int i=1; i<=N; i++){
        used[i]=1;
        for(int j=0; j<6; j++){
            best=max(best,get(i,j));
        }
        used[i]=0;
    }
    printf("%d\n",best);
    return 0;
}
