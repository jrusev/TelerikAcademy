#include<iostream>
#include<cstdio>
#define to fr^1
int fr;
long long A[64][2];
char ch;
int main()
{
	for(A[0][0]=1;;fr=to)
	{
		ch=getchar();
		if(ch=='('||ch=='?')
			for(int i=0;i<40;++i)
				A[i+1][to]+=A[i][fr];
		if(ch==')'||ch=='?')
			for(int i=40;i;--i)
				A[i-1][to]+=A[i][fr];
		if(ch!='('&&ch!=')'&&ch!='?')
		{
			if(A[0][fr]>A[0][to])
				std::cout<<A[0][fr]<<"\n";
			else std::cout<<A[0][to]<<"\n";
			return 0;
		}
		for(int i=0;i<41;++i)
			A[i][fr]=0;
	}
}
