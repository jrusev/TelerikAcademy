#include<cstdio>
#include<queue>
int n,razno,A[64],bst,x,y;
int ans[1024][1024][3];
std::queue<int> q[3];
int main()
{
	scanf("%d",&n);bst=n;
	for(int i=0;i<n;++i)
		scanf("%d",A+i);
	scanf("%d",&razno);
	if(n<3)
	{
		printf("%d\n",n);
		return 0;
	}
	ans[A[0]][A[0]][0]=1;
	q[0].push(A[0]*1025);
	if(A[0]>A[1])
	{
		if(A[0]-A[1]<razno)
		{
			ans[A[0]][A[1]][0]=2;
			q[1].push(1024*A[0]+A[1]);
		}
		else{puts("2");return 0;}
	}else{
		if(A[1]-A[0]<razno)
		{
			ans[A[1]][A[0]][0]=2;
			q[1].push(1024*A[1]+A[0]);
		}
		else{puts("2");return 0;}
	}
	for(int i=2;i<n;++i)
	{
		while(!q[(i-2)%3].empty())
		{
			x=q[(i-2)%3].front();
			y=x&1023;
			x>>=10;
			q[(i-2)%3].pop();
			if(A[i]>x)
			{
				if(A[i]-y<razno)
				{
					if(ans[A[i]][y][i%3]==0||ans[A[i]][y][i%3]>ans[x][y][(i-2)%3]+1)
					{
						ans[A[i]][y][i%3]=ans[x][y][(i-2)%3]+1;
						q[i%3].push(A[i]*1024+y);
					}
				}else if(ans[x][y][(i-2)%3]+1<bst)
					bst=ans[x][y][(i-2)%3]+1;
			}else if(A[i]<y)
			{
				if(x-A[i]<razno)
				{
					if(ans[x][A[i]][i%3]==0||ans[x][A[i]][i%3]>ans[x][y][(i-2)%3]+1)
					{
						ans[x][A[i]][i%3]=ans[x][y][(i-2)%3]+1;
						q[i%3].push(x*1024+A[i]);
					}
				}else if(ans[x][y][(i-2)%3]+1<bst)
					bst=ans[x][y][(i-2)%3]+1;
			}else{
				if(ans[x][y][i%3]==0||ans[x][y][i%3]>ans[x][y][(i-2)%3]+1)
				{
					ans[x][y][i%3]=ans[x][y][(i-2)%3]+1;
					q[i%3].push(x*1024+y);
				}
			}
			//ans[x][y][(i-2)%3]=0;
		}
		for(int as=q[(i-1)%3].size();as>0;--as)
		{
			x=q[(i-1)%3].front();
			q[(i-1)%3].push(x);
			y=x&1023;
			x>>=10;
			q[(i-1)%3].pop();
			if(A[i]>x)
			{
				if(A[i]-y<razno)
				{
					if(ans[A[i]][y][i%3]==0||ans[A[i]][y][i%3]>ans[x][y][(i-1)%3]+1)
					{
						ans[A[i]][y][i%3]=ans[x][y][(i-1)%3]+1;
						q[i%3].push(A[i]*1024+y);
					}
				}else if(ans[x][y][(i-1)%3]+1<bst)
					bst=ans[x][y][(i-1)%3]+1;
			}else if(A[i]<y)
			{
				if(x-A[i]<razno)
				{
					if(ans[x][A[i]][i%3]==0||ans[x][A[i]][i%3]>ans[x][y][(i-1)%3]+1)
					{
						ans[x][A[i]][i%3]=ans[x][y][(i-1)%3]+1;
						q[i%3].push(x*1024+A[i]);
					}
				}else if(ans[x][y][(i-1)%3]+1<bst)
					bst=ans[x][y][(i-1)%3]+1;
			}else{
				if(ans[x][y][i%3]==0||ans[x][y][i%3]>ans[x][y][(i-1)%3]+1)
				{
					ans[x][y][i%3]=ans[x][y][(i-1)%3]+1;
					q[i%3].push(x*1024+y);
				}
			}
		}
	}
	while(!q[(n-1)%3].empty())
	{
		x=q[(n-1)%3].front();
		q[(n-1)%3].pop();
		y=x&1023;
		x>>=10;
		if(ans[x][y][(n-1)%3]<bst)
			bst=ans[x][y][(n-1)%3];
	}
	while(!q[(n-2)%3].empty())
	{
		x=q[(n-2)%3].front();
		q[(n-2)%3].pop();
		y=x&1023;
		x>>=10;
		if(ans[x][y][(n-2)%3]<bst)
			bst=ans[x][y][(n-2)%3];
	}
	printf("%d\n",bst);
	return 0;
}
