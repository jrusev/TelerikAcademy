#include<cstdio>
#define to fr^1
int r,w,fr,bst;
int R[2500][2];
int W[2500][2];
bool f;
int main()
{
	scanf("%d%d",&r,&w);
	getchar();
	for(;;)
	{
		f=false;
		switch(getchar())
		{
			case 'G':f=true;
			case 'B':
				for(int i=0;i<r;++i)
				{
					if(R[i+1][to]<R[i][fr]+f)
						if(bst<(R[i+1][to]=R[i][fr]+f))
							bst=R[i+1][to];
					if(W[1][to]<R[i][fr]+!f)
						if(bst<(W[1][to]=R[i][fr]+!f))
							bst=W[1][to];
				}
				if(W[1][to]<R[r][fr]+!f)
					if(bst<(W[1][to]=R[r][fr]+!f))
						bst=W[1][to];
				for(int i=0;i<w;++i)
				{
					if(W[i+1][to]<W[i][fr]+!f)
						if(bst<(W[i+1][to]=W[i][fr]+!f))
							bst=W[i+1][to];
					if(R[1][to]<W[i][fr]+f)
						if(bst<(R[1][to]=W[i][fr]+f))
							bst=R[1][to];
				}
				if(R[1][to]<W[w][fr]+f)
					if(bst<(R[1][to]=W[w][fr]+f))
						bst=R[1][to];
			break;
			default:
				printf("%d\n",bst);
				return 0;
		}
		fr=to;
	}
}
