#include<cstdio>
int n,k,msz,wsz[64],A[64]={1};
struct dis{
	int l[32];
}_msg[64],_word[64];
inline dis operator-(dis A,const dis &B)
{
	for(int i=0;i<26;++i)
		A.l[i]-=B.l[i];
	return A;
}
inline bool operator==(const dis &A,const dis &B)
{
	for(int i=0;i<26;++i)
		if(A.l[i]!=B.l[i])
			return false;
	return true;
}
char ch,msg[64],word[64][64];
inline void occ(int i,int j)
{
	for(int x=k=0;x<wsz[j];++x)
		if(msg[i+x]!=word[j][x])
			++k;
}
int main()
{
	scanf("%s",msg);
	for(;msg[msz];++msz)
	{
		_msg[msz+1]=_msg[msz];
		++_msg[msz+1].l[msg[msz]-'a'];
	}
	scanf("%d",&n);getchar();
	for(int i=0;i<n;++i)
	{
		for(;;++wsz[i])
		{
			ch=getchar();
			if(ch<'a'||ch>'z')break;
			word[i][wsz[i]]=ch;
			++_word[i].l[word[i][wsz[i]]-'a'];
		}
	}
	for(int i=0;i<msz;++i)
	{
		if(A[i]>0)
		{
			for(int j=0;j<n;++j)
			{
				if(i+wsz[j]<=msz&&_word[j]==(_msg[i+wsz[j]]-_msg[i]))
				{
					occ(i,j);k+=A[i];
					if(A[i+wsz[j]]==0||A[i+wsz[j]]>k)
						A[i+wsz[j]]=k;
				}
			}
		}
	}
	printf("%d\n",A[msz]-1);
	return 0;
}
