#include<cstdio>
bool A[2][128][128];
int r,c,n,curr,fr,k;
int neigh(int x,int y)
{
	int ret=0;
	if(x>0)
	{
		if(y>0)ret+=A[fr][x-1][y-1];
		ret+=A[fr][x-1][y];
		if(y<c-1)ret+=A[fr][x-1][y+1];
	}
	if(y>0)ret+=A[fr][x][y-1];
	if(y<c-1)ret+=A[fr][x][y+1];
	if(x<r-1)
	{
		if(y>0)ret+=A[fr][x+1][y-1];
		ret+=A[fr][x+1][y];
		if(y<c-1)ret+=A[fr][x+1][y+1];
	}
	return ret;
}
int main()
{
	scanf("%d%d%d",&n,&r,&c);
	for(int i=0;i<r;++i)
		for(int j=0;j<c;++j)
		{
			scanf("%d",&A[0][i][j]);
			if(A[0][i][j])
				++curr;
		}
	for(int K=0;K<n;++K)
	{
		for(int i=0;i<r;++i)
		{
			for(int j=0;j<c;++j)
			{
				k=neigh(i,j);
				if(A[fr][i][j])
					A[fr^1][i][j]=(k==2||k==3);
				else A[fr^1][i][j]=(k==3);
				curr+=A[fr^1][i][j]-A[fr][i][j];
			}
		}
		fr^=1;
	}
	printf("%d\n",curr);
	return 0;
}
