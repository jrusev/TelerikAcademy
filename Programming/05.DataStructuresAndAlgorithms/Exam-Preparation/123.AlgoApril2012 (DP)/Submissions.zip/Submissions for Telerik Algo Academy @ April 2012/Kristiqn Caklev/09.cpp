#include<iostream>
#include<cstdio>
int n,x,y,z;
long long ans;
struct _3{
	int x,y,z;
	inline void operator()(int X,int Y,int Z){x=X;y=Y;z=Z;}
}bloci[64];
long long H[1<<15][64];
inline long long mx(long long A,long long B)
{return A>B?A:B;}
inline long long mn(long long A,long long B)
{return A<B?A:B;}
int main()
{
	scanf("%d",&n);
	for(int i=0;i<n;++i)
	{
		scanf("%d%d%d",&x,&y,&z);
		bloci[3*i](mn(x,y),mx(x,y),z);ans=mx(ans,H[1<<i][3*i]=z);
		bloci[3*i+1](mn(x,z),mx(x,z),y);ans=mx(ans,H[1<<i][3*i+1]=y);
		bloci[3*i+2](mn(y,z),mx(y,z),x);ans=mx(ans,H[1<<i][3*i+2]=x);
	}
	for(int i=1;i<(1<<n);++i)
	{
		for(int j=0;j<3*n;++j)
		{
			if((i>>(j/3))&1)
			{
				for(int k=0;k<3*n;++k)
				{
					if((~i>>(k/3))&1)
					{
						if(H[i][j]>0)
						{
							if(bloci[j].x>=bloci[k].x&&bloci[j].y>=bloci[k].y)
							{
								if(H[i|(1<<(k/3))][k]<H[i][j]+bloci[k].z)
									ans=mx(ans,H[i|(1<<(k/3))][k]=H[i][j]+bloci[k].z);
							}
						}
					}
				}
			}
		}
	}
//	printf("%d\n",ans);
	std::cout<<ans<<"\n";
	return 0;
}
