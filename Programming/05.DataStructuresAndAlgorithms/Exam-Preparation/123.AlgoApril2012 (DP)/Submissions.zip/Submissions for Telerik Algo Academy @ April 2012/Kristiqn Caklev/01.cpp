#include<iostream>
#define n red[0]
long long red[32];
int main()
{
	std::cin>>red[1]>>red[2]>>red[3]>>n;
	for(int i=4;i<=n;++i)
		red[i]=red[i-3]+red[i-2]+red[i-1];
	std::cout<<red[n]<<"\n";
	return 0;
}
