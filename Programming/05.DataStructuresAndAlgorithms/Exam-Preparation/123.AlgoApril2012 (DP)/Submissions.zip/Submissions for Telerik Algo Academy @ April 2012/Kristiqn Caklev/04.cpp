#include<cstdio>
#include<map>
int c,A[64],b,m;
struct _2{
	int ind,vol;
	_2(int x,int y)
	{ind=x;vol=y;}
};
inline bool operator<(const _2 &X,const _2 &Y)
{
	if(X.ind==Y.ind)
		return X.vol>Y.vol;
	return X.ind<Y.ind;
}
std::map<_2,const void*> M;
std::map<_2,const void*>::iterator it;
int main()
{
	scanf("%d",&c);
	for(int i=0;i<c;++i)
		scanf("%d",A+i);
	scanf("%d%d",&b,&m);
	M[_2(0,b)]=0;
	M[_2(c,-1)]=0;
	it=M.begin();
	for(int i=0;i<c;++i)
	{
		for(;it->first.ind==i;++it)
		{
			if(it->first.vol-A[i]>=0)
				M[_2(it->first.ind+1,it->first.vol-A[i])]=0;
			if(it->first.vol+A[i]<=m)
				M[_2(it->first.ind+1,it->first.vol+A[i])]=0;
		}
	}
	printf("%d\n",it->first.vol);
	return 0;
}
