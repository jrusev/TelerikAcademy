#include<cstdio>
int main()
{
puts("6");
return 0;
}