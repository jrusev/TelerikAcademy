#include<iostream>
#include<cstring>
using namespace std;
int main()
{
     char a[2500];
     int R,W,n,nn;
     cin>>R>>W;
     cin.get();
     cin.get(a,2500,'\n');
     n=strlen(a);
     nn=R-(W-1);
     cout<<n-(n-nn)<<endl;
     //system("pause");
     return 0;
}
