#include<iostream>
using namespace std;
int main()
{
     char a;
     int brs=0,brv=0;
     do
     {
        cin.get(a);
        if(a=='('||a==')')brs++;
        if(a=='?') brv++;
     }
     while(a!='\n');
     if(brv>brs)cout<<(brv-brs)/2<<endl;
     if(brv<brs) cout<<(brs-brv)/2<<endl;
     if(brv==brs)cout<<1<<endl;
     //system("pause");
     return 0;
}
