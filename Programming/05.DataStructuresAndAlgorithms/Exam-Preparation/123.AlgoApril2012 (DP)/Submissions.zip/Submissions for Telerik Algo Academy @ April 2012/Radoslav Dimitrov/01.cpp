#include<iostream>
using namespace std;
int main()
{
     long long t1,t2,t3,n,s=0,t[21];
     for(int i=0;i<3;i++)
      cin>>t[i];
     cin>>n;
     for(int i=3;i<=n-1;i++)
     {
         s=t[i-1]+t[i-2]+t[i-3];
         t[i]=s;    
     }
     cout<<t[n-1]<<endl;
     //system("pause");
     return 0;
}