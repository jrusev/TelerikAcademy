#include<iostream>
using namespace std;
int main()
{
   bool l[130][130]={0},l2[130][130]={0};
   int n,r,c,s=0;
   cin>>n>>r>>c;
   for(int i=1;i<=r;i++)
   for(int j=1;j<=c;j++)
   cin>>l[i][j];
   for(int i=0;i<n;i++)
   {
   for(int j=1;j<=r;j++)
      for(int o=1;o<=c;o++)
      {
         s=l[j-1][o-1]+l[j-1][o]+l[j-1][o+1]+l[j][o-1]+l[j][o+1]+l[j+1][o-1]+l[j+1][o]+l[j+1][o+1];
         if(l[j][o]==0 && s==3)l2[j][o]=1;
         else if(l[j][o]==0 && s<3)l2[j][o]=0;
         else if(l[j][o]==1 && (s==2 || s==3))l2[j][o]=1;
         else if(l[j][o]==1 && s<2)l2[j][o]=0;
         else if(l[j][o]==1 && s>3)l2[j][o]=0;
      }
      s=0;
    for(int j=1;j<=r;j++)for(int o=1;o<=c;o++)l[j][o]=l2[j][o];}
    for(int i=1;i<=r;i++)
    for(int j=1;j<=c;j++)
    s=s+l[i][j];
    cout<<s<<endl;
    return 0;
}