#include<iostream>
using namespace std;
long long br,i,n1,n,j,i1,s[129][129],a[129][129],m,fl,ns[129][129];
int main () {
cin>>n1;
cin>>n>>m;
for(i=1;i<=n;i++) {
 for(j=1;j<=m;j++) {
  cin>>a[i][j];  
  if(a[i][j]==1) {
  br++;
   s[i-1][j-1]++;
   s[i-1][j]++;
   s[i-1][j+1]++;
   s[i][j-1]++;
   s[i][j+1]++;
   s[i+1][j-1]++;
   s[i+1][j]++;
   s[i+1][j+1]++;
  }
 } 
}
for(i1=1;i1<=n1;i1++) {
 for(i=1;i<=n;i++) {
  for(j=1;j<=m;j++) {
   if(a[i][j]==0 && s[i][j]==3) {
    a[i][j]=1;
   ns[i-1][j-1]++;
   ns[i-1][j]++;
   ns[i-1][j+1]++;
   ns[i][j-1]++;
   ns[i][j+1]++;
   ns[i+1][j-1]++;
   ns[i+1][j]++;
   ns[i+1][j+1]++;    
    br++;
   }
   if(a[i][j]==1 && s[i][j]<2) {
    a[i][j]=0;
       ns[i-1][j-1]--;
   ns[i-1][j]--;
   ns[i-1][j+1]--;
   ns[i][j-1]--;
   ns[i][j+1]--;
   ns[i+1][j-1]--;
   ns[i+1][j]--;
   ns[i+1][j+1]--;
    br--;
   }
   if(a[i][j]==1 && s[i][j]>3) {
    a[i][j]=0;
    br--;
   ns[i-1][j-1]--;
   ns[i-1][j]--;
   ns[i-1][j+1]--;
   ns[i][j-1]--;
   ns[i][j+1]--;
   ns[i+1][j-1]--;
   ns[i+1][j]--;
   ns[i+1][j+1]--;
   }
   if(br==n*m) {
    fl==1;
    break;
   }
  }
  if(fl==1) {
   break;
}
 }
 if(fl==1) {
   break;
}
for(i=1;i<=n;i++)  {
 for(j=1;j<=m;j++) {

  s[i][j]=ns[i][j]+s[i][j];
if(s[i][j]<0) {
 s[i][j]=0;
}
 
 }
 
}
}
cout<<br<<endl;

return 0;
}