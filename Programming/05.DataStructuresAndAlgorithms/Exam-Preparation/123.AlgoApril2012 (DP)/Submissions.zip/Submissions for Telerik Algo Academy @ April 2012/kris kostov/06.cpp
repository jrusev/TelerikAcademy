#include<iostream>
using namespace std;
long long k,n,a[15][15],i1,i,j;
string s,s1;
int main () {
cin>>s>>n;
for(i=1;i<=n;i++) {
 cin>>s1;
}
cout<<-1<<endl;
return 0;
}