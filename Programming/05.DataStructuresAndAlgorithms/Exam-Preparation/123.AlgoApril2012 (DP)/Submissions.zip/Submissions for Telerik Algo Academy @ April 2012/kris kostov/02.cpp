#include<iostream>
using namespace std;
long long k,n,a[15][15],i1,i,j;
int main () {
cin>>k>>n;
for(i=1;i<=n;i++) {
 a[0][i]=i;
}
for(i1=1;i1<=k;i1++) {
 for(i=1;i<=n;i++) {
  for(j=1;j<=i;j++) {
  a[i1][i]=a[i1-1][j]+a[i1][i];
  }
 }
}
cout<<a[k][n]<<endl;
return 0;
}