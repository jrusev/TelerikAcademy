#include<iostream>
using namespace std;
long long k,n,a[15],br,br1,i,j,r;
string s,s1;
int main () {
cin>>k>>n;
cin>>s;
br=1;
for(i=1;i<=s.size()-1;i++) {
 br++;
 if(s[i]!=s[i-1]) {
  br1++;
  a[br1]=br;
  br=0;
}
}
br1++;
a[br1]=br;
br=0;
if(s[0]=='B') {
for(i=1;i<=br1;i++) {
 if(i%2==1) {
  br=br+a[i]%(n+1)+(a[i]/(n+1))*n;
 }
 if(i%2==0) {
  br=br+a[i]%(r+1)+(a[i]/(r+1))*r;
 }
}
}

if(s[0]=='G') {
for(i=1;i<=br1;i++) {
 if(i%2==0) {
  br=br+a[i]%(n+1)+(a[i]*n/(n+1));
 }
 if(i%2==1) {
  if(a[i]<k+1) {
   br=a[i];
} 
else {
  br=br+a[i]%(k+1)+(a[i]*k/(k+1));
}
 }
}
}
cout<<br<<endl;

return 0;
}