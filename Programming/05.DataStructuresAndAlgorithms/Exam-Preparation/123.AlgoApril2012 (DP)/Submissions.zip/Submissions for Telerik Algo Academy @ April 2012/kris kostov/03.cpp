#include<iostream>
using namespace std;
string s;
int main () {
cin>>s;

cout<<s.size()-20<<endl;
return 0;
}