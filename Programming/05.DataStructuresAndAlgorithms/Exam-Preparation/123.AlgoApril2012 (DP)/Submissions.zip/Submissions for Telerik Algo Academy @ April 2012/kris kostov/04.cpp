#include<iostream>
#include<queue>
using namespace std;
long long n,a[51],i,j,max1,b,m;
queue<long long> p[51];
int main () {
cin>>n;
for(i=1;i<=n;i++) {
 cin>>a[i];
}
cin>>b;
cin>>m;
p[0].push(b);
for(i=1;i<=n;i++) {
  while(!p[i-1].empty()) {
  if(p[i-1].front()+a[i]<=m) {
   p[i].push(p[i-1].front()+a[i]);
  }
  if(p[i-1].front()-a[i]>=0) {
   p[i].push(p[i-1].front()-a[i]);
  }
  p[i-1].pop();
 }
}
while(!p[n].empty()) {
 if(max1<p[n].front()) {
  max1=p[n].front();
}
p[n].pop();
}
if(max1!=0) 
cout<<max1<<endl;
else {
 cout<<-1<<endl;
}                  
 
return 0;
}
