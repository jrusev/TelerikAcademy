#include<iostream>
using namespace std;
long long t[21],n,i;
int main () {
cin>>t[1]>>t[2]>>t[3]>>n;
for(i=4;i<=n;i++) {
 t[i]=t[i-1]+t[i-2]+t[i-3];
}
cout<<t[n]<<endl;
return 0;
}