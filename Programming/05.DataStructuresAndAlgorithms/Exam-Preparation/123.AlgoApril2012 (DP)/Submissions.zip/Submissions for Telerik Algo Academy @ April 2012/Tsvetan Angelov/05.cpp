#include<iostream>
using namespace std;
int a[130][130],b[130][130];
int ans(int r,int c){
    int br=0;
    for(int i=0;i<r;i++)
    for(int j=0;j<c;j++)if(a[i][j])br++;
return br;
}
int count(int i,int j){
int br=0;

           if(a[i-1][j-1])br++;
           if(a[i-1][j])br++;
           if(a[i-1][j+1])br++;
           if(a[i][j-1])br++;
           if(a[i][j+1])br++;
           if(a[i+1][j-1])br++;
           if(a[i+1][j])br++;
           if(a[i+1][j+1])br++;
         
    return br;}
    
    
void gogo(int n,int r,int c){for(int i=0;i<r;i++)
    for(int j=0;j<c;j++)b[i][j]=a[i][j];
     bool f=true;int t=0;
     while(f && t<n){f=false;
     for(int i=0;i<r;i++)
    for(int j=0;j<c;j++){
            if(a[i][j])
if(count(i,j)<2 || count(i,j)>3){b[i][j]=0;f=true;}
if(a[i][j]==0 && count(i,j)==3){b[i][j]=1;f=true;}}for(int i=0;i<r;i++)
    for(int j=0;j<c;j++)a[i][j]=b[i][j];
      t++;/*for(int i=0;i<r;i++){
    for(int j=0;j<c;j++)cout<<a[i][j]<<" ";
    cout<<endl;}cout<<endl;*/}   
}
int main()
{
int n,r,c;
cin>>n>>r>>c;
//cout<<endl;
for(int i=0;i<130;i++)
for(int j=0;j<130;j++)a[i][j]==2;
for(int i=0;i<r;i++)
for(int j=0;j<c;j++){cin>>a[i][j];/*if(a[i][j]==0)a[i][j]=2;*/}//cout<<endl;
gogo(n,r,c);
cout<<ans(r,c)<<endl;


return 0;
}
