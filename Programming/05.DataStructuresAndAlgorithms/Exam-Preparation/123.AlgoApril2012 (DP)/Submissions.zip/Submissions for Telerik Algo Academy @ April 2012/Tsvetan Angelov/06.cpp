#include<iostream>
#include<cstring>
using namespace std;
int main(){
string a;char v[50][50];
cin>>a;
int n;
cin>>n;
for(int i=0;i<n;i++)cin>>v[i];
cout<<-1<<endl;
return 0;
}