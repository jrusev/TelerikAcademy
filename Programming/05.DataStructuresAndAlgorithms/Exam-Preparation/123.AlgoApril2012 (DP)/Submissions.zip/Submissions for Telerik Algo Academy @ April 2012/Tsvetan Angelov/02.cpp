#include<iostream>
using namespace std;
int supersum(int k,int n){
    if(k==0)return n;
int s=0;
for(int i=1;i<=n;i++)s+=supersum(k-1,i);
return s;
}

int main(){
 int k,n;
 cin>>k>>n;
 cout<<supersum(k,n)<<endl;

 return 0;
}   
