#include<iostream>
using namespace std;
int main()
{
long long a[20];
for(int i=0;i<3;i++)cin>>a[i];
long long n;
cin>>n;
for(int i=3;i<n;i++)a[i]=a[i-1]+a[i-2]+a[i-3];
cout<<a[n-1]<<endl;
return 0;
}
