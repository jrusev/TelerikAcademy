#include<iostream>
using namespace std;
int main()
{int t,a,b;
cin>>t;
cin>>a>>b;
char c[10][10];
for(int i=0;i<a;i++)cin>>c[i];
cout<<a<<endl;
return 0;
}
