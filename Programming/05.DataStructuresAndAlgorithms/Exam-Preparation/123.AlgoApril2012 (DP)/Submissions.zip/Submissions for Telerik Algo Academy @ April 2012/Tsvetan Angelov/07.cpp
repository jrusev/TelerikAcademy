#include<iostream>
using namespace std;
int abs(int a){
    if(a<0)a*=-1;
    return a;}
    
int main()
{int a[50];
int n;
cin>>n;
for(int i=0;i<n;i++)cin>>a[i];
int t;cin>>t;int fu;
for(int i=1;i<n;i++)if(abs(a[0]-a[i])>=t)fu=i;
fu/=2;
cout<<fu+1<<endl;



return 0;
}
