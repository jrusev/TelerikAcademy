#include<iostream>
#include<cstring>
using namespace std;
int main()
{
int r,w;
cin>>r>>w;
char a[2500];
cin>>a;
int rl=0,wl=0;
int gd=0;
if(a[0]=='G'){gd++;rl++;}
else {gd++;wl++;a[0]='G';}
for(int i=1;i<strlen(a);i++){
if(a[i]=='G'){if(rl<r){gd++;rl++;wl=0;}else {rl=0;wl++;a[i]='B';}}
else {if (wl<w){gd++;wl++;rl=0;a[i]='G';} else {wl=0;rl++;}}//cout<<rl<<" "<<wl<<endl;
}//cout<<a<<endl;
cout<<gd<<endl;

return 0;
}
