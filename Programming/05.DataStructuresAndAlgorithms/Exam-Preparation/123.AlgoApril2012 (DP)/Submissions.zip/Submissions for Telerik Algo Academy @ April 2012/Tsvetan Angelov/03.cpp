#include<iostream>
#include<cstring>  
using namespace std;  
int main()  
{  
char a[80]; 
cin>>a; 
cout<<strlen(a)/2<<endl;  
return 0;   
}