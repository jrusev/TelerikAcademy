#include<stdio.h>
#include<vector>
#include<algorithm>
using namespace std;
vector< vector<int> > an;
int a[50] ;vector<int> c;int ot;
void solve(int g,int b,int m){c.push_back(b);
an.push_back(c);
    for(int i=0;i<g;i++){c.clear();
    int n=an[i].size();
    for(int j=0;j<n;j++){if(an[i][j]+a[i]>=0 && an[i][j]+a[i]<=m)c.push_back(an[i][j]+a[i]);
    if(an[i][j]-a[i]>=0 && an[i][j]-a[i]<=m)c.push_back(an[i][j]-a[i]);}
            if(c.size()==0){ot=-1;return;}
            an.push_back(c);
            }
      int w=an.size();
    sort(an[w-1].begin(),an[w-1].end());
    int r=an[w-1].size();
    ot=an[w-1][r-1];        
    
}



int main()
{
int g;scanf("%d",&g);
//cin>>g;
for(int i=0;i<g;i++)/*cin>>a[i];*/scanf("%d",&a[i]);
int b;scanf("%d",&b);
//cin>>b;
int m;scanf("%d",&m);
//cin>>m;
solve(g,b,m);printf("%d\n",ot);
//cout<<ot<<endl;
//cin>>m;
return 0;
}
