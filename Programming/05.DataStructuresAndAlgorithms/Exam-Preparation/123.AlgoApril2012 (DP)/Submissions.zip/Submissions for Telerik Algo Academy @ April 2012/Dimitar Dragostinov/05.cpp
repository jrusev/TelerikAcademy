#include <cstdio>
#include "memory.h"
#define MAXN 130

bool A[MAXN][MAXN];
bool B[MAXN][MAXN];
int n, R, C;

int deltaR[] = { 0, 0, -1, -1, -1, 1, 1, 1 };
int deltaC[] = { 1, -1, -1, 0, 1, -1, 0, 1 };

int in(int r, int c) { return r >= 0 && r < R && c >= 0 && c < C; }

int main()
{
	scanf("%d", &n);
	scanf("%d%d", &R, &C);
	for(int r = 0; r < R; r++) 
	{
		for(int c = 0; c < C; c++) 
		{
			scanf("%d", &A[r][c]);
		}
	}

	int ln, dn, dr, dc;
	for(int i = 1; i <= n; i++) 
	{
		for(int r = 0; r < R; r++)
		{
			for(int c = 0; c < C; c++) 
			{
				ln = dn = 0;
				for(int k = 0; k < 8; k++) 
				{
					dr = r + deltaR[k];
					dc = c + deltaC[k];

					if(in(dr, dc))
					{
						if(A[dr][dc]) ln++;
						else dn++;
					}
				}
				if(!A[r][c] && ln == 3) B[r][c] = true;
				else if(!A[r][c] && ln != 3) B[r][c] = false;
				else if(A[r][c] && (ln == 3 || ln == 2)) B[r][c] = true;
				else if(A[r][c] && (ln < 2 || ln > 3)) B[r][c] = false;
			}
		}
		memcpy(A, B, sizeof(B));
		memset(B, 0, sizeof(B));
	}

	int l = 0;
	for(int r = 0; r < R; r++) 
	{
		for(int c = 0; c < C; c++) 
		{
			l+=A[r][c];
		}
	}	
	printf("%d\n", l);
	return 0;
}