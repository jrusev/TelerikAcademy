#include <iostream>
#define MAXC 55
#define MAXM 1010

using namespace std;


int main()
{
	int c, a[MAXC], b, m, res[MAXC][MAXM];
	cin >> c;
	for (int i = 0; i < c; i++)
	{
		cin >> a[i];
	}
	cin >> b >> m;
	res[0][b] = 1;
	int max = -1;
	for (int i = 1; i <= c; i++)
	{
		for (int j = 0; j <= m; j++)
		{
			if ( (j - a[i - 1] >= 0 && res[i-1][j - a[i - 1]] == 1) || (j + a[i - 1] <= m && res[i-1][j + a[i - 1]] == 1))
			{
				res[i][j] = 1;
				if (i == c && j > max)
				{
					max = j;
				}
			}
		}
	}
	cout << max << endl;
	return 0;
}
