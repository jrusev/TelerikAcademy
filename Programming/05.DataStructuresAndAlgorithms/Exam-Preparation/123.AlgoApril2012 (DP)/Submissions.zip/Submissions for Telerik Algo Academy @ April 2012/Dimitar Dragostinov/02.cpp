#include <iostream>
#include "memory.h"
using namespace std;
#define MAXK 20
#define MAXN 20

int dp[MAXK][MAXN];

int main()
{
	int k, n;
	memset(dp, 0, sizeof(dp));
	cin >> k >> n;
	for(int i = 0; i <= n; i++)
	{
		dp[0][i] = i;
	}

	
	for(int i = 1; i <= k; i++) 
	{
		for(int j = 0; j <= n; j++) 
		{
			for(int z = 0; z <= j; z++) 
			{
				dp[i][j] += dp[i - 1][z];
			}
		}
	}
	cout << dp[k][n] << endl;
	return 0;
}