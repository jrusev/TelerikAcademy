#include <iostream>
#include <algorithm>

#define MAXN 55
#define MAXM 1010
using namespace std;

int n, a[MAXN], p;

struct Str 
{
	Str() { min = 0; max = 0; zad = 0; }
	int zad, min, max;
};

Str calc(Str zad, int ind)
{
	Str res;
	int mi = min(zad.min, a[ind]);
	int mx = max(zad.max, a[ind]);
	res.min = mi;
	res.max = mx;
	res.zad = ind;
	return res;
}

int main()
{
	const int INF = 0x77777777;
	//freopen("f.in", "r", stdin);
	Str dp[MAXN][MAXM];
	cin >> n;
	int mxxx= 0, miiin=INF;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
		mxxx = max(mxxx, a[i]);
		miiin = min(miiin, a[i]);
	}
	cin >> p;
	if(mxxx-miiin < p) 
	{
		cout << n << endl;
		return 0;
	}
	dp[1][0].zad = 1;
	dp[1][0].min = a[1];
	dp[1][0].max = a[1];

	for (int i = 1; i < n; i++)
	{
		for (int j = 0; j < p; j++)
		{
			if (dp[i][j].zad != 0)
			{
				for(int k = 1; k <= 2; k++) 
				{
					int ind = dp[i][j].zad + k;
					Str res = calc(dp[i][j], ind);
					int diff = res.max - res.min;
					dp[i + 1][diff] = res;
					if (res.zad == n || diff >= p)
					{
						cout << i + 1 << endl;
						return 0;
					}
				}
			}
		}
	}
	cout << n << endl;
	return 0;
}