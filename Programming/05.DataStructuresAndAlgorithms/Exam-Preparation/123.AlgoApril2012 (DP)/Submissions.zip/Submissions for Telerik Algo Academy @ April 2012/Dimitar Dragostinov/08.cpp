#include <iostream>
#include <algorithm>
#include <string>
using namespace std;
#define MAXN 2505

int R, W;

struct state
{
	state() { good = 0; bad = 0; score = 0; }
	state(int g, int b, int s): good(g), bad(g), score(s) { }
	int good;
	int bad;
	int score;
};

state maxRight(const state& a, const state& b)
{
	if(a.score == b.score)
	{
		if(a.bad) return a;
		else return b;
	}
	else
	{
		if(a.score > b.score)
		{
			if(a.good + 1 <= R) return a;
			return b;
		}
		else 
		{
			if(b.good + 1 <= R) return b;
			return a;
		}
	}
}

state maxWrong(const state& a, const state& b)
{
	if(a.score == b.score)
	{
		if(a.good) return a;
		else return b;
	}
	else
	{
		if(a.score > b.score)
		{
			if(a.bad + 1 <= W) return a;
			return b;
		}
		else
		{
			if(b.bad + 1 <= W) return b;
			return a;
		}
	}
}

state dp[2][MAXN];

int main()
{
	string str;
	cin >> R >> W >> str;
	dp[0][0] = state(0, 1, str[0] == 'B');
	dp[1][0] = state(1, 0, str[0] == 'G');

	int val;
	for(int i = 1; i < str.size(); i++)
	{
		dp[1][i] = maxRight(dp[0][i - 1], dp[1][i - 1]);
		val = str[i] == 'G';
		dp[1][i].score += val;
		dp[1][i].good++;
		dp[1][i].bad = 0;

		dp[0][i] = maxWrong(dp[0][i - 1], dp[1][i - 1]);
		val = str[i] == 'B';
		dp[0][i].score += val;
		dp[0][i].good = 0;
		dp[0][i].bad++;

	}
	cout << max(dp[1][str.size() - 1].score, dp[0][str.size() - 1].score) << endl;
	return 0;
}