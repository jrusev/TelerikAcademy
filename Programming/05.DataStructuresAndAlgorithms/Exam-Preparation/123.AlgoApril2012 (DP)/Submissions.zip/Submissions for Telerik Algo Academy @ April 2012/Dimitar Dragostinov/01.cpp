#include <iostream>
using namespace std;

int main()
{
	long long a = 0,b = 0,c= 0, d= 0, n;
	cin >> a >> b >> c >> n;
	if(n > 3) 
	{
		for(int i = 3; i < n; i++) {
			d = a + b + c;
			a = b;
			b = c;
			c = d;
		}
	} else 
	{
		switch(n)
		{
			case 1 : d = a; break;
			case 2: d = b; break;
			case 3: d = c; break;
		}
	}
	cout << d << endl;
	return 0;
}