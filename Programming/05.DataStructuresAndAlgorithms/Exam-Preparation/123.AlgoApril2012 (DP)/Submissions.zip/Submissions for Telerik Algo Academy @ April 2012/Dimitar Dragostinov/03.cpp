#include <iostream>
#include <string>
#define MAXN 100

using namespace std;
long long F[MAXN][MAXN];

int main()
{
	string str;
	cin >> str;
	int N = str.size();	
	str = " " + str;
	int c, k;
	for(c = 0; c <= N + 1; c++) F[0][c] = 0;
	for(k = 0; k <= N; k++) F[k][N+1] = 0;

	F[0][0] = 1;

	for(k = 1; k <= N; k++) 
	{
		c = 0;
		if(str[k] == '(') F[k][c] = 0;
		else if(str[k] == ')') F[k][c] = F[k-1][c+1];
		else F[k][c] = F[k-1][c+1];

		for(c = 1; c <= N; c++) {
			if(str[k] == '(') F[k][c] = F[k-1][c-1];
			else if(str[k] == ')') F[k][c] = F[k-1][c+1];
			else F[k][c] = F[k-1][c-1] + F[k-1][c+1];
		}
	}
	cout << F[N][0] << endl;
	return 0;
}