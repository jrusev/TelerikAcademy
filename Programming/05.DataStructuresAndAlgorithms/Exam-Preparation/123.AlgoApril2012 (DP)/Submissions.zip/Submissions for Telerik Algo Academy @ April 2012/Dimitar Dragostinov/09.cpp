#include <iostream>
#include <algorithm>

#define MAXN 20

using namespace std;

struct Par
{
	Par() 
	{ 
		sides[0] = 0;
		sides[1] = 0;
		sides[2] = 0;
	}
	int sides[3];
};

bool canFit(Par left, int leftHight, Par right, int rightHight)
{
	int leftFloor[2];
	int rightFloor[2];
	int cnt = 0;
	for (int i = 0; i < 3; i++)
	{
		if (i == leftHight)
		{
			continue;
		}
		leftFloor[cnt++] = left.sides[i];
	}
	cnt = 0;
	for (int i = 0; i < 3; i++)
	{
		if (i == rightHight)
		{
			continue;
		}
		rightFloor[cnt++] = right.sides[i];
	}
	sort(leftFloor, leftFloor+2);
	sort(rightFloor, rightFloor+2);

	return leftFloor[0] >= rightFloor[0] && leftFloor[1] >= rightFloor[1];
}

int main()
{
	//freopen("f.in", "r", stdin);
	int n;
	Par a[MAXN];
	int res[MAXN][MAXN][3];
	bool used[MAXN][MAXN][3][MAXN] = {0 };
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		for (int k = 0; k < 3; k++)
		{
			cin >> a[i].sides[k];
		}
	}
	for (int j = 0; j < n; j++)
	{
		for (int k = 0; k < 3; k++)
		{
			res[1][j][k] = a[j].sides[k];
			used[1][j][k][j] = true;
		}
	}

	for (int i = 2; i <= n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			for (int k = 0; k < 3; k++)
			{
				res[i][j][k] = a[j].sides[k];
				used[i][j][k][j] = true;
				for (int ii = 1; ii < i; ii++)
				{
					for (int jj = 0; jj < n; jj++)
					{
						for (int kk = 0; kk < 3; kk++)
						{
							if (!used[ii][jj][kk][j] && canFit(a[jj], kk, a[j], k) && res[i][j][k] <= res[ii][jj][kk] + a[j].sides[k])
							{
								res[i][j][k] = res[ii][jj][kk] + a[j].sides[k];
								for (int t = 0; t < n; t++)
								{
									used[i][j][k][t] = used[ii][jj][kk][t];
								}
								used[i][j][k][j] = true;
							}
						}
					}
				}

			}
		}
	}
	int max = 0;
	for (int j = 0; j < n; j++)
	{
		for (int k = 0; k < 3; k++)
		{
			if (max < res[n][j][k])
			{
				max = res[n][j][k];
			}
		}
	}
	cout << max << endl;
	return 0;
}