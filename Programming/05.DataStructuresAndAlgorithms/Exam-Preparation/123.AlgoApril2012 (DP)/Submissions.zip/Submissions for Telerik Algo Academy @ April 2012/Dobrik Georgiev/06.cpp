#include<iostream>
#include<map>
#include<string>
#include<cstring>
#include<queue>
using namespace std;
string message;
int n;
string a[52],s;
int bfs(string x,string y)
{
    map<string,int> used;
    used[x]=1;
    int m=x.size();
    string sn,current;
    queue<string> q;
    q.push(x);
    while(!q.empty())
    {
        current=q.front();
        q.pop();
        if(used[y]!=0)break;
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<m;j++)
            {
                if(i!=j)
                {
                    sn=current;
                    swap(sn[i],sn[j]);
                    //cout<<"u="<<used[sn]<<endl;
                    if(used[sn]==0)
                    {
                        used[sn]=used[current]+1;
                        q.push(sn);
                    }
                }
            }
        }
    }
    return used[y];
}
int main()
{
    int f,ans=0;
    //ios::sync_with_stdio(false);
    cin>>message;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
        s=message.substr(0,a[i].size());
        message.erase(0,a[i].size());
        f=bfs(a[i],s);
        if(f==0){cout<<-1<<endl;return 0;}
        ans+=f;
        if(message.size()==0)break;
        if(i==n)i=1;
        
    }
    cout<<ans<<endl;
    return 0;
}
/*
neotowheret
4
one two three three

sepawaterords
3
this is meaningful
*/