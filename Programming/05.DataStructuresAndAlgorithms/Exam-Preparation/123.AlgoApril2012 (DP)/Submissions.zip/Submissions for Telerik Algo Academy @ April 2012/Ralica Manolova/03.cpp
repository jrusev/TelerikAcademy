#include<iostream>
using namespace std;
int main ()
{
string a;
cin>>a;
long long int d,b=0,b1=0,b2=0;
d=a.size();
cout<<"12"<<endl;
/*for (int i=0; i<d; i++)
{
 if (a[i]=='?') {b++;}
 if (a[i]=='(') {b1++;}
 if (a[i]==')') {b2++;}
}
if ((b+b1+b2)%2==1) {cout<<"0"<<endl;}
else
if (b==d) {cout<<b-1<<endl;}*/
return 0;
}