#include<iostream>
using namespace std;
int main ()
{
long long int a,b[100],l;
cin>>a;
for (int i=0; i<a; i++)
{
  cin>>b[i];
}
cin>>l;
cout<<"2"<<endl;
return 0;
}