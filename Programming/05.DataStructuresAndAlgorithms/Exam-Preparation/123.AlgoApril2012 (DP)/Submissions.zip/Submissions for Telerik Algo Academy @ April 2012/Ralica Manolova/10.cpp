#include<iostream>
using namespace std;
int main ()
{
char q;
int a,b,g,br=0,p=0;
cin>>g;
cin>>a>>b;
for (int i=0; i<a; i++)
{
  for (int j=0; j<b; j++)
  {
    cin>>q;
    if (q=='.') {br++;}
    else {if (br!=0) {p++;} br=0;}
  }
  if (br!=0) {p++;}
  br=0;
}
cout<<p<<endl;
return 0;
}