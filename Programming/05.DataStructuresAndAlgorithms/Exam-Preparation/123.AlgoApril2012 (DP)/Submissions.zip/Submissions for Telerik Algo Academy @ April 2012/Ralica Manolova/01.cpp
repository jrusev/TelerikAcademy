#include<iostream>
using namespace std;
long long int a,b,c,n,s;
int main ()
{
cin>>a>>b>>c>>n;
if (n==1) {cout<<a<<endl;}
else
if (n==2) {cout<<b<<endl;}
else
if (n==3) {cout<<c<<endl;}
else
{
for (int i=1; i<=n-3; i++)
{
  s=a+b+c;
  a=b;
  b=c;
  c=s;
}
cout<<c<<endl;
}
return 0;
}