#include<iostream>
#include<cstring>
using namespace std;
int main ()
{
int n,k,s;
cin>>n>>k;
string a;
cin>>a;
s=a.size();
if (n==s) {cout<<n<<endl;}
else {cout<<s-1<<endl;}
return 0;
}