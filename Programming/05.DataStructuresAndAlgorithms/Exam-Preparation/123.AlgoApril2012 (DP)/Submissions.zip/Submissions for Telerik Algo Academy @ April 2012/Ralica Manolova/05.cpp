#include<iostream>
using namespace std;
int a[200][200],c[200][200];
int main ()
{
long long int n,q,w,br=0,b=0;
cin>>n>>q>>w;
for (int i=0; i<q; i++)
{
  for (int j=0; j<w; j++)
  {
    cin>>a[i][j];
  }
}
for (int h=1; h<=n; h++)
{
for (int i=0; i<q; i++)
{
  for (int j=0; j<w; j++)
  {
    if (i-1>=0 && j-1>=0 && a[i-1][j-1]==1) {b++;}
    if (i-1>=0  && a[i-1][j]==1) {b++;}
    if (j-1>=0 && a[i][j-1]==1) {b++;}
    if (i-1>=0 && j+1<=w-1 && a[i-1][j+1]==1) {b++;}
    if (j+1<=w-1 && a[i][j+1]==1) {b++;}
    if (i+1<=q-1 && j-1>=0 && a[i+1][j-1]==1) {b++;}
    if (i+1<=q-1 && a[i+1][j]==1) {b++;}
    if (i+1<=q-1 && j+1<=w-1 && a[i+1][j+1]==1) {b++;}

    if (a[i][j]==0 && b==3) {c[i][j]=1;}
    if (a[i][j]==0 && b!=3) {c[i][j]=0;}
    if (a[i][j]==1 && (b==3 || b==2)) {c[i][j]=1;}
    if (a[i][j]==1 && b<2) {c[i][j]=0;}
    if (a[i][j]==1 && b>3) {c[i][j]=0;}
    //cout<<b<<endl;
    b=0;
  }
}
for (int i=0; i<q; i++)
{
  for (int j=0; j<w; j++)
  {
    a[i][j]=c[i][j];
  }
}
}
for (int i=0; i<q; i++)
{
  for (int j=0; j<w; j++)
  {
    if (a[i][j]==1) {br++;}
    //cout<<a[i][j]<<" ";
  }
  //cout<<endl;
}
cout<<br<<endl;
return 0;
}