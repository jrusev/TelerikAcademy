#include<iostream>
using namespace std;
int main ()
{
string a,b[100];
int n;
cin>>a;
cin>>n;
for (int i=0; i<n; i++)
{
   cin>>b[i];
}
cout<<"-1"<<endl;
return 0;
}