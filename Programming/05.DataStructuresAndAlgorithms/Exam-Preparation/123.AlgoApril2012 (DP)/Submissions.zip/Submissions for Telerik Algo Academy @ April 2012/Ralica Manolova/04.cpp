#include<iostream>
using namespace std;
int main ()
{
long long int n,a[100],l=0;
cin>>n;
for (int i=0; i<n; i++)
{
  cin>>a[i];
}
long long int b,m,s;
cin>>b>>m;
s=b;
for (int i=0; i<n; i++)
{
  if (s+a[i]<=m) {s=s+a[i];}
  else
  if (s-a[i]>=0) {s=s-a[i];}
  else {cout<<"-1"<<endl; l++; break;}
}
if (l==0) {cout<<s<<endl;}
/*
14
74
39
127
95
63
140
99
96
154
18
137
162
14
88
40
243
*/
return 0;
}