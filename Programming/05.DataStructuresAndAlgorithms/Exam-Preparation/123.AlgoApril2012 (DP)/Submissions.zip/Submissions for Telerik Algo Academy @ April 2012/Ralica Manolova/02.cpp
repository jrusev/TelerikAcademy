#include<iostream>
using namespace std;
long long int fif (long long b)
{
  long long h=0;
   for (int  j=1; j<=b; j++) {h=h+j;}
   return h;
}
int main ()
{
long long int n,k,sb=0,l=1,q;
cin>>k>>n;
q=k-2;
if (k==0) {cout<<n<<endl;}
else
if (k==1) {sb=fif(n); cout<<sb<<endl;}
else
{
  for (int i=n; i>=1; i--)
  {
     sb=sb+fif(i)*l;
     l=l+q;
  }
  cout<<sb<<endl;
}
return 0;
}