#include<iostream>
#include<cstring>
using namespace std;
int main ()
{
long long int a[100][4],n,s=0,mn=100000;
cin>>n;
for (int i=0; i<n; i++)
{
  for (int j=0; j<3; j++)
  {
    cin>>a[i][j];
  }
}
for (int i=0; i<3; i++)
{
  for (int j=0; j<n; j++)
  {
    s=s+a[j][i];
  }
  if (mn>s) {mn=s;}
  s=0;
}
cout<<mn<<endl;
return 0;
}