#include<iostream>
#include <string>
using namespace std;

string a;

int main(){
	cin >> a;
	cin>> a;
	cout<< -1 << endl;


	return 0;
}
