#include <cstdio>
#include <algorithm>
#define maxn 60
#define maxm 1010
using namespace std;

int c, m, b, v[maxn];

int num[maxm];

int main(){


	scanf("%d", &c);

	for(int i = 1; i<=c; ++i){
		scanf("%d", v+i);
	}

	scanf(" %d %d", &b, &m);

	num[b] = 1;

	for(int i = 1; i<=c; ++i){
		for(int j = 0; j <= m; ++j){
			if(num[j] == i){
				if(j + v[i] <= m){
					num[j + v[i]] = i+1;// printf("%d\n", j + v[i]);
				}
				if(j - v[i] >= 0){
					num[j - v[i]] = i+1;// printf("%d\n", j - v[i]);
				}
			}
		}


	}

	for(int i = m; i>=0; --i){
		if(num[i] == c+1){
			printf("%d\n", i);
			return 0;
		}
	}
	printf("-1\n");

	return 0;
}


