#include<cstdio>
#include <cmath>
#define maxn 60
using namespace std;

int price(int begin, int end){
	int tek = end - begin;
	return tek/2 + tek%2;
}


int n, pri[maxn], raz;

int main(){

	scanf("%d", &n);
	for(int i = 0; i<n; ++i){
		scanf("%d", pri+i);
	}
	scanf("%d", &raz);

	int best = 99999;

	int tek;

	for(int i = 1; i<n; ++i){
		for(int j = 0; j<i; ++j){
			if(abs((float)(pri[j] - pri[i])) >= raz){
				tek = price(0, j) + price(j, i);
				if(tek < best)
					best = tek;
			}
		}
	}
	printf("%d\n", best+1);


	return 0;
}
