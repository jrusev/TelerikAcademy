#include <iostream>
using namespace std;


int main(){
	int a;
	cin>> a >> a;
	++a;
	string s;
	cin >> s;
	int size = s.size();

	cout<< size/a + size%a << endl;

	return 0;
}

