#include <iostream>
#include <cstdio>
#include <string>
#include <algorithm>
#define maxn 90
using namespace std;

string s;

int num[2][maxn];
int t, t1 = 1;

void clear(int cer, int size){
	for(int i = 0; i<size; ++i){
		num[cer][i] = 0;
	}
}

int price(char q){
	if( q == '(') return 1;
	else return -1;
}

int main(){



	cin>>s;
	int size = s.size();

	num[t][1] = 1;


	int maxj = 0;
	for(int i = 1; i<size; ++i){
		maxj = i+3;
		if(s[i] == '?'){
			if(maxj > size - i + 3) maxj = size - i + 3;
			for(int j = 0; j < maxj; ++j){
				if(num[t][j] != 0){
					if(j != 0) num[t1][j-1] += num[t][j];
					num[t1][j+1] += num[t][j];
				}
			}
		}else{
			for(int j = 0; j < maxj; ++j){
				if(!(j == 0 && price(s[i]) == -1)){
					num[t1][j+price(s[i])] = num[t][j];
				}
			}
		}
		swap(t1, t);
		clear(t1, maxj);
		//for(int i = 0; i<maxj; ++i){ printf("%d ", num[t][i]); } printf("\n");
	}

	//for(int i = 0; i<maxj; ++i){ printf("%d ", num[t][i]); }

	printf("%d\n", num[t][0]);




	return 0;
}
