#include<cstdio>
#include <algorithm>
#define maxs 200
using namespace std;

int a[2][maxs][maxs];
int n, mr, mk;
int t, t1 = 1;


int con(int cer,int r,int k){
	int l = 0, d = 0;
	for(int i = -1; i<= 1; ++i){
		for(int j = -1; j<=1; ++j){
			if(r >= 0 && r < mr && k >= 0 && k < mk && !(i == 0 && j == 0) ){
				if(a[cer][r+i][k+j] == 1) l++;
				else d++;
			}
		}
	}
	if(a[cer][r][k] == 0){
		if (l == 3){
			return 1;
		}else return 0;
	}else{
		if(l == 2 || l == 3){
			return 1;
		}
		if(l < 2) return 0;
		if(l > 3) return 0;
	}
}




int main(){

	scanf("%d", &n);
	scanf("%d %d", &mk, &mr);

	for(int k = 0; k<mk; ++k){
		for(int r = 0; r<mr; ++r){
			scanf("%d", &a[t][r][k]);
		}
	}


	for(int i = 0; i<n; ++i){
		for(int k = 0; k<mk; ++k){
			for(int r = 0; r<mr; ++r){
				a[t1][r][k] = con(t, r, k);
			}
		}
		swap(t, t1);
	}

	int br = 0;

	for(int k = 0; k<mk; ++k){
		for(int r = 0; r<mr; ++r){
			if( a[t][r][k] == 1) ++br;
		}
	}
	printf("%d\n", br);

	return 0;
}
