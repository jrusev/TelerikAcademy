#include<iostream>
using namespace std;

long long t1, t2, t3, n, tnew;


int main(){

    cin >> t1 >> t2 >> t3 >> n;


    for(int i = 3; i<n; ++i){
        tnew = t1 + t2 + t3;

        t1 = t2;
        t2 = t3;
        t3 = tnew;
    }

    cout << t3 << endl;



return 0;
}
