#include<iostream>
#define maxn 20
using namespace std;

int mem[maxn][maxn];

int supersum(int k, int n){
    long long res = 0;
    if( k == 0 ) return n;

    if( mem[k][n] != 0 ) return mem[k][n];

    for(int i = 1; i<=n; ++i){
        res += supersum(k-1, i);
    }

    mem[k][n] = res;
    return res;
}

int k, n;

int main(){
    cin >> k >> n;

    cout<<supersum(k, n)<< endl;


    return 0;
}
