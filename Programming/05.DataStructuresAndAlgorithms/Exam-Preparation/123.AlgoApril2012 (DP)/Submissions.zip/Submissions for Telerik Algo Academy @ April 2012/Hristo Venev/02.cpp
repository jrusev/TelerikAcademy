#include <stdio.h>
#include <stddef.h>
#include <stdint.h>
uint64_t Sum[16], c;
size_t i, j, K, N;
int main(){
    for(i=0;i<16;i++) Sum[i]=i;
    scanf("%lu %lu", &K, &N);
    for(i=1;i<=K;i++){
        c=0;
        for(j=0;j<=N;j++){
            c+=Sum[j];
            Sum[j]=c;
        }
    }
    printf("%llu\n", Sum[N]);
    return 0;
}
