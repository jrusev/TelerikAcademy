#include <cstdio>
#include <cstddef>
#include <algorithm>
bool Possible[2][1024], *From=Possible[0], *To=Possible[1];
size_t Diff[1024];
size_t i, j, N, M, B;
int main(){
    scanf("%lu", &N);
    for(i=0;i<N;i++){
        scanf("%lu", Diff+i);
    }
    scanf("%lu %lu", &B, &M);
    M++;
    From[B]=1;
    for(i=0;i<N;i++){
        std::fill(To, To+M, 0);
        for(j=0;j<M-Diff[i];j++) if(From[j+Diff[i]]) To[j]=1;
        for(j=Diff[i];j<M;j++) if(From[j-Diff[i]]) To[j]=1;
        std::swap(From, To);
    }
    j=M;
    while(j--){
        if(From[j]){
            printf("%lu\n", j);
            return 0;
        }
    }
    puts("-1");
    return 0;
}