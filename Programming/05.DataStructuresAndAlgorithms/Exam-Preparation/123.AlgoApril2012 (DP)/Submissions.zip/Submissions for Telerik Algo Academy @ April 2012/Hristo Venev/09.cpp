#include <stdio.h>
static const size_t Perm[3][3]={
    {0,1,2},
    {0,2,1},
    {1,2,0},
};
size_t Sizes[15][3];
size_t MaxH[15][3][32768]; //[Block][Permutation][Mask]
size_t N;
size_t Get(size_t B, size_t P, size_t M){
    if(MaxH[B][P][M]!=0) return MaxH[B][P][M];
    size_t T;
    size_t X=Sizes[B][Perm[P][0]], Y=Sizes[B][Perm[P][1]], Z=Sizes[B][Perm[P][2]], Mask=M|(1<<B), NextX, NextY, i, j;
    for(i=0;i<N;i++){
        if(Mask&(1<<i)) continue;
        for(j=0;j<3;j++){
            NextX=Sizes[i][Perm[j][0]];
            NextY=Sizes[i][Perm[j][1]];
            if(NextX>X||NextY>Y) continue;
            T=Get(i, j, Mask);
            if(T>MaxH[B][P][M]) MaxH[B][P][M]=T;
        }
    }
    MaxH[B][P][M]+=Z;
    return MaxH[B][P][M];
}
int main(){
    size_t i, j, Max=0;
    scanf("%lu", &N);
    for(i=0;i<N;i++){
        scanf("%lu %lu %lu", Sizes[i]+0, Sizes[i]+1, Sizes[i]+2);
        if(Sizes[i][0]>Sizes[i][1]) Sizes[i][0]^=Sizes[i][1]^=Sizes[i][0]^=Sizes[i][1];
        if(Sizes[i][0]>Sizes[i][2]) Sizes[i][0]^=Sizes[i][2]^=Sizes[i][0]^=Sizes[i][2];
        if(Sizes[i][1]>Sizes[i][2]) Sizes[i][1]^=Sizes[i][2]^=Sizes[i][1]^=Sizes[i][2];
    }
    for(i=0;i<N;i++){
        for(j=0;j<3;j++){
            if(Get(i, j, 0)>Max) Max=Get(i, j, 0);
        }
    }
    printf("%lu\n", Max);
    return 0;
}