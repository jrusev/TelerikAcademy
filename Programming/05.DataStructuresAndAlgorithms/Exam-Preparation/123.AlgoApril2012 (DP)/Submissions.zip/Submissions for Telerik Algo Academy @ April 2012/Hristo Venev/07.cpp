#include <stdio.h>
#include <stddef.h>
#define min(a,b) (((a)<(b))?(a):(b))
#define max(a,b) (((a)<(b))?(b):(a))
size_t Tasks[64];
size_t MaxMax[64][64][1024]; //[Task][Solved][Min]
size_t N, M, i, j, k, Offset, Min, Max, Answer=1000;
static const size_t Invalid=-1;
int main(){
    scanf("%lu", &N);
    for(i=0;i<N;i++) scanf("%lu", Tasks+i);
    scanf("%lu", &M);
    for(i=0;i<N;i++) for(j=0;j<N;j++) for(k=0;k<1024;k++) MaxMax[i][j][k]=Invalid;
    MaxMax[0][1][Tasks[0]]=Tasks[0];
    for(i=0;i<N;i++){
        for(Offset=1;Offset<=2;Offset++){
            if(i+Offset>=N) break;
            for(j=0;j<N;j++){
                for(k=0;k<1024;k++){
                    if(MaxMax[i][j][k]==Invalid) continue;
                    Min=min(k, Tasks[i+Offset]);
                    Max=max(MaxMax[i][j][k], Tasks[i+Offset]);
                    if(MaxMax[i+Offset][j+1][Min]==Invalid||Max>MaxMax[i+Offset][j+1][Min]) MaxMax[i+Offset][j+1][Min]=Max;
                }
            }
        }
    }
    for(i=0;i<N;i++){
        for(j=1;j<N;j++){
            for(k=0;k<1024;k++){
                if(MaxMax[i][j][k]!=Invalid&&MaxMax[i][j][k]-k>=M){
                    printf("%lu\n", j);
                    return 0;
                }
            }
        }
    }
    printf("%lu\n", N);
    return 0;
}