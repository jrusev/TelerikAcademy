#include <stdio.h>
#include <stddef.h>
#include <stdbool.h>
static const size_t Invalid=-1;
size_t Min[10][1024]; //[last line][mask '1=can continue down']
size_t PrevMask[10][1024];
unsigned char Filling[10][1024][10];
bool Floor[10][10]; //1 means free
size_t FloorMasks[10];
size_t N, M;
inline size_t Count(size_t i, size_t Mask, size_t Prev){
    size_t k, Res=0;
    bool OnHorizontal=0;
    for(k=0;k<M;k++){
        if(!OnHorizontal&&Floor[i][k]&&!(Mask&(1<<k))){
            OnHorizontal=1;
            Res++;
        }else if(OnHorizontal&&(!Floor[i][k]||(Mask&(1<<k)))){
            OnHorizontal=0;
        }
        if((Mask&(1<<k))&&!(Prev&(1<<k))){
            Res++;
        }
    }
    return Res;
}
inline void DoFill(size_t i, size_t Mask, size_t Prev){
    size_t k;
    bool OnHorizontal=0;
    char Fill=0;
    for(k=0;k<M;k++){
        if(!OnHorizontal&&Floor[i][k]&&!(Mask&(1<<k))){
            OnHorizontal=1;
            Fill=10*i+k+1;
        }else if(OnHorizontal&&(!Floor[i][k]||(Mask&(1<<k)))){
            Fill=0;
            OnHorizontal=0;
        }
        Filling[i][Mask][k]=Fill;
        if(Mask&(1<<k)){
            if(Prev&(1<<k)) Filling[i][Mask][k]=Filling[i-1][Prev][k];
            else Filling[i][Mask][k]=10*i+k+1;
        }
    }
    return;
}
size_t i, Prev, Mask, j, T, Curr, BestMask;
char Ch, Line[11], Assigned[100], NextCh='A';
size_t MaskList[10];
unsigned char Filled;
int main(){
    scanf("%lu %lu %lu", &T, &N, &M);
    for(i=0;i<N;i++){
        for(j=0;j<M;j++){
            Ch=10;
            while(Ch==10) scanf("%c", &Ch);
            Floor[i][j]=Ch=='.';
            if(Floor[i][j]) FloorMasks[i]|=1<<j;
        }
    }
    for(i=0;i<N;i++){
        for(j=0;j<1<<M;j++){
            Min[i][j]=Invalid;
        }
    }
    for(Mask=0;Mask<1<<M;Mask++){
        if((Mask&FloorMasks[0])!=Mask) continue;
        Min[0][Mask]=Count(0, Mask, 0);
    }
    for(i=1;i<N;i++){
        for(Mask=0;Mask<1<<M;Mask++){
            for(Prev=0;Prev<1<<M;Prev++){
                if(Min[i-1][Prev]==Invalid) continue;
                if((Mask&FloorMasks[i])!=Mask) continue;
                Curr=Min[i-1][Prev]+Count(i, Mask, Prev);
                if(Curr<Min[i][Mask]){
                    Min[i][Mask]=Curr;
                    PrevMask[i][Mask]=Prev;
                }
            }
        }
    }
    for(Mask=1;Mask<1<<M;Mask++){
        if(Min[N-1][Mask]<Min[N-1][BestMask]) BestMask=Mask;
    }
    if(T==1){
        printf("%lu\n", Min[N-1][BestMask]);
    }else{
        i=N;
        Mask=BestMask;
        while(i--){
            MaskList[i]=Mask;
            Mask=PrevMask[i][Mask];
        }
        Ch='A';
        for(i=0;i<N;i++){
            Mask=MaskList[i];
            DoFill(i, Mask, PrevMask[i][Mask]);
            for(j=0;j<M;j++){
                Filled=Filling[i][Mask][j];
                if(Filled==0) Line[j]='#';
                else{
                    if(Assigned[Filled]==0) Assigned[Filled]=NextCh++;
                    Line[j]=Assigned[Filled];
                }
            }
            Line[M]=0;
            puts(Line);
        }
    }
    return 0;
}
