#include <stdio.h>
#include <stddef.h>
#include <string.h>
static const size_t Invalid=-1;
char Str[256];
char Dict[256][256];
size_t DictSize;
size_t W[256], i, j, k, m, M;
int Count[256];
int main(){
    for(i=1;i<256;i++) W[i]=Invalid;
    scanf("%s", Str);
    scanf("%lu", &DictSize);
    for(i=0;i<DictSize;i++) scanf("%s", Dict[i]);
    for(i=0;Str[i];i++){
        if(W[i]==Invalid) continue;
        for(j=0;j<DictSize;j++){
            for(m=0;m<256;m++) Count[m]=0;
            M=0;
            for(k=0;Dict[j][k]!=0;k++){
                Count[Str[i+k]]++;
                Count[Dict[j][k]]--;
                if(Str[i+k]!=Dict[j][k]) M++;
            }
            for(m=0;m<256;m++) if(Count[m]!=0) M=Invalid;
            if(M==Invalid) continue;
            if(W[i]+M<W[i+k]) W[i+k]=W[i]+M;
        }
    }
    if(W[i]==Invalid) puts("-1");
    else printf("%lu\n", W[i]);
    return 0;
}
