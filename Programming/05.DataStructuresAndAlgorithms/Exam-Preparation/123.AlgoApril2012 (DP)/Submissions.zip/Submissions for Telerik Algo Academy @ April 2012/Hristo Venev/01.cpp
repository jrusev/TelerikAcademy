#include <stdio.h>
long long a, b, c, d, N;
int main(){
    scanf("%lld %lld %lld %lld", &a, &b, &c, &N);
    while(N>1){
        d=a+b+c;
        a=b;
        b=c;
        c=d;
        N--;
    }
    printf("%lld\n", a);
    return 0;
}
