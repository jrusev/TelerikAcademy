#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
uint64_t Pos[128][128]; //[Pos][Open]
char Input[128];
size_t i, j;
int main(){
    fgets(Input, 127, stdin);
    Pos[0][0]=1;
    for(i=0;Input[i];i++){
        if(Input[i]=='('||Input[i]=='?'){
            for(j=1;j<128;j++){
                Pos[i+1][j]+=Pos[i][j-1];
            }
        }
        if(Input[i]==')'||Input[i]=='?'){
            for(j=0;j<127;j++){
                Pos[i+1][j]+=Pos[i][j+1];
            }
        }
    }
    printf("%llu\n", Pos[i-1][0]);
    return 0;
}