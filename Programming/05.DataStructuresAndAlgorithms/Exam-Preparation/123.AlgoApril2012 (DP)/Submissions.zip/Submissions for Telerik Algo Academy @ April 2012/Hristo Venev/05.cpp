/// CONWAY'S GAME OF LIFE
#include <cstdio>
#include <algorithm>
bool Game[256][256], Next[256][256];
size_t R, C;
inline size_t LiveNeighbCount(size_t i, size_t j){
    size_t Res=0;
    if(i>0){
        if(j>0) Res+=Game[i-1][j-1];
        Res+=Game[i-1][j];
        if(j+1<C) Res+=Game[i-1][j+1];
    }
    if(j>0) Res+=Game[i][j-1];
    if(j+1<C) Res+=Game[i][j+1];
    if(i+1<R){
        if(j>0) Res+=Game[i+1][j-1];
        Res+=Game[i+1][j];
        if(j+1<C) Res+=Game[i+1][j+1];
    }
    return Res;
}
int main(){
    size_t Gen, i, j, k, Res=0;
    int a;
    scanf("%lu %lu %lu", &Gen, &R, &C);
    for(i=0;i<R;i++){
        for(j=0;j<C;j++){
            scanf("%d", &a);
            Game[i][j]=a;
        }
    }
    for(k=0;k<Gen;k++){
        for(i=0;i<R;i++){
            for(j=0;j<C;j++){
                size_t Neighb=LiveNeighbCount(i, j);
                Next[i][j]=(Neighb==2&&Game[i][j])||Neighb==3;
            }
        }
        for(i=0;i<R;i++){
            std::copy(Next[i], Next[i]+C, Game[i]);
        }
    }
    for(i=0;i<R;i++){
        for(j=0;j<C;j++){
            Res+=Game[i][j];
        }
    }
    printf("%lu\n", Res);
    return 0;
}
