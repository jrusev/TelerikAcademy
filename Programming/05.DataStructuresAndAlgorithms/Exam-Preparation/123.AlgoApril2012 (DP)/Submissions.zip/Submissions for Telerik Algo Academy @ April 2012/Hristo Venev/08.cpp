#include <stdio.h>
#include <stddef.h>
size_t MaxGood[2501][2][2501]; // [days][seq_type][seq_len]
                                 // 0=good=right 1=bad=wrong so I can XOR them
size_t Prophecy[2500];
size_t N, MaxR, MaxW, i, j, k, Type, Best, Old, New;
char Ch;

int main(){
    scanf("%lu %lu", &MaxR, &MaxW);
    MaxR++;
    MaxW++;
    getchar();
    for(N=0;1;N++){
        Ch=getchar();
        if(Ch==10) break;
        Prophecy[N]=Ch=='B';
    }
    for(i=0;i<N;i++){
        for(j=0;j<MaxR;j++){
            Old=MaxGood[i][0][j];
            
            New=Old+!Prophecy[i];
            if(j+1<MaxR&&MaxGood[i+1][0][j+1]<New) MaxGood[i+1][0][j+1]=New;
            
            New=Old+Prophecy[i];
            if(MaxGood[i+1][1][1]<New) MaxGood[i+1][1][1]=New;
        }
        for(j=0;j<MaxW;j++){
            Old=MaxGood[i][1][j];

            New=Old+Prophecy[i];
            if(j+1<MaxW&&MaxGood[i+1][1][j+1]<New) MaxGood[i+1][1][j+1]=New;
            
            New=Old+!Prophecy[i];
            if(MaxGood[i+1][0][1]<New) MaxGood[i+1][0][1]=New;
        }
    }
    for(j=0;j<MaxR;j++){
        if(MaxGood[N][0][j]>Best) Best=MaxGood[N][0][j];
    }
    for(j=0;j<MaxW;j++){
        if(MaxGood[N][1][j]>Best) Best=MaxGood[N][1][j];
    }
    printf("%lu\n", Best);
    return 0;
}
