#include <iostream>

using namespace std;

int Ar[100000];
// t1-1 t2-1 t3-1 t4-3 t1-5 t2-9 t3-17
void solve(int T1 , int T2, int T3, int Num)
{
     int T4;
     Ar[0]=T1;
     Ar[1]=T2;
     Ar[2]=T3;
     for (int i=3;i<Num;i++) Ar[i]=Ar[i-1]+Ar[i-2]+Ar[i-3];
     cout << Ar[Num-1] << endl;
}

int main (void)
{  
    int n,T1,T2,T3;
    cin >> T1 >> T2 >> T3 >> n;
    solve(T1,T2,T3,n);
    return 0;   
}
