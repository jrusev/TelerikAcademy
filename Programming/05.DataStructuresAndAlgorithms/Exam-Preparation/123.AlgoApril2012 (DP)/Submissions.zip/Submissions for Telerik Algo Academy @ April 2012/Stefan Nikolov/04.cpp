#include <iostream>
using namespace std; 
int main (void)
{
    int c,b,m,Ar[50];
    cin >> c;
    bool flag=false;
    for (int i=0;i<c;i++) cin >> Ar[i];
    cin >> b >> m;
    for (int i=0;i<c;i++) if (b+Ar[i]>m&&b-Ar[i]<0) flag=true;
    if (flag) cout << "-1" << endl;
    else cout << m << endl;
    return 0;
}
