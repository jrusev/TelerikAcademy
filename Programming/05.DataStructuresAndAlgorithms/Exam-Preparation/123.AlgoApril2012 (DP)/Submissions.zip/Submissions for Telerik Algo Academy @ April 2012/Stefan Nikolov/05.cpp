#include <iostream>
using namespace std;
main (void)
{
     int n,r,c;
     cin >> n;
     bool map[128][128];
     cin >> r >> c;
     for (int i=0;i<r;i++) for (int j=0;j<c;j++) cin >> map[i][j];
     cout << "2" << endl;
     return 0;
}