#include <iostream>
#include <string>
using namespace std;
int main (void)
{
    int Right,Wrong;
    cin >> Right >> Wrong;
    string predict;
    cin >> predict;
    cout << predict.size() << endl;
    return 0;
}
