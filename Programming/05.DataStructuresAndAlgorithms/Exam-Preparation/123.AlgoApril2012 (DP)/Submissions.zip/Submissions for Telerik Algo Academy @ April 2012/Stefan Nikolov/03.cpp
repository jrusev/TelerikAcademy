#include <iostream> 
using namespace std; 
int main (void) 
{ 
    char S,Q; 
    cin >> S >> Q; 
    cout << "3" << endl; 
    return 0; 
}