#include <iostream>
using namespace std;
int main (void)
{
    int n,Ar[15][3],Sum=0;
    cin >> n;
    for (int i=0;i<n;i++) for (int j=0;j<3;j++) {
                                                cin >> Ar[i][j]; 
                                                if (j==2) Sum+=Ar[i][j];
                                                }
    cout << Sum << endl;
    return 0;
}
