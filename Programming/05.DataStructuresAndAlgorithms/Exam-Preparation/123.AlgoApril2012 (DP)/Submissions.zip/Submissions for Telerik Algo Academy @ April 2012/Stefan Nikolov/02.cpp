#include <iostream>

using namespace std;
int Ar[15][15];
void SuperSum (int prime, int second)
{
     int Sum=0;
     for (int i=0;i<=prime;i++) for (int j=0;j<=second;j++) 
                                                            {
                                                            if (i==0) Ar[0][j]=j;
                                                            else if (j==1) Ar[i][1]=1;
                                                            else if (j==0) Ar[i][j]=0;
                                                            else Ar[i][j]=Ar[i-1][j]+Ar[i][j-1];
                                                            }
}
 
int main (void)
{
    int k,n;
    cin >> k >> n;
    SuperSum(k,n);
    cout << Ar[k][n] << endl;
    return 0;
}