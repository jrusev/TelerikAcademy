#include <iostream>
using namespace std;
int main (void)
{
    int t,n,m;
    cin >> t >> n >> m;
    char Ar[n][m];
    for (int i=0;i<n;i++) for (int j=0;j<m;j++) cin >> Ar[i][j];
    cout << "1" << endl;
    return 0;
}
