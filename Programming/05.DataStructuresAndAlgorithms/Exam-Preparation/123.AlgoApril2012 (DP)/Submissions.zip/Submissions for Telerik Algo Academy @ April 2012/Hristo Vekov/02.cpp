#include<iostream>
using namespace std;

int n;
int buhta1(int kmin,int qmin)

{   int ssum=0;
        if(kmin>qmin) {return 0;}
        if(kmin==qmin) {return 1;}

        for(int i=kmin;i<=qmin;i++)
{ssum=ssum+i;}

return ssum;
}

int sum=0;
int buhta(int kmin,int qmax)
{int qmin=0;
while(qmax!=qmin){qmin++;sum=sum+buhta1(kmin,qmin) ;}

}




int main (){
        int k;

cin>>k>>n;
//k-1=p, q=n;
buhta(k-1,n);
cout<<sum<<endl;
return 0;
}
