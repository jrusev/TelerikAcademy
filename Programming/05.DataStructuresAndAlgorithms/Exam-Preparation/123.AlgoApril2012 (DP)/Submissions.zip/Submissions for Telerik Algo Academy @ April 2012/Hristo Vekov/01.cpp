#include<iostream>
#include<cstdlib>
using namespace std;
int main (){
long long a,b,c,d;
long long n,i;
cin>>a>>b>>c>>n;
for(i=0;i<n-3;i++)
{d=a+b+c;
a=b;
b=c;
c=d;
}
cout<<d<<endl;
return 0;
}