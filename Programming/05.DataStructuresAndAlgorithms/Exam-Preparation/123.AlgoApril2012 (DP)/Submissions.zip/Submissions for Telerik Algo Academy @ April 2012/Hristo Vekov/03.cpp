#include<iostream>
#include <cstring>
using namespace std;

long long fac (int k)
{int sum=1;
int i;
for(i=1;i<=k;i++) sum=sum*i;
return sum;
}

int main (){
    int k;
    long long p;
char a[10000];
cin>>a;
k=strlen(a);
p=fac(k);
cout<<p<<endl;
return 0;
}
