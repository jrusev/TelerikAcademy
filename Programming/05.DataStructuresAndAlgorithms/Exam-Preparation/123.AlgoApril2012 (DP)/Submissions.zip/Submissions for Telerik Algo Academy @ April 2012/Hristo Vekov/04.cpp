#include<cstdio>
#include <iostream>
using namespace std;
int a[2000];
int n,i,sum,c,b,m;
int main (){
scanf("%d",&c);
for(i=0;i<c;i++)
{scanf("%d",&a[i]);


}
scanf("%d",&b);
scanf("%d",&m);
sum=b;
for(i=0;i<c;i++)
{if(sum+a[i]<=m) sum+=a[i];
else sum=sum-a[i-1];
 
}
cout<<sum<<endl;
return 0;
}
