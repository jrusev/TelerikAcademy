#include<cstdio>
using namespace std;
int main (){
printf("-1\n");

return 0;
}
