#include<iostream>

using namespace std;

int SuperSuma(int k, int n){
	int result = 0;
	if(k!=1){
		for(int i=1;i<=n;i++){
			result += SuperSuma(k-1, i);
		}
	} else {
		for(int i=1;i<=n;i++){
			result += i;
		}
	}
	
	return result;
}

int main(){
	int k, n;
	cin>>k>>n;
	cout<<SuperSuma(k, n);
	return 0;
}
