#include<iostream>

using namespace std;

int main(){
	long long fs, sc, th, cr, i;
	short n;
	cin>>fs>>sc>>th>>n;
	if(n<4){
		if(n==3)cout<<th;
		if(n==2)cout<<sc;
		if(n==1)cout<<fs;
		return 0;
	}
	for(i=0;i<n-3;++i){
		// The new one
		cr = fs + sc + th;
		// The next
		fs = sc;
		sc = th;
		th = cr;
	}
	cout<<cr;
}
