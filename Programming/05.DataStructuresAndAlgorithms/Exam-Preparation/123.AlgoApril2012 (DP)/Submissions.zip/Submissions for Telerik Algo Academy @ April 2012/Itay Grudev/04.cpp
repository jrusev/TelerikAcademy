#include<iostream>
#include<cmath>
  
using namespace std;
  
int main(){
      
    int c, b, m, i, prev = 1, prevn = 0, w;
    cin>>c;
      
    int s[c];
    for(i=0;i<c;++i){
        cin>>s[i];
    }
    cin>>b>>m;
      
    int row[(int)pow(2, c)];
    int newrow[(int)pow(2, c)];
    row[0] = b;
      
    for(i=0;i<c;++i){
        int c = -1;
        for(int j=0;j<prev;j+=2){
            ++c;
            // Collection
            w = row[c] + s[i];
            if(w >= 0 && w <= m){
                newrow[prevn] = w;
                prevn++;
            }
            // Subtraction
            w = row[c] - s[i];
            if(w >= 0 && w <= m){
                newrow[prevn] = w;
                prevn++;
            }
        }
        // ROW = NEWROW
        for(int m=0;m<prevn;++m){
            row[m] = newrow[m];
        }
        prev = prevn;
        if(prevn == 0)break;
        prevn = 0;
    }
      
    // Nprev used like MAX
    prevn = -1;
    for(i=0;i<prev;++i){
        if(row[i]>prevn)prevn = row[i];
    }
      
    cout<<prevn;
      
    return 0;
}