#include<iostream>
#include<cstring>

using namespace std;

int main(){
	string in;
	cin>>in;
	
	int lf = 0, rh = 0, qm = 0, var = 0, varc=0;
	
	for(int i=0;i<in.size();++i){
		if(in[i] == '(')++lf;
		if(in[i] == ')')++rh;
		if(in[i] == '?'){
			++qm;
			if(lf-rh == 0){
				if(var == 0){
					var ++;
				} else {
					var --;
					varc ++;
				}
			}
		}
	}
	
	cout<<varc;
}
