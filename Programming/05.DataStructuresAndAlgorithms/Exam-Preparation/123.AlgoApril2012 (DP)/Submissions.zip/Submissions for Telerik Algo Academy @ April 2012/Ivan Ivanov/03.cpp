#include<iostream>
#include<cstring>
using namespace std;
long long nam(long long  a)
{
    long long f1,f2,next,i;
    f1=1;
    f2=2;
    for(i=6;i<=a;i=i+2)
    {
        next=f1+f2;
        f1=f2;
        f2=next;
    }
    return f2;
}
int main(){
int i,p=0;
char skobi[80];
cin>>skobi;
skobi[0]='(';
skobi[strlen(skobi)-1]=')';
for(i=0;i<strlen(skobi);i++)
{
    if(skobi[i]=='?')
    {
        p=1;
        cout<<nam(strlen(skobi));
        i=strlen(skobi);
    }
}
if(p==0)
{
    cout<<"1"<<endl;
}
return 0;
}
