#include<iostream>
using namespace std;
long long nam(long long f1,long long f2,long long f3,long long n)
{
    long long tek,i;
    for(i=4;i<=n;i++)
    {
        tek=f1+f2+f3;
        f1=f2;
        f2=f3;
        f3=tek;
    }
    return f3;
}
int main(){
long long m,n,p,o;
cin>>m>>n>>p>>o;
cout<<nam(m,n,p,o)<<endl;
return 0;
}
