#include<iostream>
using namespace std;
int main(){
char a[50];
int b,i;
cin>>a>>b;
for(i=0;i<b;i++)
{
    cin>>a;
}
cout<<"-1\n";
return 0;
}
