#include<iostream>
using namespace std;
long long mem[14][14];
long long rab(long long n,long long k)
{
    long long i;
    if(mem[k][n]!=0) return mem[k][n];
    if(k==0)
    {
        return n;
    }
    for(i=1;i<=n;i++)
    {
       mem[k][n]+=rab(i,k-1);
    }
    return mem[k][n];
}
int main(){
long long n,k,i,j;
cin>>k>>n;
for(i=0;i<k;i++)
{
    for(j=0;j<n;j++)
    {
       mem[i][j]=0;
    }
}
cout<<rab(n,k)<<endl;
return 0;
}
