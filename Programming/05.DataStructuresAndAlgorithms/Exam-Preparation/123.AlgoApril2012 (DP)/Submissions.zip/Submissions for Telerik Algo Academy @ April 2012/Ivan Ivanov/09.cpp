#include<iostream>
#include<algorithm>
using namespace std;
int main(){
long long brblock,razm[3],s[15],maxstr[15],i,sbor=0;
cin>>brblock;
for(i=0;i<brblock;i++)
{
    cin>>razm[0]>>razm[1]>>razm[2];
    sort(razm,razm+3);
    maxstr[i]=razm[1];
    s[i]=razm[0]*razm[1];
    sbor=sbor+razm[2];
}
cout<<sbor<<endl;
return 0;
}
