#include<iostream>
#include<cstring>
using namespace std;
int main(){
int kv,kg,i,hd=0,pom,br;
cin>>kv>>kg;
char prog[2500];
cin>>prog;
i=0;
while(i<strlen(prog))
{
    br=0;
    while(prog[i]=='G'&&i<strlen(prog))
    {
       br++;
       i++;
    }
    if(br>kv&&br!=0)
    {
        hd+=br/(kv+1)*kv+br%(kv+1);
    }
    if(br<=kv&&br!=0)
    {
        hd+=br;
    }
    if(br==0)
    {
        while(prog[i]=='B'&&i<strlen(prog))
        {
            br++;
            i++;
        }
        if(br>kg&&br!=0)
        {
            hd+=br/(kg+1)*kg+br%(kg+1);
        }
        if(br<=kg&&br!=0)
        {
            hd+=br;
        }
    }
}
cout<<hd<<endl;
return 0;
}
