#include<iostream>
using namespace std;
bool possible[100000],newpossible[100000];
long long m,sbor=0;
long long sl(long long p)
{
   while(!possible[p]&&p<sbor)
   {
       p++;
   }
   return p;
}
int main(){
long long ch[50],n,i,j,b;
cin>>n;
for(i=0;i<n;i++)
{
    cin>>ch[i];
}
for(i=0;i<n;i++)
{
    sbor+=ch[i];
}
for(i=0;i<sbor;i++)
{
    possible[i]=false;
    newpossible[i]=false;
}
cin>>b>>m;
possible[ch[0]]=true;
for(i=0;i<n-1;i++)
{
    for(j=0;j<sbor;j++)
    {
        if(possible[j])
        {
            newpossible[j+ch[i+1]]=true;
        }
    }
    for(j=0;j<sbor;j++)
    {
        if(newpossible[j])
        {
            possible[j]=true;
        }
    }
    possible[ch[i+1]]=true;
}
i=0;
while(sl(i)<sbor)
{
    j=sl(i);
    if(possible[sbor-2*j])
    {
        if(sbor-2*j+b<=m)
        {
          if(b-ch[0]<0&&b+ch[0]>m)
          {
              cout<<"-1"<<endl;
              i=sbor+5;
          }
          else
          {
            cout<<sbor-2*j+b<<endl;
            i=sbor+5;
          }
        }
        else
        {
           i=j;
           i++;
        }
    }
    else
    {
        i=j;
        i++;
    }
}
if(sl(i)>=sbor&&i!=sbor+5)
{
    cout<<"-1"<<endl;
}
return 0;
}
