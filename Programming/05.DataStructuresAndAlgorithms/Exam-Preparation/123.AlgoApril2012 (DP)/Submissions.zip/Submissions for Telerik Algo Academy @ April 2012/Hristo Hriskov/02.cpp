#include<iostream>
using namespace std;
int main()
{
    unsigned long long k,n,i,j,s=0,s2=0,a,s1=0;
    cin>>k>>n;
    if(k==1)
    {
        for(i=1;i<=n;i++)
        s=s+i;
        cout<<s<<endl;
        return 0;
    }
    for(i=1;i<k;i++)
    {
        for(j=i;j<=n;j++)
        {
            for(a=1;a<=j;a++)
            s=s+a;
        }
    }
    cout<<s<<endl;
    return 0;
}
