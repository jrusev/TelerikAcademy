#include<iostream>
using namespace std;
int main()
{
    cout<<15<<endl;
    return 0;
}
