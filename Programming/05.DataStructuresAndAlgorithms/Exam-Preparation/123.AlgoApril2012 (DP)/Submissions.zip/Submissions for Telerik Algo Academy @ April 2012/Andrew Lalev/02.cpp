#include <stdio.h>

#define MAXK 14
#define MAXN 14

int K,N;
long long map[MAXK+1][MAXN];

void init() {
	scanf("%d%d", &K, &N);
	for(int i=0;i<=K;i++)
		for(int j=0;j<N;j++)
			map[i][j] = 0;
}

void create_cell(int k, int n) {
	for(int j=0;j<=n;j++)
		map[k][n] += map[k-1][j];
}

void construct() {
	for(int j=0;j<N;j++)
		map[0][j] = j+1;
	for(int i=1;i<=K;i++)
		for(int j=0;j<N;j++)
			create_cell(i,j);
}

int main() {
	init();
	construct();
	printf("%d\n", map[K][N-1]);

	return 0;
}
