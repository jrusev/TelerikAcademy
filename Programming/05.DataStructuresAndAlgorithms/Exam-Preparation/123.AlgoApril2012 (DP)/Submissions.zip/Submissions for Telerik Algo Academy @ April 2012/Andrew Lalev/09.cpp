#include <stdio.h>


int main() {
	int N,x[15],y[15],z[15];
	scanf("%d", &N);
	for(int i=0;i<N;i++)
		scanf("%d%d%d", &x[i], &y[i], &z[i]);
	int sum=0;
	for(int i=0;i<N;i++)
		sum += x[i];
	printf("%d\n", sum);
	return 0;
}