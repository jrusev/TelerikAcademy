#include <stdio.h>
#include <string.h>

#define MAXLEN 2500
// MAXRW: 2500

int R,W,N,index=0,res=0; //right; wrong
char s[MAXLEN];

int next(char target) {
	int i=index;
	while(i<N && (s[i]!=target)) i++;
	return i;
}

void good() {
	int limit=next('B');
	//printf("%d %d %d\n", index, limit, limit-index);
	if(limit-index >= R+1) {
		res += ((limit-index)/(R+1))*R;
		index += ((limit-index)/(R+1))*(R+1);
	}
	res += limit-index;
	index = limit;

	//printf("%d\n", index);
}

void bad() {
	int limit=next('W');
	//printf("%d %d %d\n", index, limit, limit-index);
	if(limit-index >= R+1) {
		res += ((limit-index)/(W+1))*W;
		index += ((limit-index)/(W+1))*(W+1);
	}
	res += limit-index;
	index = limit;
	//printf("%d\n", index);
}

void solve() {
	while(index<N) {
		if(s[index]=='G') good();
		else bad();
		break;
	}
}

void init() {
	scanf("%d%d", &R, &W);
	scanf("%s", &s);
	N = strlen(s);
}

int main() {
	init();

	solve();
	printf("%d\n", res);

	return 0;
}


/*
2 2
GGGGGGBG

----
2 2
GGGG

3
----
4 1
GGGG


----
7 1
GGGGGGGGGGGGGGGG


*/
