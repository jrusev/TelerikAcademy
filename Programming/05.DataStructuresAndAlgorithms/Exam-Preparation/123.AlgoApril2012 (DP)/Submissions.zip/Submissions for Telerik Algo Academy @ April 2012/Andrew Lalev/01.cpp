#include <stdio.h>

using namespace std;

int N;
long long t1=1,t2=1,t=1,ind=3,temp;

void solve() {
	while(ind<N) {
		temp = t1+t2+t;
		t1 = t2;
		t2 = t;
		t = temp;
		ind++;
	}
}

void init() {
	scanf("%d%d%d%d", &t1, &t2, &t, &N);
}

int main() {
	init();
	solve();
	printf("%d\n", t);

	return 0;
}