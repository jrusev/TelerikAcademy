#include <stdio.h>
#include <string.h>

#define MAXN 80

int N,sum=0;
char arr[MAXN+1],brr[MAXN+1];
long long res=0;

void solve_roughly(int ind) {
	while(ind<N && (arr[ind]!='?')) {
		if(arr[ind]=='(') sum++;
		if(arr[ind]==')') sum--;
		ind++;
	}
	if(ind<N) {
		sum++;
		brr[ind]='(';
		solve_roughly(ind+1);
		sum -= 2;
		brr[ind]=')';
		solve_roughly(ind+1);
	} else res+=(sum==0);
}

void init() {
	scanf("%s", &arr);
	N = strlen(arr);
}

int main() {
	init();
	solve_roughly();

	printf("%d\n", res);

	return 0;
}
