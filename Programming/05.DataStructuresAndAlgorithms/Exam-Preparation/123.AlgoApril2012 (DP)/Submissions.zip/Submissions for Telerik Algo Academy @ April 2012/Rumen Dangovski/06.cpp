#include <iostream>
#include <string>

using namespace std;

string s;
string dict[500];
int size[500];
int n, dp[500];
int used[500];
int used2[500][500];
char k;

int main () {
    cin >> s;
    cin >> n;
    int m = s.size ();
    for (int i = 1; i <= n; ++ i) {
        cin >> dict[i];
        size[i] = dict[i].size ();
        for (int j = 0; j < size[i]; ++ j)
            ++ used2[i][dict[i][j]];
    }

    for (int i = 1; i <= m; ++ i)
        dp[i] = 2000000000;

    dp[0] = 0;

    /*for (int i = 1; i <= n; ++ i)
        cout << size[i] << endl;

    for (int i = 96; i <= 123; ++ i)
        cout << used2[1][i] << endl;*/

    bool ok;
    int cnt;

    for (int i = 0; i < m; ++ i) {
        for (int j = 1; j <= n; ++ j) {
            if (i - size[j]  + 1 >= 0) {
                for (int t = 96; t <= 123; ++ t)
                    used[t] = 0;
                for (int t = i; t >= i - size[j] + 1; -- t)
                    ++ used[s[t]];
                ok = 0;
                for (int t = 96; t <= 123; ++ t)
                    if (used[t] != used2[j][t]) {
                        ok = 1;
                        break;
                    }
                if (ok == 0) {
                    cnt = 0;
                    for (int t = 0; t < size[j]; ++ t)
                        if (dict[j][t] != s[i - size[j] + 1 + t]) ++ cnt;
                    if (i - size[j] == -1 ) dp[i] = min (dp[i], cnt);
                    else dp[i] = min (dp[i], dp[i - size[j]] + cnt);
                }
            }
        }
    }
    if (dp[m-1] == 2000000000) dp[m-1] = -1;
    cout << dp[m-1] << endl;

    return 0;
}

/*
neotowheret
4
one
two
three
there
*/
