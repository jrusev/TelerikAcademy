#include <iostream>
using namespace std;

int R, C, n;

bool a[1024][1024], b[1024][1024];
char k ;

int main () {
    cin >> n >> R >> C;
    for (int i = 1; i <= R; ++ i)
        for (int j = 1; j <= C; ++ j)
            cin >> a[i][j];

    int cnt1, cnt2 ;

    for (int t = 1; t <= n; ++ t) {
        for (int i = 1; i <= R; ++ i)
            for (int j = 1; j <= C; ++ j) {
                cnt1 = 0;
                cnt2 = 0;
                if (i - 1 >= 1 && j - 1 >= 1) {
                    if (a[i-1][j-1] == 0) ++ cnt1;
                    if (a[i-1][j-1] == 1) ++ cnt2;
                }
                if (i - 1 >= 1) {
                    if (a[i-1][j] == 0) ++ cnt1;
                    if (a[i-1][j] == 1) ++ cnt2;
                }
                if (i - 1 >= 1 && j + 1 <= C) {
                    if (a[i-1][j+1] == 0) ++ cnt1;
                    if (a[i-1][j+1] == 1) ++ cnt2;
                }
                if (j + 1 <= C) {
                    if (a[i][j+1] == 0) ++ cnt1;
                    if (a[i][j+1] == 1) ++ cnt2;
                }
                if (j - 1 >= 1) {
                    if (a[i][j-1] == 0) ++ cnt1;
                    if (a[i][j-1] == 1) ++ cnt2;
                }
                if (i + 1 <= R && j - 1 >= 1) {
                    if (a[i+1][j-1] == 0) ++ cnt1;
                    if (a[i+1][j-1] == 1) ++ cnt2;
                }
                if (i + 1 <= R) {
                    if (a[i+1][j] == 0) ++ cnt1;
                    if (a[i+1][j] == 1) ++ cnt2;
                }
                if (i + 1 <= R && j + 1 <= C) {
                    if (a[i+1][j+1] == 0) ++ cnt1;
                    if (a[i+1][j+1] == 1) ++ cnt2;
                }
                if (a[i][j] == 0) {
                    if (cnt2 == 3) b[i][j] = 1;
                    else b[i][j] = 0;
                }
                if (a[i][j] == 1) {
                    if (cnt2 == 2 || cnt2 == 3) b[i][j] = 1;
                    else b[i][j] = 0;
                }
            }
            for (int i = 1; i <= R; ++ i)
                for (int j = 1; j <= C; ++ j)
                    a[i][j] = b[i][j];
    }

    int cnt = 0;
    for (int i = 1; i <= R; ++ i)
        for (int j = 1; j <= C; ++ j)
            if (a[i][j] == 1) ++ cnt;
    cout << cnt << endl;
    return 0;
}
