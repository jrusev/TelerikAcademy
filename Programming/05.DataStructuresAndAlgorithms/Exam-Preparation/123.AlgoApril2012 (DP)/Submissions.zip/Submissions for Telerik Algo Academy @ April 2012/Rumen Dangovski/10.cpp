#include <iostream>
using namespace std;

int t, n, m, ans = 2000000000;
int a[11][11];
char k;

void rec (int b[][11], int v) {
    /*for (int i = 1; i <= n; ++ i) {
        for (int j = 1; j <= m; ++ j)
            cout << a[i][j] << " " ;
        cout << endl;
    }
    cin >> k ;*/
    bool ok2 = 0;
    for (int i = 1; i <= n; ++ i)
        for (int j = 1; j <= m; ++ j)
            if (b[i][j] == 0) {
                ok2 = 1;
                bool ok;
                int ii;
                int jj;

                //TOVA E ZA NADOLU!!!!
                ok = 0;
                ii = i;
                while (ii <= n && b[ii][j] == 0) {
                    b[ii][j] = v;
                    ++ ii;
                    ok = 1;
                }
                if (ok == 1) rec (b, v + 1);
                -- ii;
                while (ii >= i) {
                    b[ii][j] = 0;
                    -- ii;
                }

                //NAGORE
                ok = 0;
                ii = i;
                while (ii >= 1 && b[ii][j] == 0) {
                    b[ii][j] = v;
                    -- ii;
                    ok = 1;
                }
                if (ok == 1) rec (b, v + 1);
                ++ ii;
                while (ii <= i) {
                    b[ii][j] = 0;
                    ++ ii;
                }

                //NALYAVO
                ok = 0;
                jj = j;
                while (jj >= 1 && b[jj][i] == 0) {
                    b[jj][i] = v;
                    -- jj;
                    ok = 1;
                }
                if (ok == 1) rec (b, v + 1);
                ++ jj;
                while (jj <= j) {
                    b[jj][i] = 0;
                    ++ jj;
                }

                //NADYASNO
                ok = 0;
                jj = j;
                while (jj <= m && b[jj][i] == 0) {
                    b[jj][i] = v;
                    ++ jj;
                    ok = 1;
                }
                if (ok == 1) rec (b, v + 1);
                -- jj;
                while (jj >= j) {
                    b[jj][i] = 0;
                    -- jj;
                }
            }
            if (ok2 == 0) {
                ans = min (ans , v);
                return;
            }
}

int main () {
    cin >> t >> n >> m;

    for (int i = 1; i <= n; ++ i)
        for (int j = 1; j <= m; ++ j)
            cin >> a[i][j];

    cout << n << endl;
    return 0;
}
