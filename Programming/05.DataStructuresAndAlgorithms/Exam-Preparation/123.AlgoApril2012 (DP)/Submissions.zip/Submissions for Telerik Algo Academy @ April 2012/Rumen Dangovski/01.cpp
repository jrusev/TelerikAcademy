#include <iostream>

using namespace std;

int N;
long long dp[21];

int main () {
    cin >> dp[1] >> dp[2] >> dp[3] >> N;
    for (int i = 4 ; i <= N; ++ i)
        dp[i] = dp[i-1] + dp[i-2] + dp[i-3];
    cout << dp[N] << endl;

    return 0;
}
