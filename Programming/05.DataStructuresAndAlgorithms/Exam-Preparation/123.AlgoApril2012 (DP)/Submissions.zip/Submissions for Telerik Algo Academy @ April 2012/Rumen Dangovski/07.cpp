#include <iostream>
using namespace std;

int n;
int a[51];
int diff;
int dp[51];
int sm[51];
int hg[51];
int BIGans = 2000000000;

int mini (int a, int b) {
    if (a < b) return a;
    return b;
}

void rec (int i, int max, int min, int ans) {
    if (i == n) {
        BIGans = mini (BIGans, ans);
        return ;
    }
    if (a[i] - min >= diff) {
        BIGans = mini (BIGans, ans);
        return ;
    }

    if (i + 1 <= n) {
        if (a[i + 1] >= max) rec (i + 1, a[i+1], min, ans + 1);
        if (a[i + 1] <= min) rec (i + 1, max, a[i+1], ans + 1);
    }

    if (i + 2 <= n) {
        if (a[i + 2] >= max) rec (i + 2, a[i+2], min, ans + 1);
        if (a[i + 2] <= min) rec (i + 2, max, a[i+2], ans + 1);
    }
}

int main () {
    cin >> n;
    for (int i = 1; i <= n; ++ i)
        cin >> a[i];
    cin >> diff;

    rec (1, a[1], a[1], 1);

    cout << BIGans << endl;

    return 0;
}
