#include <iostream>
#include <string>
using namespace std;

string s;
bool a[2502];
int n;
int dp[2502];
int r[2502];
int w[2502];
int R, W;
int cnt;

int main () {
    cin >> R >> W;
    cin >> s;

    n = s.size ();
    for (int i = 0; i < n; ++ i)
        if (s[i] == 'G') a[i + 1] = 1;

    dp[0] = 0;
    for (int i = 1; i <= n; ++ i) {
        cnt = 0;
        for (int j = 1; j <= R; ++ j) {
            if (a[i - j + 1] == 1) ++ cnt;
            if (i - j >= 0) dp[i] = max (dp[i], dp[i-j] + cnt);
        }
        cnt = 0;
        for (int j = 1; j <= W; ++ j) {
            if (a[i - j + 1] == 0) ++ cnt;
            if (i - j >= 0) dp[i] = max (dp[i], dp[i-j] + cnt);
        }
    }
    cout << dp[n] << endl;

    return 0;
}
