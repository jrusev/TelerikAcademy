#include <iostream>
#include <cstdio>

using namespace std;

#define LIM -2000000000

int a[81];
int dp[81][2];
int c, b, m;
char k;
int ans = -2000000000;

void scan () {
    scanf ("%d", &c);
    for (int i = 1; i <= c; ++ i)
        scanf ("%d", &a[i]);
    scanf ("%d %d", &b, &m);
}

void rec (int val, int n) {
    if (n == c + 1) {
        ans = max (ans, val);
        return ;
    }
    if (val - a[n] >= 0)
        rec (val - a[n], n + 1);
    if (val + a[n] <= m)
        rec (val + a[n], n + 1);
}

void solve () {
    //1 za +
    //2 za -

    /*dp[0][1] = b;
    dp[0][2] = b;
    //cout << m << endl;
    for (int i = 1; i <= c; ++ i) {
        dp[i][1] = LIM;
        dp[i][2] = LIM;
        if (dp[i-1][1] == LIM && dp[i-1][2] == LIM) continue;

        if (dp[i-1][1] != LIM) {
            if (dp[i-1][1] + a[i] >= 0 && dp[i-1][1] + a[i] <= m) dp[i][1] = max (dp[i][1], dp[i-1][1] + a[i]);
            if (dp[i-1][1] - a[i] >= 0 && dp[i-1][1] - a[i] <= m) dp[i][2] = max (dp[i][2], dp[i-1][1] - a[i]);
        }

        if (dp[i-1][2] != LIM) {
            if (dp[i-1][2] + a[i] >= 0 && dp[i-1][2] + a[i] <= m) dp[i][1] = max (dp[i][1], dp[i-1][2] + a[i]);
            if (dp[i-1][2] - a[i] >= 0 && dp[i-1][2] - a[i] <= m) dp[i][2] = max (dp[i][2], dp[i-1][2] - a[i]);
        }
        //cout << dp[i][1] << " " << dp[i][2] << endl;
        //cout << "-----" << endl;
    }*/
    /*int ans = -1;
    if (dp[c][1] >= 0 && dp[c][1] <= m) ans = max (ans, dp[c][1]);
    if (dp[c][2] >= 0 && dp[c][2] <= m) ans = max (ans, dp[c][2]);*/
    rec (b, 1);
    cout << ans << endl;
}

int main ()  {
    scan ();
    solve ();

    return 0;
}

/*
14
74 39 127 95 63 140 99 96 154 18 137 162 14 88
40 243
*/
