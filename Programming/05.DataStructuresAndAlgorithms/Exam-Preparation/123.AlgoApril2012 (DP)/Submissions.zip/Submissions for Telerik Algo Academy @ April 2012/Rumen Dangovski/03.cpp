#include <iostream>
#include <string>

using namespace std;

unsigned long long Cat[85];
string a;

int main () {
    cin >> a;
    int n = a.size ();
    //cout << n << endl;
    if (n % 2 == 1) {
        cout << 0 << endl;
        return 0;
    }

    Cat[0] = 1;
    for (int i = 1; i <= n; ++ i)
        for (int j = 0; j <= i - 1; ++ j)
            Cat[i] += Cat[j] * Cat[i - 1 - j];

    cout << Cat[(n/2)] << endl;

    return 0;
}
