#include <iostream>
using namespace std;

int f(int k, int n) {
    if (k == 0) return n;
    int ans = 0;
    for (int i = 1; i <= n; ++ i)
        ans += f(k-1, i);
    return ans;
}

int main () {
    int n, k;
    cin >> k >> n;
    cout << f (k, n) << endl;

    return 0;
}