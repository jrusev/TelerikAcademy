/*
PROB: academy
LANG: C++
KEYW: 
COMMENT: Very dulll!!! :@
*/
/// Thanks to Him I can know and learn! Love Christ!
/// "Without Me you can do nothing" ( John 15:5 )
#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <cstring>
#include <queue>
#include <ctime>
#include <cstdio>
#include <cassert>
#include <cmath>
#include <numeric>
#include <algorithm>
#define foreach(_var,_container) for( typeof( (_container).begin() ) _var = (_container).begin() ; _var != (_container).end() ; ++_var )
#define now() double( double( clock() ) / double( CLOCKS_PER_SEC ) )
#if 0
#define eprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )
#else
#define eprintf(msg, ... ) 0
#endif
#define pprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )

typedef long long ll;

using namespace std;

const int MAXN = 1 << 6;
const int INF = 1 << 30;
const int MAXV = 1 << 10;

int N, M;
int a[MAXN];
int dp[3][MAXV][MAXV];

void remin( int &self , int x ){
    if( self > x )
        self = x;
}

void calc(){
    for( int min = 0 ; min < MAXV ; min++ )
        for( int max = 0 ; max < MAXV ; max++ )
            if( max - min >= M )
                dp[N % 3][min][max] = 0;
            else
                dp[N % 3][min][max] = INF;
    
    for( int at = N - 1 ; at >= 0 ; at-- ){
        int p = at % 3;
        
        for( int min = 0 ; min < MAXV ; min++ ){
            int newmin = ( a[at] < min ? a[at] : min );
            
            for( int max = min ; max < MAXV ; max++ ){
                int newmax = ( a[at] > max ? a[at] : max );
                
                dp[p][min][max] = INF;
                
                if( max - min >= M ){
                    dp[p][min][max] = 0; /// solving this isn't really needed
                }else{
                    /// it's needed
                    int q = ( p + 1 ) % 3;
                    
                    remin( dp[p][min][max] , 1 + dp[q][newmin][newmax] );
                    
                    q = ( p + 2 ) % 3;
                    
                    if( at + 2 <= N )
                        remin( dp[p][min][max] , 1 + dp[q][newmin][newmax] );
                }
            }
        }
    }
}

void read(){
    scanf("%d", &N);
    
    for( int i = 0 ; i < N ; i++ ){
        scanf("%d", &a[i]);
    }
    
    scanf("%d", &M);
}

void solve(){
    if( *max_element( a , a + N ) - *min_element( a , a + N ) < M )
        printf("%d\n", N);
    else{
        calc();
        
        eprintf("first = %d", dp[1][ a[0] ][ a[0] ]);
        
        int answer = dp[1][ a[0] ][ a[0] ]; /// if jumped straight to second
        
        /// or third?
        
        if( N > 2 )
            remin( answer , dp[2][ a[0] ][ a[0] ] );
        
        ++answer;
        
        printf("%d\n", answer);
    }
}

int main(){
    //freopen( "7.in" , "r" , stdin );
    //freopen( "7.out" , "w" , stdout );
    
    read();
    ///init();
    solve();
    
    return 0;
}
