/*
PROB: tribonacci
LANG: C++
KEYW: 
*/
/// Thanks to Him I can know and learn! Love Christ!
/// "Without Me you can do nothing" ( John 15:5 )
#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <cstring>
#include <queue>
#include <ctime>
#include <cstdio>
#include <cassert>
#include <cmath>
#include <numeric>
#include <algorithm>
#define foreach(_var,_container) for( typeof( (_container).begin() ) _var = (_container).begin() ; _var != (_container).end() ; ++_var )
#define now() double( double( clock() ) / double( CLOCKS_PER_SEC ) )
#if 1
#define eprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )
#else
#define eprintf(msg, ... ) 0
#endif
#define pprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )

typedef long long ll;

using namespace std;

const int MAXN = 1 << 5;

int N;
ll dp[MAXN];

void read(){
    scanf("%lld %lld %lld", &dp[1], &dp[2], &dp[3]);
    scanf("%d", &N);
}

void solve(){
    for( int i = 4 ; i <= N ; i++ ){
        dp[i] = dp[i - 1] + dp[i - 2] + dp[i - 3];
    }
    
    printf("%lld\n", dp[N]);
}

int main(){
    //freopen( "tribonacci.in" , "r" , stdin );
    //freopen( "tribonacci.out" , "w" , stdout );
    
    read();
    ///init();
    solve();
    
    return 0;
}
