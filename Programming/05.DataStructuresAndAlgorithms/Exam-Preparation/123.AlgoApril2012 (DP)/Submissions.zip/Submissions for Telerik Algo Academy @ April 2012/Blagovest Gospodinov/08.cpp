/*
PROB: mystic
LANG: C++
KEYW: 
*/
/// Thanks to Him I can know and learn! Love Christ!
/// "Without Me you can do nothing" ( John 15:5 )
#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <cstring>
#include <queue>
#include <ctime>
#include <cstdio>
#include <cassert>
#include <cmath>
#include <numeric>
#include <algorithm>
#define foreach(_var,_container) for( typeof( (_container).begin() ) _var = (_container).begin() ; _var != (_container).end() ; ++_var )
#define now() double( double( clock() ) / double( CLOCKS_PER_SEC ) )
#if 1
#define eprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )
#else
#define eprintf(msg, ... ) 0
#endif
#define pprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )

typedef long long ll;

using namespace std;

const int MAXN = 2600;
const int INF = 1 << 30;

int R, W, N;
char s[MAXN];

int dp[2][2][MAXN];

void read(){
    scanf("%d %d", &R, &W);
    
    scanf("%s", s);
    
    N = strlen( s );
}

void remax( int &self , int x ){
    if( self < x )
        self = x;
}

void solve(){
    fill( dp[N & 1][0] , dp[N & 1][0] + MAXN , -INF );
    fill( dp[N & 1][1] , dp[N & 1][1] + MAXN , -INF );
    
    for( int i = 1 ; i <= R ; i++ )
        dp[N & 1][0][i] = 0;
    for( int i = 1 ; i <= W ; i++ )
        dp[N & 1][1][i] = 0;
    
    const int A = max( R , W );
    
    for( int d = N - 1 ; d >= 0 ; d-- ){
        int c = d & 1;
        
        for( int i = 0 ; i <= A ; i++ ){
            /// Calc if it's right
            
            dp[c][0][i] = dp[c][1][i] = -INF;
            
            if( i < R ) /// tell truth
                remax( dp[c][0][i] , dp[c ^ 1][0][i + 1] + (s[d] == 'G'));
            
            remax( dp[c][0][i] , dp[c ^ 1][1][1] + (s[d] == 'B') );
            
            if( i < W ) /// tell a lie
                remax( dp[c][1][i] , dp[c ^ 1][1][i + 1] + (s[d] == 'B'));
            
            remax( dp[c][1][i] , dp[c ^ 1][0][1] + (s[d] == 'G') );
            
            //eprintf("Good[%d][%d] = %d , Bad[%d][%d] = %d", d, i, dp[c][0][i], d, i, dp[c][1][i]);
        }
    }
    
    printf("%d\n", max( dp[0][0][0] , dp[0][1][0] ));
}

int main(){
    //freopen( "8.in" , "r" , stdin );
    //freopen( "8.out" , "w" , stdout );
    
    read();
    ///init();
    solve();
    
    return 0;
}
