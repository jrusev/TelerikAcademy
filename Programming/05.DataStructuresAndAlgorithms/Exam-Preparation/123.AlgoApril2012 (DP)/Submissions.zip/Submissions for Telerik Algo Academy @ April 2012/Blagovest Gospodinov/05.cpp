/*
PROB: gameoflife
LANG: C++
KEYW: 
*/
/// Thanks to Him I can know and learn! Love Christ!
/// "Without Me you can do nothing" ( John 15:5 )
#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <cstring>
#include <queue>
#include <ctime>
#include <cstdio>
#include <cassert>
#include <cmath>
#include <numeric>
#include <algorithm>
#define foreach(_var,_container) for( typeof( (_container).begin() ) _var = (_container).begin() ; _var != (_container).end() ; ++_var )
#define now() double( double( clock() ) / double( CLOCKS_PER_SEC ) )
#if 1
#define eprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )
#else
#define eprintf(msg, ... ) 0
#endif
#define pprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )

typedef long long ll;

using namespace std;

const int MAXR = 1 << 7;
const int dx[] = { 0 , 0 , +1 , +1 , +1 , -1 , -1 , -1 };
const int dy[] = { -1 , +1 , 0 , -1 , +1 , 0 , -1 , +1 };

int R, C, N;
int dp[2][MAXR][MAXR];

void read(){
    scanf("%d", &N);
    scanf("%d %d", &R, &C);
    
    for( int i = 0 ; i < R ; i++ )
        for( int j = 0 ; j < C ; j++ )
            scanf("%d", &dp[0][i][j]);
}

int get( int x , int y , int id ){
    int answer = 0;
    for( int i = 0 ; i < 8 ; i++ )
        if( x + dx[i] < R and y + dy[i] < C and x + dx[i] >= 0 and y + dy[i] >= 0 and dp[id][x + dx[i]][y + dy[i]] )
            answer++;
    return answer;
}

void solve(){
    for( int i = 1 ; i <= N ; i++ ){
        int m = i & 1;
        
        for( int r = 0 ; r < R ; r++ )
            for( int c = 0 ; c < C ; c++ ){
                int neigh = get( r , c , m ^ 1 );
                if( dp[m ^ 1][r][c] ){
                    /// alive
                    if( neigh == 2 or neigh == 3 )
                        dp[m][r][c] = 1;
                    else
                        dp[m][r][c] = 0;
                }else{
                    dp[m][r][c] = neigh == 3;
                }
            }
    }
    
    int answer = 0;
    
    for( int i = 0 ; i < R ; i++ )
        answer += accumulate( dp[N & 1][i] , dp[N & 1][i] + C , 0 );
    
    printf("%d\n", answer);
}

int main(){
    //freopen( "5.in" , "r" , stdin );
    //freopen( "5.out" , "w" , stdout );
    
    read();
    ///init();
    solve();
    
    return 0;
}
