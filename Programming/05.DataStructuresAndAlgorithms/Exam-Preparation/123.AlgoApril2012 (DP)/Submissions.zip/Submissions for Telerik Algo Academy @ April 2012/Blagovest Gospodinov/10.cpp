/*
PROB: room
LANG: C++
KEYW: 
COMMENT: Stefan's epicness
*/
/// Thanks to Him I can know and learn! Love Christ!
/// "Without Me you can do nothing" ( John 15:5 )
#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <cstring>
#include <queue>
#include <ctime>
#include <cstdio>
#include <cassert>
#include <map>
#include <cmath>
#include <numeric>
#include <algorithm>
#define foreach(_var,_container) for( typeof( (_container).begin() ) _var = (_container).begin() ; _var != (_container).end() ; ++_var )
#define now() double( double( clock() ) / double( CLOCKS_PER_SEC ) )
#if 0
#define eprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )
#else
#define eprintf(msg, ... ) 0
#endif
#define pprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )

typedef long long ll;

using namespace std;

const int MAXN = 14;
const int INF = 1 << 30;

int T, N, M, A, I;
int map[MAXN]; /// set bits are dots i.e. active

int pc[1 << MAXN][1 << MAXN];
int rowcosts[1 << MAXN];

int dp[MAXN][1 << MAXN];

int out[MAXN][MAXN];

void read(){
    scanf("%d %d %d", &T, &N, &M);
    
    for( int i = 1 ; i <= N ; i++ ){
        static char mapbuff[1 + MAXN];
        
        scanf("%s", mapbuff);
        
        for( int j = 0 ; j < M ; j++ )
            if( mapbuff[j] == '.' )
                ::map[i] |= 1 << j;
        
        eprintf("map[%d] = %d", i, ::map[i]);
    }
    
    A = ( 1 << M );
}

inline int isset( int n , int x ){
    return n & ( 1 << x );
}

inline int getcost( int row ){
    int cost = 0;
    
    int loc = 0;
    
    do{
        while( loc < M and isset( row , loc ) )
            ++loc;
        
        if( loc == M )
            break;
        
        while( loc < M and !isset( row , loc ) )
              loc++;
        
        ++cost;
    }while( true );
    
    return cost;
}

void init(){
    for( int i = 0 ; i < A ; i++ ){
        rowcosts[i] = getcost( i );
        
        for( int j = 0 ; j < A ; j++ ){
            for( int k = 0 ; k < M ; k++ ){
                if( isset( j , k ) and !isset( i , k ) )
                    pc[i][j]++;
            }
        }
    }
}

void fillrow( int row , int id ){
    int loc = 0;
    
    do{
        while( loc < M and isset( row , loc ) )
            ++loc;
        
        if( loc == M )
            break;
        
        while( loc < M and !isset( row , loc ) ){
            out[id][loc++] = I;
        }
        
        I++;
    }while( true );
}

void trace( int row , int ver , vector<int> &verids ){
    if( row == N + 1 ){
        eprintf("I = %d", I);
        for( int i = 1 ; i <= N ; i++ ){
            for( int j = 0 ; j < M ; j++ ){
                eprintf("(%d,%d) -> %d", i, j, out[i][j]);
            }
        }
        return;
    }
    
    eprintf("At row %d ver = %d, I = %d", row, ver, I);
    
    for( int i = 0 ; i < M ; i++ )
        if( isset( ver , i ) )
            out[row][i] = verids[i];
        else if( !isset( ::map[row] , i ) )
            out[row][i] = -1; /// '#'
        else{
            eprintf("Cell (%d,%d)", row, i);
        }
    
    assert( (ver & ::map[row]) == ver );
    
    fillrow( (ver | (~::map[row])) & (A - 1) , row );
    
    for( int newver = A - 1 ; newver >= 0 ; newver-- ){
        /// some will stop existing others will start, always
        /// continues instead of starting new
        
        if( row < N and ( newver & ::map[row + 1] ) != newver )
            continue;
        
        if( dp[row + 1][newver] + pc[ver][newver] + rowcosts[(ver | (~::map[row])) & (A - 1)] == dp[row][ver] ){
            /// this is the next row
            for( int i = 0 ; i < M ; i++ ){
                if( (isset( newver , i )) and (!isset( ver , i )) ){ /// new id!
                    eprintf("new id for vertical #%d -> %d", i, I);
                    verids[i] = I++;
                }else if( !isset( newver , i ) )
                    verids[i] = -1;
            }
            
            trace( row + 1 , newver , verids );
            return;
        }
    }
    
}

void solve(){
    for( int i = 0 ; i < A ; i++ ){
        if( (i & ::map[N]) == i ) /// that's possible
            dp[N + 1][i] = 0;
        else
            dp[N + 1][i] = INF; /// nonsense creating new ones just for the last
    }
    
    for( int i = N ; i > 0 ; i-- ){
        for( int ver = 0 ; ver < A ; ver++ ){
            /**
             * Till row $i we have verticals of $ver
             */
            int &self = dp[i][ver];
            
            self = +INF;
            
            if( (ver & ::map[i]) != ver )
                continue;
            
            int row = ver | (~::map[i]); /// which are covered
            
            row &= A - 1;
            
            int cost = rowcosts[row];
            
            eprintf("row #%d ver = %d -> %d ( row = %d )", i, ver, cost, row);
            
            /// Now choose the verticals for the next row
            /// They're gonna be some new perhaps
            
            for( int newver = 0 ; newver < A ; newver++ ){
                /// some will stop existing others will start, always
                /// continues instead of starting new
                
                if( i < N and ( newver & ::map[i + 1] ) != newver )
                    continue;
                
                self = min( self , dp[i + 1][newver] + pc[ver][newver] + cost );
            }
            
            eprintf("DP[%d][%d] = %d", i, ver, self);
        }
    }
    
    int best = +INF, bestloc = -1;
        
    for( int i = 0 ; i < A ; i++ ){
        int row = i & ::map[1];
        
        if( row != i )
            continue;
        
        int cur = __builtin_popcount( row ) + dp[1][row];
        
        if( best > cur )
            best = cur, bestloc = i;
        
        eprintf("mask %d gives %d ( dp = %d )", i, cur, dp[1][row]);
    }
    
    if( T == 1 ){
        printf("%d\n", best);
        return;
    }
    
    vector<int> ids;
    
    for( int i = 0 ; i < M ; i++ )
        if( isset( bestloc , i ) )
            ids.push_back( I++ );
        else
            ids.push_back( 0 );
    
    trace( 1 , bestloc , ids );
    
    set<int> seen;
    std::map<int, char> mapping;
    
    char let = 'A';
    
    for( int i = 1 ; i <= N ; i++ ){
        for( int j = 0 ; j < M ; j++ ){
            if( out[i][j] >= 0 ){
                if( seen.count( out[i][j] ) > 0 )
                    printf("%c", mapping[ out[i][j] ]);
                else{
                    mapping[ out[i][j] ] = let++;
                    seen.insert( out[i][j] );
                    printf("%c", let - 1);
                }
            }else
                printf("#");
        }
        printf("\n");
    }
}

int main(){
    //freopen( "10.in" , "r" , stdin );
    //freopen( "10.out" , "w" , stdout );
    //freopen( "10.err" , "w" , stderr );
    
    read();
    init();
    solve();
    
    return 0;
}
