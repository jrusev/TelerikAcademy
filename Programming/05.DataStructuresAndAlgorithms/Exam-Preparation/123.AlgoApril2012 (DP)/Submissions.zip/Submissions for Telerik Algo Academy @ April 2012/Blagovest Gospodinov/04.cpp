/*
PROB: guitar
LANG: C++
KEYW: 
*/
/// Thanks to Him I can know and learn! Love Christ!
/// "Without Me you can do nothing" ( John 15:5 )
#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <cstring>
#include <queue>
#include <ctime>
#include <cstdio>
#include <cassert>
#include <cmath>
#include <numeric>
#include <algorithm>
#define foreach(_var,_container) for( typeof( (_container).begin() ) _var = (_container).begin() ; _var != (_container).end() ; ++_var )
#define now() double( double( clock() ) / double( CLOCKS_PER_SEC ) )
#if 1
#define eprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )
#else
#define eprintf(msg, ... ) 0
#endif
#define pprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )

typedef long long ll; 

using namespace std;

const int MAXC = 1 << 6;
const int MAXM = 1 << 10;

int C, B, M;
int a[MAXC];

int dp[MAXM][MAXM];

void read(){
    scanf("%d", &C);
    for( int i = 1 ; i <= C ; i++ )
        scanf("%d", &a[i]);
    scanf("%d %d", &B, &M);
}

void setit( int idx , int lo , int hi , int x ){
    if( lo <= x and x <= hi )
        dp[idx][x] = 1;
}

void solve(){
    dp[0][B] = 1;
    
    for( int i = 1 ; i <= C ; i++ ){
        for( int j = 0 ; j <= M ; j++ ){
            if( dp[i - 1][j] ){
                //if( i == 1 ) eprintf("setting (b = %d, m = %d) %d / %d", j, a[i], j + a[i], j - a[i]);
                setit( i , 0 , M , j + a[i] );
                setit( i , 0 , M , j - a[i] );
            }
        }
    }
    
    int answer = M;
    
    while( answer >= 0 and dp[C][answer] == 0 )
        --answer;
    
    printf("%d\n", answer);
}

int main(){
    //freopen( "4.in" , "r" , stdin );
    //freopen( "4.out" , "w" , stdout );
    
    read();
    ///init();
    solve();
    
    return 0;
}
