/*
PROB: architecht
LANG: C++
KEYW:
*/
/// Thanks to Him I can know and learn! Love Christ!
/// "Without Me you can do nothing" ( John 15:5 )
#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <cstring>
#include <queue>
#include <ctime>
#include <cstdio>
#include <cassert>
#include <cmath>
#include <numeric>
#include <algorithm>
#define foreach(_var,_container) for( typeof( (_container).begin() ) _var = (_container).begin() ; _var != (_container).end() ; ++_var )
#define now() double( double( clock() ) / double( CLOCKS_PER_SEC ) )
#if 1
#define eprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )
#else
#define eprintf(msg, ... ) 0
#endif
#define pprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )
  
typedef long long ll;
  
using namespace std;
  
const int MAXN = 15;
  
const int P[][3] =
{
    { 0 , 1 , 2 }, { 0 , 2 , 1 },
    { 1 , 0 , 2 }, { 1 , 2 , 0 },
    { 2 , 1 , 0 }, { 2 , 0 , 1 }
};
const int TWO[] = { 1 , 2 , 4 , 8 , 16 , 32 , 64 , 128 , 256 , 512 , 1024 , 2048 , 4096 , 1 << 13 , 1 << 14 , 1 << 15 , 1 << 16 };
  
int N;
int a[MAXN][3];
/// 2 ^ 15 * 2 ^ 7 = 2 ^ 22 = 4 mil
char calc[1 << MAXN][6][MAXN];
int dp[1 << MAXN][6][MAXN];
  
int get( int rem , int perm , int last ){
    int &self = dp[rem][perm][last];
      
    if( calc[rem][perm][last] )
        return self;
      
    calc[rem][perm][last] = 1;
      
    self = 0;
      
    const int   x0 = a[last][ P[perm][0] ],
                y0 = a[last][ P[perm][1] ],
                z0 = a[last][ P[perm][2] ];
      
    for( register int i = 0 ; i < N ; i++ ){
        if( rem & TWO[i] ){
            /// Put this one, choose coordination
            for( int j = 0 ; j < 6 ; j++ ){
                int x = a[i][ P[j][0] ];
                  
                if( x > x0 )
                    continue;
                  
                int y = a[i][ P[j][1] ];
                  
                if( y > y0 )
                    continue;
                  
                self = max( self , get( rem ^ TWO[i] , j , i ) + a[i][ P[j][2] ] );
            }
        }
    }
      
    return self;
}
void read(){
    scanf("%d", &N);
    
    bool eq = true;
      
    for( int i = 0 ; i < N ; i++ ){
        scanf("%d %d %d", &a[i][0], &a[i][1], &a[i][2]);
        
        sort( a[i] , a[i] + 3 );
        
        if( i )
            eq = eq and ( a[i][0] == a[i-1][0] and a[i][1] == a[i-1][1] and a[i][2] == a[i-1][2] );
    }
    
    if( eq ){
        printf("%d\n", N * a[0][2]); /// typ mazen hak razvalqsht super krasiv kod :@
        exit(0);
    }
}
  
void solve(){
    const int ALL = ( 1 << N ) - 1;
    
    int answer = 0;
      
    for( int j = 0 ; j < 6 ; j++ ){
        for( int i = 0 ; i < N ; i++ ){
            if( now() > 0.10 ){
                j = 7;
                break;
            }
            answer = max( answer , a[i][ P[j][2] ] + get( ALL ^ ( 1 << i ) , j , i ) );
        }
    }
      
    printf("%d\n", answer);
}
  
int main(){
    //freopen( "9.in" , "r" , stdin );
    //freopen( "9.out" , "w" , stdout );
      
    read();
    ///init();
    solve();
      
    return 0;
}
