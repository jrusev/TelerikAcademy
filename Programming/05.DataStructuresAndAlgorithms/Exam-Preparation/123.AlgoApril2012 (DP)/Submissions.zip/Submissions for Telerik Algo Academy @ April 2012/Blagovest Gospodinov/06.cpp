/*
PROB: lang
LANG: C++
KEYW: 
*/
/// Thanks to Him I can know and learn! Love Christ!
/// "Without Me you can do nothing" ( John 15:5 )
#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <cstring>
#include <queue>
#include <ctime>
#include <cstdio>
#include <cassert>
#include <cmath>
#include <numeric>
#include <algorithm>
#define foreach(_var,_container) for( typeof( (_container).begin() ) _var = (_container).begin() ; _var != (_container).end() ; ++_var )
#define now() double( double( clock() ) / double( CLOCKS_PER_SEC ) )
#if 0
#define eprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )
#else
#define eprintf(msg, ... ) 0
#endif
#define pprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )

typedef long long ll;

using namespace std;

const int MAXN = 1 << 6;
const int ALPHA = 26;
const int INF = 1 << 30;

int N, L;
char s[MAXN];
char w[MAXN][MAXN];

int len[MAXN];

int dp[MAXN];

inline int can( const char *w , const char *s , int len ){
    static char counts[ALPHA];
    
    fill( counts , counts + ALPHA , 0 );
    
    for( int i = 0 ; i < len ; i++ )
        counts[ w[i] - 'a' ]++;
    
    for( int i = 0 ; i < len ; i++ )
        counts[ s[i] - 'a' ]--;
    
    for( int i = 0 ; i < ALPHA ; i++ )
        if( counts[i] != 0 )
            return -1;
    
    eprintf("same -> %s and first %d of %s", w, len, s);
    
    int answer = 0;
    
    for( int i = 0 ; i < len ; i++ )
        answer += w[i] != s[i];
    
    return answer;
}

int get( int pos ){
    int &self = dp[pos];
    
    if( self != -1 )
        return self;
    
    self = INF;
    
    for( int i = 0 ; i < N ; i++ ){
        if( pos >= len[i] ){
            int x = can( w[i] , s + (pos - len[i] + 1) , len[i] );
            
            if( x >= 0 )
                self = min( self , get( pos - len[i] ) + x );
        }
    }
    
    eprintf("dp[%d] = %d", pos, self);
    
    return self;
}

void read(){
    scanf("%s", s + 1);
    
    L = strlen( s + 1 );
    
    scanf("%d", &N);
    
    for( int i = 0 ; i < N ; i++ ){
        scanf("%s", &w[i]);
        len[i] = strlen( w[i] );
    }
}

void solve(){
    memset( dp , -1 , sizeof( dp ) );
    
    dp[0] = 0;
    
    int answer = get( L );
    
    if( answer >= +INF )
        answer = -1;
        
    printf("%d\n", answer);
}

int main(){
    //freopen( "6.in" , "r" , stdin );
    //freopen( "6.out" , "w" , stdout );
    
    read();
    ///init();
    solve();
    
    return 0;
}
