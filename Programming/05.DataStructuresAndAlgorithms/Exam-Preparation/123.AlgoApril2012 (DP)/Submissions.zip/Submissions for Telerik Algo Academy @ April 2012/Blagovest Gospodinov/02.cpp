/*
PROB: supersum
LANG: C++
KEYW: 
*/
/// Thanks to Him I can know and learn! Love Christ!
/// "Without Me you can do nothing" ( John 15:5 )
#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <cstring>
#include <queue>
#include <ctime>
#include <cstdio>
#include <cassert>
#include <cmath>
#include <numeric>
#include <algorithm>
#define foreach(_var,_container) for( typeof( (_container).begin() ) _var = (_container).begin() ; _var != (_container).end() ; ++_var )
#define now() double( double( clock() ) / double( CLOCKS_PER_SEC ) )
#if 1
#define eprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )
#else
#define eprintf(msg, ... ) 0
#endif
#define pprintf(msg, ... ) fprintf(stderr," %s:%d in %s at %.4lf :: " msg "\xA" , strrchr( __FILE__ , '\\' )+1 , __LINE__ , __FUNCTION__ , now() , ##__VA_ARGS__ )

typedef long long ll;

using namespace std;

const int MAXN = 1 << 5;

int N, K;
ll dp[MAXN][MAXN];

ll get( int x , int y ){
    if( x == 0 )
        return y;
    
    ll &self = dp[x][y];
    
    if( self != -1 )
        return self;
    
    self = 0;
    
    for( int i = 1 ; i <= y ; i++ ){
        self += get( x - 1 , i );
    }
    
    return self;
}

void read(){
    scanf("%d %d", &K, &N);
}

void solve(){
    memset( dp , -1 , sizeof( dp ) );
    
    printf("%lld\n", get( K , N ));
}

int main(){
    //freopen( "2.in" , "r" , stdin );
    //freopen( "2.out" , "w" , stdout );
    
    read();
    ///init();
    solve();
    
    return 0;
}
