#include <iostream>

using namespace std;

int N;
int a[128];

int dp[128][2048];
int B, M;

void scan(){
    cin >> N;

    for ( int i = 0; i < N; ++i )
        cin >> a[i];

    cin >> B >> M;
}

void solve(){
    dp[0][B] = 1;

    for ( int i = 0; i < N; ++i )
        for ( int j = 0; j <= M; ++j )
            if ( dp[i][j] ){
                if ( j >= a[i] )
                    dp[i + 1][j - a[i]] =1 ;
                dp[i + 1][j + a[i]] = 1;
            }

    int res = -1;

    for ( int i = M; i >= 0; --i )
        if ( dp[N][i] ){
            res = i;
            break;
        }

    cout << res << endl;
}

int main(){
    scan();
    solve();
}
