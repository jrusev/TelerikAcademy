#include <iostream>
#include <cstring>

using namespace std;

int dp[2505][2505][2];

int main(){
    int R,W;

    char a[2505];
    cin >> R>>W;
    cin >> a;
    int N = strlen ( a );

    for ( int i = 0; i < N; ++i ){
        for ( int j = 0; j <= R; ++j ){
            if ( a[i] == 'G' ){
                dp[i + 1][j + 1][0] = max ( dp[i + 1][j + 1][0], dp[i][j][0] + 1 );
                dp[i + 1][1][1] = max ( dp[i + 1][1][1], dp[i][j][0] );
            }
            else{
                dp[i + 1][j + 1][0] = max ( dp[i + 1][j + 1][0], dp[i][j][0] );
                dp[i + 1][1][1] = max ( dp[i + 1][1][1], dp[i][j][0] + 1 );
                }
        }


        for ( int j = 0; j <= W; ++j ){
            if ( a[i] == 'G' ){
                dp[i + 1][j + 1][1] = max ( dp[i + 1][j + 1][1], dp[i][j][1] );
                dp[i + 1][1][0] = max ( dp[i + 1][1][0], dp[i][j][1] + 1 );
            }
            else{
                dp[i + 1][j + 1][1] = max ( dp[i + 1][j + 1][1], dp[i][j][1]  + 1);
                dp[i + 1] [1][0] = max ( dp[i + 1][1][0], dp[i][j][1] );
                }
        }
    }

    int mx = 0;

    for ( int i = 0; i <= R; ++i  )
        mx = max ( mx, dp[N][i][0] );
    for ( int i = 0; i <= W; ++i  )
        mx = max ( mx, dp[N][i][1] );
    cout << mx << endl;

}
