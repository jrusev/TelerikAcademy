#include <iostream>
#include <map>
#include <cstring>
using namespace std;

int N, a[64], diff;

map < int, int > code, decode;
int dp[64][64][64];

void scan(){
    cin >> N;
    for ( int i  = 0; i < N; ++i ){
        cin >> a[i];
        code[ a[i] ] = 0;
    }
    cin >> diff;
}

void solve(){
    int cnt = 0;


    for ( map < int, int > :: iterator it = code.begin(); it != code.end(); ++it ){
        it -> second = cnt;
        decode[cnt++] = it -> first;
    }


    for ( int i = 0; i < 64; ++i )
        for ( int j = 0; j < 64; ++j )
            for ( int k = 0; k < 64; ++k )
                dp[i][j][k] = 1e9;

    dp[0][ code[ a[0] ] ][ code[ a[0] ]] = 1;

    for ( int i = 0; i < N; ++i )
        for ( int j = 0; j< 64; ++j )
            for ( int k = 0; k < 64; ++k )
                for ( int d = 1; d < 3; ++d )
                dp[i + d][ min ( j, code[ a[i + d] ] ) ][ max ( k, code[ a[i + d] ] )] =
                 min (  dp[i + d][ min ( j, code[ a[i + d] ] ) ][ max ( k, code[ a[i + d] ] )],
                                                                            dp[i][j][k] + 1 );
    int res = N;

    for ( int i = 0; i < N; ++i )
        for ( int j = 0; j< 64; ++j )
            for ( int k = 0; k < 64; ++k )
                if ( decode[k] - decode[j] >= diff )
                    res = min ( res, dp[i][j][k] );

    cout << res << endl;
}

int main(){
    scan();
    solve();
}
