#include <iostream>
#include <cstring>

using namespace std;

long long dp[64][64];

long long sum ( int K, int N ){
    if ( K == 0 )
        return N;

    if ( dp[K][N] != -1  )
        return dp[K][N];

    dp[K][N] = 0;

    for ( int i = 1; i <= N; ++i )
        dp[K][N] += sum ( K - 1, i );

    return dp[K][N];
}

int main(){
    memset ( dp, -1, sizeof ( dp ) );

    int k, n;

    cin >> k >> n;
    cout << sum ( k, n ) << endl;
}
