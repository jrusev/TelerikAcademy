#include <iostream>
#include <cstring>

using namespace std;

long long dp[128][128];

int main(){
    dp[0][0] = 1;

    char a[256];

    cin >> a;
    int N  = strlen ( a );
    for ( int i = 1; i <= N; ++i )
        for ( int j = 0; j <= N; ++j )
            if ( a[i - 1] == '?' ){
            dp[i][j] += dp[i - 1][j + 1];
            if ( j)
                dp[i][j] += dp[i - 1][j - 1];
            }
            else
                if ( a[i - 1] == ')' )
                    dp[i][j] += dp[i -  1][j + 1];
            else if ( j ) if ( a[i - 1] == '(' )
                dp[i][j] += dp[i - 1][j - 1];

    cout << dp[strlen ( a ) ][0] << endl;
}
