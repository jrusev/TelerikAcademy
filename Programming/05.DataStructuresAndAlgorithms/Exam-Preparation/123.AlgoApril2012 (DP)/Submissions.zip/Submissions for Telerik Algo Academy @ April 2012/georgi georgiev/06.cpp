#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

string inp;

vector < string > v;
int tt;
int diff ( string t1, string t2 ){
    int res = 0;

    for ( int i = 0; i < t1.size(); ++i )
        res+= ( t1[i] != t2[i] );

    return res;
}

int eq ( string t1, string t2 ){
    sort ( t1.begin(), t1.end() );
    sort ( t2.begin(), t2.end() );

    return t1 == t2;
}

void scan(){
    cin >> inp;
    string tmp;
    cin >> tt;

    for ( int i = 0; i < tt; ++i ){
        cin >> tmp;
        v.push_back ( tmp ) ;
    }

}

int dp[64];
void solve(){
    inp = " " + inp;

    int N = inp.size();
    for ( int i = 0; i <= N; ++i )
        dp[i] =1e9;
    dp[0] =0;

    for ( int i =0 ; i <= N; ++i )
        for ( int j = 0; j < v.size(); ++j )
            if ( v[j].size() + i  < inp.size())
                if ( eq ( inp.substr ( i + 1, v[j].size() ), v[j]  ) ){
                    dp[i + v[j].size()] = min ( dp[i + v[j].size()], dp[i] + diff ( inp.substr ( i + 1, v[j].size() ), v[j] ) );
//                    cout << i << " " << j << endl;
                }

    if ( dp[N - 1] >= 1e9 )
        dp[N -1 ] = -1;
    cout << dp[N - 1] << endl;
}

int main(){
    scan();
    solve();
}
