#include <iostream>

using namespace std;

using namespace std;

int main(){
    long long a[32];

    cin >> a[1] >> a[2] >> a[3];

    for ( int i = 4; i <= 20; ++i )
        a[i] = a[i - 1] + a[i - 2] + a[i - 3];

    int n;

    cin >> n;

    cout << a[n] << endl;
}
