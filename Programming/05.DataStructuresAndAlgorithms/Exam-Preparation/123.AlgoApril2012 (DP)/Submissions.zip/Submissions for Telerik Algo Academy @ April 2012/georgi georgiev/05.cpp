#include <iostream>
#include <cstring>

using namespace std;

int a[130][130];
int t[130][130];
int T;
int N , M;

void scan(){
    cin >> T >> N >> M;

    for ( int i = 1; i <= N; ++i )
        for ( int j = 1; j <= M; ++j )
            cin >> a[i][j];
}

void solve(){
    for ( int time = 0; time < T; ++time ){
        for ( int i = 1; i <= N; ++i )
            for ( int j = 1; j <= M; ++j ){
                int cnt = 0;
                for ( int dx = -1; dx <= 1; ++dx )
                    for ( int dy = -1; dy <= 1; ++dy )
                        if ( dx || dy )
                            cnt += a[i + dx][j + dy];
                if ( a[i][j] == 0 ){
                    if ( cnt == 3 )
                        t[i][j] = 1;
                }
                else{
                    if ( cnt == 2 || cnt == 3 )
                        t[i][j] = 1;
                }
            }

        memcpy ( a, t, sizeof ( a ) );
        memset ( t, 0, sizeof ( t ) );
    }

    int res = 0;

    for ( int i = 0; i < 130; ++i )
        for ( int j = 0; j < 130; ++j )
            res += a[i][j];

    cout << res << endl;
}
int main(){
    scan();
    solve();
}
