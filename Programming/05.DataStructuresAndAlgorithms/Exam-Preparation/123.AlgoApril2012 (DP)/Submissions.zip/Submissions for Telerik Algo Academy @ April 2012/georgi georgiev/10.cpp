#include <iostream>
#include <cstdio>
using namespace std;

int T, N, M;
int dp[16][16][1 << 11];
char a[16][16];

void scan(){
    cin >> T >> N >> M;

    for ( int i = 0; i < N; ++i )
        cin >> a[i];
}


int f ( int mask, int i ){
    return mask & ( ( ( 1 << M ) - 1 ) ^ ( 1 << i ) );
}

void solve(){
    for ( int i = 0; i < 16; ++i )
        for ( int j = 0; j < 16; ++j )
            for ( int k = 0; k < ( 1 << 11 ); ++k )
                dp[i][j][k] = 1e9;

    dp[0][0][1] = ( a[0][0] != '#' );
    dp[0][0][0] = ( a[0][0]!= '#' );
    for ( int i = 0; i < N; ++i )
        for ( int j = 0; j < M; ++j )
            for ( int mask = 0; mask < ( 1 << M ); ++mask ){
                int ni = i, nj = j + 1;
                if ( nj == M ){
                    nj  =0;
                    ++ni;
                }

              //  cout << i << " " << j << " " << mask << " " << dp[i][j][mask] << endl;

                if ( a[ni][nj] == '#' ){
                    dp[ni][nj][mask] = dp[i][j][mask];
                    continue;
                }

                dp[ni][nj][mask | ( 1 << nj )] = min ( dp[ni][nj][mask | ( 1 << nj )] , dp[i][j][mask] + 1 );

                dp[ni][nj][f ( mask, nj )] =min ( dp[ni][nj][f ( mask, nj )]
                                                                     ,dp[i][j][mask] + 1 );
                //1 down
                if ( ni )
                    if ( a[ni -1 ][nj] != '#' && ( mask & ( 1 << nj ) ) )
                        dp[ni][nj][mask] = min ( dp[ni][nj][mask], dp[i][j][mask] );
                if ( nj )
                    if ( a[i][j] != '#' && ! ( mask & ( 1 << j ) ) )
                        dp[ni][nj][f ( mask, nj )]  = min (
                                                                                        dp[i][j][mask], dp[ni][nj][f ( mask, nj )] );
            }

    int res = 1e9;

    for ( int i = 0; i < ( 1 << M ); ++i )
        res = min ( res, dp[N - 1][M - 1][i] );

    cout << res << endl;
}

int main(){
    scan();
    solve();
}
