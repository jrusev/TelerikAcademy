#include <fstream>
#include <iostream>
#include <algorithm>
#include <cstring>

using namespace std;

struct cube{
    int dim[3];
};

int dp[1 << 15][15][3];
cube a[17];
int N;
int side[3][4];
void scan(){
    cin >> N;
    for ( int i = 0; i < N; ++i ){
        cin >> a[i].dim[0] >> a[i].dim[1] >> a[i].dim[2];
        sort ( a[i].dim, a[i].dim + 3 );
    }
}
//w, l, h

inline int MAX ( int t1, int t2 ){
    return ( t1 < t2 ) ? t2 : t1;
}

int f ( int mask,  int idx, int pos ){
    if ( dp[mask][idx][pos] != -1 ) return dp[mask][idx][pos];

    int cnt = 0;

    for ( int j = 0; j < N; ++j )
        if ( ( 1 << j ) & mask ){ ++cnt; }

    if ( cnt == 1 )
        return dp[mask][idx][pos] = a[idx].dim[ side[pos][2] ];
    dp[mask][idx][pos] = 0;
    for ( int i = 0; i < N; ++i )
        if ( ( mask & ( 1 << i ) )  && i != idx )
            for ( int npos = 0; npos < 3; ++npos )
            if ( a[idx].dim[ side[pos][0] ] <= a[i].dim[ side[npos][0] ] &&
                a[idx].dim[ side[pos][1] ] <= a[i].dim[ side[npos][1] ] )
                    dp[mask][idx][pos] = MAX ( dp[mask][idx][pos], f ( mask ^ ( 1 << idx ), i, npos ) +  a[idx].dim[ side[pos][2] ] );

 //   if ( cnt * 10 < dp[mask][idx][pos] )
  //      cout << mask << " " << cnt << " " << dp[mask][idx][pos] <<  endl;
    return  dp[mask][idx][pos];
}

void solve(){
    int mx = 0;
    memset ( dp, -1, sizeof ( dp ) );

    for ( int i = 1; i < ( 1 << N ); ++i )
        for ( int k = 0; k < N; ++k )
             if ( i & ( 1 << k ) )
            for ( int p = 0; p < 3; ++p )mx = max ( mx, f ( i, k, p ) );
    cout << mx << endl;
}

int main(){
   // freopen ("arh.in", "r", stdin );
    side[0][0] = 0; side[0][1] = 1; side[0][2] =2;
    side[1][0] = 0; side[1][1] = 2; side[1][2] =1;
    side[2][0] = 1; side[2][1] = 2; side[2][2] =0;
    scan();
    solve();

}
