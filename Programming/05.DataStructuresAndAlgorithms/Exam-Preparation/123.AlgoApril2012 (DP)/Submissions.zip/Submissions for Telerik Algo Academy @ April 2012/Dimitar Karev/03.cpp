//
#include<iostream>
#include<cmath>
using namespace std; 
int main()
{
    string s;
    cin>>s;
    int n=s.size(),a[85],br=0,br1=0,br2=0;
    long long sum=0;
    for(int i=0;i<n;i++)
    {
        if(s[i]=='?'){br++;}
        if(s[i]!='?' || i+1==n)
        {
            if(br==2 || br==3){sum=sum+1;}
            if(br>=4 && br<=5){sum=sum+2;}
            if(br==6 || br==7){sum=sum+5;}
            if(br==8 || br==9){sum=sum+14;}
            if(br==10 || br==11){sum=sum+42;}
            if(br==12 || br==13){sum=sum+132;}
            br=0;
        }
        if(s[i]=='('){br1++;}
        if(s[i]==')'){br2++;}
    }    
    /*if(br1+br2+br==br)
    {
        for(int i=1;i<=br/2;i++)
        {
            sum=i+sum;
        }
        cout<<sum-1<<endl;
    }
    else
    {
        br=(br-abs(br1-br2))/2;
        if(br==0){cout<<1<<endl;}
        else{cout<<br<<endl;}
    }
    */
    //if(sum!=0)cout<<sum<<endl;
    //else{cout<<1<<endl;}
    cout<<br+br1+br2<<endl;
    return 0;
}