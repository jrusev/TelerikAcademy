//
#include<iostream>
#include<cmath>
#include<string>
#include<cstring>
using namespace std; 
int main()
{
    int n,m;
    cin>>n>>m;
    string s;
    cin>>s;
    cout<<s.size()-s.size()/(n+1);
    return 0;
}