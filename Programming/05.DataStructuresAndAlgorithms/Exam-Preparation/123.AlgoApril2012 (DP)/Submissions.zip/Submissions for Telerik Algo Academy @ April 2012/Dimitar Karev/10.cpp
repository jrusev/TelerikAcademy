//
#include<iostream>
#include<cmath>
#include<string>
#include<cstring>
#include<stack>
#include<queue>
#include<iomanip>
using namespace std; 
string s[11];
int n,m,t;
int hp(int k,int k1)
{
    int br=0,br1=0;
    for(int i=k;i<n;i++)
    {
        if(s[i][k1]=='.'){br++;}
        else{break;}
    }
    for(int i=k1;i<m;i++)
    {
        if(s[k][i]=='.'){br1++;}
        else{break;}
    }
    //cout<<k<<" "<<k1<<" "<<br<<" "<<br1<<endl;
    if(br>=br1){return 1;}
    else{return 0;}
}
int main()
{
    
    
    cin>>t>>n>>m;
    for(int i=0;i<n;i++)
    {
        cin>>s[i];
    }
    int k=0,br=0;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(s[i][j]=='.')
            {
                //cout<<i<<" "<<j<<endl;   
                k=hp(i,j);
                if(k==1)
                {
                    br++;
                    int z=i;
                    while(s[z][j]!='#' && z<n)
                    {
                        s[z][j]='#';
                        z++;
                    }
                }
                else
                {
                    br++;
                    int z=j;
                    while(s[i][z]!='#' && z<m)
                    {
                        s[i][z]='#';
                        z++;
                    }
                }
            }
        }
    }
    cout<<br<<endl;
    return 0;
}