//
#include<iostream>
using namespace std;
int main()
{
    int c,a[55];
    cin>>c;
    for(int i=0;i<c;i++)
    {
        cin>>a[i];
    }
    int b,m,p=0;
    cin>>b>>m;
    for(int i=0;i<c;i++)
    {
        if(a[i]+b>m && b-a[i]>=0){p=1;}
        if(a[i]+b<=m && b-a[i]<0){p=2;}
        if(a[i]+b>m && b-a[i]<0){p=3;}
        if(a[i]+b<=m && b-a[i]>=0){p=4;}
        if(p==1){b=b-a[i];}
        if(p==2){b=b+a[i];}
        if(p==3){cout<<-1<<endl;p=-2;break;}
        if(p==4){b=b+a[i];}
        //cout<<a[i]<<" "<<b<<endl;
    }
    if(p!=-2){cout<<b<<endl;}
    /*
    14
    74 39 127 95 63 140 99 96 154 18 137 162 14 88
    40
    243
    */
    return 0;
}