//
#include<iostream>
#include<cmath>
using namespace std; 
int main()
{
    int n,a,m;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>a;
    }
    cin>>m;
    cout<<n<<endl;
    return 0;
}