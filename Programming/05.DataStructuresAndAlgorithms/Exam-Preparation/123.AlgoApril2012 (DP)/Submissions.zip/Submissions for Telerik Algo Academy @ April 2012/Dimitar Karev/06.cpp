//
#include<iostream>
#include<cmath>
using namespace std; 
int main()
{
    string s;
    cin>>s;
    int n;
cin>>n;
for(int i=0;i<n;i++)
{
cin>>s;
}
cout<<-1<<endl;
    return 0;
}