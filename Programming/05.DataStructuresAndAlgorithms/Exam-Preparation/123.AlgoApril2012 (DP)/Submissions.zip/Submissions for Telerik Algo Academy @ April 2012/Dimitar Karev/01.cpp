//
#include<iostream>
using namespace std;
int main()
{
    long long a,b,c,p;
    int n;
    cin>>a>>b>>c>>n;    
    if(n==1){cout<<a<<endl;}
    if(n==2){cout<<b<<endl;}
    if(n==3){cout<<c<<endl;}
    if(n>3)
    {
        for(int i=3;i<=n-1;i++)
        {
            p=c;
            c=a+b+c;
            a=b;
            b=p;
            //cout<<a<<" "<<b<<" "<<c<<endl;
        }
        cout<<c<<endl;
    }
    return 0;
}