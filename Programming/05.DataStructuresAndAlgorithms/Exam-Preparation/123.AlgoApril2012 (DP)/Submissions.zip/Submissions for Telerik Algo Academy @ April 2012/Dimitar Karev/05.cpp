//
#include<iostream>
using namespace std; 
int n;
int e,r,a[130][130],b[130][130];
void swapp()
{
    for(int i=1;i<=e;i++)
    {
        for(int j=1;j<=r;j++)
        {
            a[i][j]=b[i][j];
            //cout<<b[i][j]<<" ";
        }
        //cout<<endl;
    }
}
int main()
{
   
    cin>>n>>e>>r;
    for(int i=1;i<=e;i++)
    {
        for(int j=1;j<=r;j++)
        {
            cin>>a[i][j];
        }
    }
    /*for(int i=0;i<e;i++)
    {
        a[0][i]=-1;
    }
    for(int j=0;j<r;j++)
    {
        a[j][0]=-1;
    }
    */
    //cout<<a[4][6]<<" "<<a[3][6]<<" "<<a[2][6]<<" "<<a[4][4]<<" "<<a[3][4]<<" "<<a[4][5]<<" "<<a[2][4]<<" "<<a[2][5]<<endl;
    int k=0;
    for(int o=0;o<n;o++)
    {
        for(int i=1;i<=e;i++)
        {
            for(int j=1;j<=r;j++)
            {
                k=a[i-1][j-1]+a[i-1][j]+a[i-1][j+1]+a[i][j-1]+a[i][j+1]+a[i+1][j-1]+a[i+1][j]+a[i+1][j+1];
      //         if(i==3 && j==5) cout<<k<<endl;
                if(a[i][j]==0)
                {
                    if(k==3){b[i][j]=1;}
                    if(k!=3){b[i][j]=0;}
                }
                else
                {
                    if(k>=2 && k<=3){b[i][j]=1;}
                    if(k<2){b[i][j]=0;}
                    if(k>3){b[i][j]=0;}
                }
               
            }
        }
        swapp();
    }
    int br=0;
    for(int i=1;i<=e;i++)
    {
        for(int j=1;j<=r;j++)
        {
            if(a[i][j]==1){br++;}
        }
    }
    cout<<br<<endl;
    return 0;
}