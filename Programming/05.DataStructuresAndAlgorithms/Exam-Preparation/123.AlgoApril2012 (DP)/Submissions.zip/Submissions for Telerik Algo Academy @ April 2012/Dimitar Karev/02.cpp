//
#include<iostream>
using namespace std;
int main()
{
    int k,n,a[15][15],sum=0;
    cin>>k>>n;
    for(int i=0;i<=14;i++)
    {
        sum=sum+i;
        a[1][i]=sum;
        //cout<<a[1][i]<<" ";
        
    }
    //cout<<endl;
    sum=0;
    for(int i=0;i<=14;i++)
    {
        sum=sum+a[1][i];
        a[2][i]=sum;
        //cout<<a[2][i]<<" ";
        
    }
    //cout<<endl;
    sum=0;
        for(int i=0;i<=14;i++)
    {
        sum=sum+a[2][i];
        a[3][i]=sum;
        //cout<<a[3][i]<<" ";
        
    }
    //cout<<endl;
    sum=0;
    for(int i=0;i<=14;i++)
    {
        sum=sum+a[3][i];
        a[4][i]=sum;
        //cout<<a[4][i]<<" ";
        
    }
    //cout<<endl;
    sum=0;
    for(int i=0;i<=14;i++)
    {
        sum=sum+a[4][i];
        a[5][i]=sum;
        //cout<<a[5][i]<<" ";
        
    }
    //cout<<endl;
    sum=0;
    for(int i=0;i<=14;i++)
    {
        sum=sum+a[5][i];
        a[6][i]=sum;
        //cout<<a[6][i]<<" ";
        
    }
    //cout<<endl;
    sum=0;
    for(int i=0;i<=14;i++)
    {
        sum=sum+a[6][i];
        a[7][i]=sum;
        //cout<<a[7][i]<<" ";
        
    }
    //cout<<endl;
    sum=0;
    for(int i=0;i<=14;i++)
    {
        sum=sum+a[7][i];
        a[8][i]=sum;
        //cout<<a[8][i]<<" ";
        
    }
    //cout<<endl;
    sum=0;
    for(int i=0;i<=14;i++)
    {
        sum=sum+a[8][i];
        a[9][i]=sum;
        //cout<<a[9][i]<<" ";
        
    }
    //cout<<endl;
    sum=0;        
    for(int i=0;i<=14;i++)
    {
        sum=sum+a[9][i];
        a[10][i]=sum;
        //cout<<a[10][i]<<" ";
        
    }
    //cout<<endl;
    sum=0;
    for(int i=0;i<=14;i++)
    {
        sum=sum+a[10][i];
        a[11][i]=sum;
        //cout<<a[11][i]<<" ";
        
    }
    //cout<<endl;
    sum=0;
    for(int i=0;i<=14;i++)
    {
        sum=sum+a[11][i];
        a[12][i]=sum;
        //cout<<a[12][i]<<" ";
        
    }
    //cout<<endl;
    sum=0;
    for(int i=0;i<=14;i++)
    {
        sum=sum+a[12][i];
        a[13][i]=sum;
        //cout<<a[13][i]<<" ";
        
    }
    //cout<<endl;
    sum=0;
    for(int i=0;i<=14;i++)
    {
        sum=sum+a[13][i];
        a[14][i]=sum;
        //cout<<a[14][i]<<" ";
    }
    //cout<<endl;
    cout<<a[k][n]<<endl;
    return 0;
}