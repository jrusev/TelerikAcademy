//
#include<iostream>
#include<cmath>
#include<string>
#include<cstring>
using namespace std; 
int main()
{
    int n,a,b,c,sum=0;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>a>>b>>c;
        sum=sum+c;
    }
    cout<<sum<<endl;
    return 0;
}