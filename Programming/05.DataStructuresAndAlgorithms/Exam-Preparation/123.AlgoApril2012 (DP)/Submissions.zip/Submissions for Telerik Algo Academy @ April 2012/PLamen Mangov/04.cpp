#include "iostream"
using namespace std;

int c,b,m,dp[1001],v[51];

int main()
{
    cin>>c;
    for(int i=1; i<=c; i++)
    {
        cin>>v[i];
    }
    cin>>b>>m;
    dp[b]=1;
    bool p=1;
    for(int i=1; i<=c; i++)
    {
        for(int j=0; j<=m; j++)
        {
            if(dp[j]==i)
            {
                if(v[i]+j<=m)
                {
                    dp[v[i]+j]=i+1;
                }
                if(j-v[i]>=0)
                {
                    dp[j-v[i]]=i+1;
                }
            }
        }
    }
    if(!p) cout<<-1<<endl;
    else
    {
        b=m;
        while(dp[b]!=c+1)b--;
        cout<<b<<endl;
    }
}
