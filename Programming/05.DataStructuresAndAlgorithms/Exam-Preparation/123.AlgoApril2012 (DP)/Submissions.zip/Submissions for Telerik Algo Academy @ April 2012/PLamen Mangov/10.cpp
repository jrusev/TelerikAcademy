#include "iostream"
using namespace std;
int main()
{
    int t,n,m,cnt=1;
    char r[10][10];
    cin>>t>>n>>m;
    if(t==2) cout<<"Nyamam si i na ideq ;/\n";
    else
    {
        for(int i=0; i<n; i++)
        {
            for(int j=0; j<m; j++)
            {
                cin>>r[i][j];
            }
        }
    cout<<13<<endl;
    }
}
