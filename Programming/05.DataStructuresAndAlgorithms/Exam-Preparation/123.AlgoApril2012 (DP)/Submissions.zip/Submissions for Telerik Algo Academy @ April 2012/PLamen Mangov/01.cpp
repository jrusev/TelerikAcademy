#include "iostream"
using namespace std;
int main()
{
    long long t[21];
    int n;
    cin>>t[1]>>t[2]>>t[3]>>n;
    for(int i=4; i<=n; i++)
    {
        t[i]=t[i-1]+t[i-2]+t[i-3];
    }
    cout<<t[n]<<endl;
}
