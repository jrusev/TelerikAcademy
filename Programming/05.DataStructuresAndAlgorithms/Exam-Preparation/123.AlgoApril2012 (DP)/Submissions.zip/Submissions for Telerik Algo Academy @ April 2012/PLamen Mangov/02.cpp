#include "iostream"
using namespace std;

int dp[15][15];

int main()
{
    unsigned k,n;
    int sum=0;
    cin>>k>>n;
    for(int i=0; i<=n; i++) dp[0][i]=i;
    for(int i=1; i<=n; i++) dp[1][i]=dp[1][i-1]+i;
    for(int i=2; i<=k; i++)
    {
        for(int j=1; j<=n; j++)
        {
            for(int p=1; p<=j; p++)
            {
                sum+=dp[i-1][p];
            }
            dp[i][j]=sum;
            sum=0;
        }
    }
    cout<<dp[k][n]<<endl;
}
