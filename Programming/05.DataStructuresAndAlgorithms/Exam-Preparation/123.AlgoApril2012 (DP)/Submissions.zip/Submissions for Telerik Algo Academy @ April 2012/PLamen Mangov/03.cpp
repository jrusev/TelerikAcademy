#include "iostream"
using namespace std;
int main()
{
    string a;
    cin>>a;
    cout<<0<<endl;
}