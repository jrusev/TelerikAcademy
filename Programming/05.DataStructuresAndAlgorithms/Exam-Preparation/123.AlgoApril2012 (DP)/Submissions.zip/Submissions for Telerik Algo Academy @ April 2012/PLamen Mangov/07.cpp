#include "iostream"
#include "cmath"
using namespace std;
int main()
{
    int n,t[50],r,max=0,min=2000;
    cin>>n;
    for(int i=0; i<n; i++)
    {
        cin>>t[i];
        if(t[i]>min) min=t[i];
    }
    cin>>r;
        int cnt=0;
        for(int i=0; i<n; i++)
        {
            if(t[i]>max)max=t[i];
            if(t[i]<min)min=t[i];
            if(abs(t[i]-t[i+1])<abs(t[i]-t[i+2])) i++;
            cnt++;
            if(max-min>=r) break;
        }
        cout<<cnt<<endl;

}
