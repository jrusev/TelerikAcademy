#include <cstdio>
#include <cstring>
#include <algorithm>
#include <utility>
#include <set>
using namespace std;

const int MAXDIF = 1024;

struct Node
{
    int l , r;
    int val;

    Node ()
    {
        l = r = val = 0;
    }

    Node ( int _l , int _r , int _val )
    {
        l = _l;
        r = _r;
        val = _val;
    }

    bool operator < ( const Node t ) const
    {
        if ( l != t.l ) return l < t.l;
        if ( r != t.r ) return r < t.r;
        return val < t.val;
    }
};


set < Node > dp[3];
int n , dif;
int x[64];


void read()
{
    scanf ( "%d" , &n );

    int i;
    for (i = 0; i < n; ++i)
        scanf ( "%d" , x + i );

    scanf ( "%d" , &dif );
}

int get ( int x )
{
    if ( x == -1 ) x = 2;
    if ( x == -2 ) x = 1;

    return x % 3;
}

void add ( int &x , int y )
{
    if ( x > y ) x = y;
}

void check ( int &res , int val , int nmin , int nmax )
{
    if ( nmax - nmin >= dif )
        if ( res > val )
            res = val;
}

void solve()
{
    int i , j , k;

    dp[0].insert ( Node ( x[0] , x[0] , 1 ) );
    int res = n;

    for (i = 0; i < n - 1; ++i)
    {
        /*
        for (j = 0; j < MAXDIF; ++j)
            for (k = j; k < MAXDIF; ++k)
            {
                dp[ get ( i + 2 ) ][j][k] = 1 << 29;

                if ( (dp[ get ( i ) ][j][k] != (1 << 29)) && (k - j >= dif) )
                {
                    add ( res , dp[ get ( i ) ][j][k] );
                }
            }
        */
        set < Node >::iterator it;
        for (it = dp[ get ( i ) ].begin(); it != dp[ get ( i ) ].end(); ++it)
        {
            if ( it->r - it->l >= dif )
                add ( res , it->val );
        }
        dp[ get ( i + 2 ) ].clear();


        for (it = dp[ get ( i ) ].begin(); it != dp[ get ( i ) ].end(); ++it)
        {
            int nmin , nmax;

            nmin = min ( it->l , x[i + 1] );
            nmax = max ( it->r , x[i + 1] );

            dp[ get ( i + 1 ) ].insert ( Node ( nmin , nmax , it->val + 1 ) );
            check ( res , it->val + 1 , nmin , nmax );

            if ( i + 2 < n )
            {
                nmin = min ( it->l , x[i + 2] );
                nmax = max ( it->r , x[i + 2] );

                dp[ get ( i + 2 ) ].insert ( Node ( nmin , nmax , it->val + 1 ) );
                check ( res , it->val + 1 , nmin , nmax );
            }
        }
    }

    set < Node >::iterator it;
    for (it = dp[ get ( n -1 ) ].begin(); it != dp[ get ( n - 1 ) ].end(); ++it)
    {
        check ( res , it->val , it->l , it->r );
    }
    printf ( "%d\n" , res );

}



int main()
{
    read();
    solve();

    return 0;
}
