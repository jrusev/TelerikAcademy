#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

const int MAXN = 12;

struct State
{
    int row;
    int mask;

    State ( int _row = -1 , int _mask = -1 )
    {
        this->row = _row;
        this->mask = _mask;
    }
};


State arow[MAXN][1 << MAXN];
int dp[MAXN][1 << MAXN];

char ma3x[MAXN][MAXN];
vector < char > tmpg[MAXN];

int rmask[MAXN];

int t , n , m;

int dr[MAXN];


void read()
{
    scanf ( "%d%d%d" , &t , &n , &m );

    int i , j;
    for (i = 0; i < n; ++i)
        scanf ( "%s" , &ma3x[i] );
}


int go ( int row , int pmask )
{
    if ( row >= n )
    {
        return 0;
    }

    int &res = dp[row][pmask];
    if ( res != -1 ) return res;

    res = 1 << 29;
    int i , tmask;

    for (tmask = (1 << m) - 1; tmask >= 0; --tmask)
    {
        int tmp = 0;
        for (i = 0; i < m; ++i)
        {
            if ( ma3x[row][i] == '#' ) continue;
            if ( (tmask >> i) & 1 )
            {
                if ( i == 0 ) ++tmp;
                else
                {
                    if ( !((tmask >> (i - 1)) & 1) || ma3x[row][i - 1] == '#' )
                        ++tmp;
                }
            }
            else
            {
                if ( ma3x[row - 1][i] == '#' ) ++tmp;
                else if ( ((pmask >> i) & 1) ) ++tmp;
            }
        }

        int f = go ( row + 1 , tmask | rmask[row] ) + tmp;
        if ( f < res )
        {
            res = f;
            arow[row][pmask] = State ( row + 1 , tmask | rmask[row] );
        }

        //res = min ( res , go ( row + 1 , tmask | rmask[row] ) + tmp );
    }

    return res;
}

void init()
{
    int i , j;
    for (i = 0; i < n; ++i)
    {
        for (j = 0; j < m; ++j)
        {
            if ( ma3x[i][j] == '#' )
            {
                rmask[i] |= 1 << j;
            }
        }
    }
}


void printg()
{
    State t = arow[0][0];
    while ( t.row != -1 )
    {
        dr[ t.row - 1 ] = t.mask;
        t = arow[ t.row ][ t.mask ];
    }


    char cl = 'A';
    int i , j;

    for (i = 0; i < n; ++i)
    {
        for (j = 0; j < m; ++j)
        {
            if ( ma3x[i][j] == '#' )
                tmpg[i].push_back ( '#' );//[j] = '#';

            else if ( (dr[i] >> j) & 1 )
                tmpg[i].push_back ( '1' ); //[j] = '1';

            else
                tmpg[i].push_back ( '0' ); //[j] = '0';
        }
    }



    int ni , nj;
    for (i = 0; i < n; ++i)
    {
        for (j = 0; j < m; ++j)
        {
            ni = i;
            nj = j;
            if ( tmpg[ni][nj] == '1' )
            {
                while ( nj < m && tmpg[ni][nj] == '1' ) tmpg[ni][ nj++ ] = cl;
                cl++;
            }
            else if ( tmpg[ni][nj] == '0' )
            {
                while ( ni < n && tmpg[ni][nj] == '0' ) tmpg[ ni++ ][nj] = cl;
                ++cl;
            }
        }
    }
    for (i = 0; i < n; ++i)
    {
        for (j = 0; j < m; ++j)
        {
            printf ( "%c" , tmpg[i][j] );
        }
        puts ( "" );
    }
}

void solve()
{
    init();

    memset ( dp , -1 , sizeof dp );

    int mask , res = 1 << 29;
    for (mask = (1 << m) - 1; mask >= 0; --mask)
    {
        int tmp = 0;
        for (int j = 0; j < m; ++j)
        {
            if ( ma3x[0][j] == '#' )
                continue;

            else if ( j == 0 )
                ++tmp;

            else
            {
                if ( !((mask >> j) & 1) )
                    ++tmp;

                else if ( ((mask >> j) & 1) )
                {
                    if ( (!((mask >> (j - 1)) & 1)) || ma3x[0][j - 1] == '#' )
                        ++tmp;
                }
            }
            //printf ( "%d  %d\n" , j , tmp );
        }
        int f = go ( 1 , mask | rmask[0] ) + tmp;
        if ( f < res )
        {
            res = f;
            arow[0][0] = State ( 1 , mask | rmask[0] );
        }
        //res = min ( res , go ( 1 , mask | rmask[0] ) + tmp );
    }

    if ( t == 1 )
    {
        printf ( "%d\n" , res );
    }
    else
    {
        printg();
    }

}

int main()
{
    read();
    solve();

    return 0;
}
