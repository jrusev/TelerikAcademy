#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;

struct Word
{
    string t;
    int freq[32];

    Word ()
    {
        this->t = "";
        memset ( freq , 0 , sizeof freq );
    }

    Word ( string _t )
    {
        this->t = _t;
        memset ( freq , 0 , sizeof freq );
        this->init();
    }

    void read()
    {
        cin >> t;
        this->init();
    }

    void init()
    {
        int i;
        for (i = 0; i < (int)t.length(); ++i)
            freq[ t[i] - 'a' ]++;
    }

    bool operator == ( const Word o ) const
    {
        int i;
        for (i = 0; i < 32; ++i)
            if ( this->freq[i] != o.freq[i] )
                return 0;

        return 1;
    }
};


vector < Word > v;
string s;
int n;

int dp[64];


void read()
{
    cin >> s;

    int wc;
    scanf ( "%d" , &wc );

    for (int i = 0; i < wc; ++i)
    {
        Word t;
        t.read();

        v.push_back ( t );
    }
}

int go ( int pos )
{
    if ( pos == n )
        return 0;

    int &res = dp[pos];
    if ( res != -1 )
        return res;

    res = 1 << 29;

    int i , j;
    for (i = 0; i < (int)v.size(); ++i)
    {
        int tlen = (int)v[i].t.length();
        if ( pos + tlen > n )
            continue;

        string tmp;
        for (j = 0; j < tlen; ++j)
            tmp.push_back ( s[pos + j] );

        Word w ( tmp );
        //cout << pos << " " << w.t << endl;

        if ( v[i] == w )
        {
            int diff = 0;
            for (j = 0; j < tlen; ++j)
            {
                if ( v[i].t[j] != tmp[j] )
                    ++diff;
            }

            res = min ( res , go ( pos + tlen ) + diff );
        }
    }

    return res;
}

void solve()
{
    n = (int)s.length();
    memset ( dp , -1 , sizeof dp );

    int res = go ( 0 );

    if ( res == (1 << 29) )
        res = -1;


    printf ( "%d\n" , res );
}

int main()
{
    read();
    solve();

    return 0;
}
