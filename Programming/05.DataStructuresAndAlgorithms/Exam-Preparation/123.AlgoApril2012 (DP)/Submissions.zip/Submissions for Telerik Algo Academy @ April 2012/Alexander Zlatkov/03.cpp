#include <cstdio>
#include <cstring>
using namespace std;

const int MAXN = 64;

typedef long long int lli;

lli dp[128][MAXN][MAXN]; //pos , open
char s[128];

int n;

void read()
{
    scanf ( "%s" , s );
}

lli go ( int pos , int open , int close )
{
    if ( pos == n )
        return (open == close);

    lli &res = dp[pos][open][close];
    if ( res != -1 ) return res;

    res = 0;
    if ( s[pos] != '?' )
    {
        if ( s[pos] == '(' && pos < n  )
            res = go ( pos + 1 , open + 1 , close );

        else if ( pos > 0 )
            res = go ( pos + 1 , open , close + 1 );
    }
    else
    {
        if ( pos < n )
            res += go ( pos + 1 , open + 1 , close );

        if ( open > close && pos > 0 )
            res += go ( pos + 1 , open , close + 1 );
    }
    return res;
}


void solve()
{
    n = (int)strlen ( s );
    memset ( dp , -1 , sizeof dp );

    lli res = go ( 0 , 0 , 0 );
    printf ( "%lld\n" , res );
}



int main()
{
    read();
    solve();

    return 0;
}
