#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

struct Cube
{
    int x[3];

    Cube ( int _x = 0 , int _y = 0 , int _z = 0 )
    {
        this->x[0] = _x;
        this->x[1] = _y;
        this->x[2] = _z;
    }

};

const int MAXN = 16;

Cube c[MAXN];
int dp[1 << MAXN][MAXN][3];

int n;


void read()
{
    scanf ( "%d" , &n );

    int i , j;
    for (i = 0; i < n; ++i)
    {
        for (j = 0; j < 3; ++j)
            scanf ( "%d" , &c[i].x[j] );

        sort ( c[i].x , c[i].x + 3 );
    }
}


int go ( int mask , int last , int a )
{
    if ( mask == (1 << n) - 1 )
        return 0;

    int &res = dp[mask][last][a];
    if ( res != -1 )
        return res;

    res = 0;
    int i , j , k;
    for (i = 0; i < n; ++i)
        {
            if ( !((mask >> i) & 1) )
            {
                for (j = 0; j < 3; ++j)
                {
                    if ( j )
                        if ( c[i].x[j] == c[i].x[j - 1] ) continue;


                    int add = c[i].x[j];

                    int n1 = (j + 1) % 3;
                    int n2 = (j + 2) % 3;

                    int o1 = (a + 1) % 3;
                    int o2 = (a + 2) % 3;

                    if ( c[last].x[o1] > c[last].x[o2] ) swap ( o1 , o2 );
                    if ( c[i].x[n1] > c[i].x[n2] ) swap ( n1 , n2 );


                    if ( c[last].x[o1] >= c[i].x[n1] && c[last].x[o2] >= c[i].x[n2] )
                    {
                        res = max ( res , go ( mask | (1 << i) , i , j ) + add );
                    }
                }
            }
    }

    return res;
}

void solve()
{
    memset ( dp , -1 , sizeof dp );

    int res = 0;
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < 3; ++j)
        {
            if ( j )
                if ( c[i].x[j] == c[i].x[j - 1] ) continue;

            res = max ( res , go ( 1 << i , i , j ) + c[i].x[j] );
        }
    }
    printf ( "%d\n" , res );
}

int main()
{
    read();
    solve();

    return 0;
}
