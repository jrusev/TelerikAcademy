#include <cstdio>
#include <iostream>
using namespace std;

typedef long long int lli;


lli t1 , t2 , t3;
lli n;


void read()
{
    cin >> t1 >> t2 >> t3 >> n;
}


void solve()
{
    if ( n == 1 )
    {
        cout << t1 << endl;
        return;
    }
    if ( n == 2 )
    {
        cout << t2 << endl;
        return;
    }
    if ( n == 3 )
    {
        cout << t3 << endl;
        return;
    }
    lli t4;
    for (int i = 4; i <= n; ++i)
    {
        t4 = t1 + t2 + t3;
        t1 = t2;
        t2 = t3;
        t3 = t4;
    }

    cout << t3 << endl;
}



int main()
{
    read();
    solve();

    return 0;
}
