#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int MAXN = 64;

int dp[MAXN][1024];

int n , s , m;
int x[MAXN];


void read()
{
    scanf ( "%d" , &n );

    int i;
    for (i = 1; i <= n; ++i)
        scanf ( "%d" , x + i );

    scanf ( "%d%d" , &s , &m );
}

int go ( int pos , int volume )
{
    if ( volume < 0 ) return -(1 << 29);
    if ( volume > m ) return -(1 << 29);

    if ( pos > n )
    {
        return volume;
    }

    int &res = dp[pos][volume];
    if ( res != -1 ) return res;

    res = -(1 << 29);
    res = max ( go ( pos + 1 , volume + x[pos] ) , go ( pos + 1 , volume - x[pos] ) );
    return res;

}

void solve()
{
    memset ( dp , -1 , sizeof dp );

    int res = go ( 1 , s );
    printf ( "%d\n" , max ( -1 , res ) );
}

int main()
{
    read();
    solve();

    return 0;
}
