#include <cstdio>
#include <cstring>
using namespace std;


int k , n;
int dp[16][16];

void read()
{
    scanf ( "%d%d" , &k , &n );
}

int go ( int x , int y )
{
    if ( x == 0 ) return y;

    int &res = dp[x][y];
    if ( res != -1 ) return res;

    res = 0;
    for (int i = 1; i <= y; ++i)
        res += go ( x - 1 , i );

    return res;
}

void solve()
{
    memset ( dp , -1 , sizeof dp );

    int res = go ( k , n );
    printf ( "%d\n" , res );
}

int main()
{
    read();
    solve();

    return 0;
}
