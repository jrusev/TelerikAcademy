#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

const int MAXN = 2502;

string s;
int r , w;

int dp[MAXN][MAXN][2];
int n;


void read()
{
    cin >> r >> w;
    cin >> s;
}

int go ( int pos , int left , int type )
{
    if ( pos == n )
        return 0;

    int &res = dp[pos][left][type];
    if ( res != -1 )
        return res;

    res = 0;
    if ( left )
    {
        if ( type == 1 )
        {
            if ( s[pos] == 'G' )
            {
                res = max ( res , go ( pos + 1 , left - 1 , 1 ) + 1 );
                res = max ( res , go ( pos + 1 , w - 1 , 0 ) + 1 );
            }

            if ( s[pos] == 'B' )
            {
                res = max ( res , go ( pos + 1 , left - 1 , 1 ) );
                res = max ( res , go ( pos + 1 , w - 1 , 0 ) );
            }
        }
        else if ( type == 0 )
        {
            if ( s[pos] == 'G' )
            {
                res = max ( res , go ( pos + 1 , left - 1 , 0 ) );
                res = max ( res , go ( pos + 1 , r - 1 , 1 ) );
            }
            if ( s[pos] == 'B' )
            {
                res = max ( res , go ( pos + 1 , left - 1 , 0 ) + 1 );
                res = max ( res , go ( pos + 1 , r - 1 , 1 ) + 1 );
            }
        }
    }
    else
    {
        if ( s[pos] == 'G' )
        {
            if ( type == 1 )
            {
                res = max ( res , go ( pos + 1 , w - 1 , 0 ) + 1 );
            }
            else
            {
                res = max ( res , go ( pos + 1 , r - 1 , 1 ) );
            }
        }
        else
        {
            if ( type == 1 )
            {
                res = max ( res , go ( pos + 1 , w - 1 , 0 ) );
            }
            else
            {
                res = max ( res , go ( pos + 1 , r - 1 , 1 ) + 1 );
            }
        }
    }
    return res;
}

void solve()
{
    n = (int)s.length();
    memset ( dp , -1 , sizeof dp );

    int res = max ( go ( 0 , r - 1 , 1 ) , go ( 0 , w - 1 , 0 ) );
    printf ( "%d\n" , res );
}


int main()
{
    read();
    solve();

    return 0;
}
