#include <cstdio>

const int MAXR = 130;

const int dx[] = { -1 , -1 , -1 , 0 , 0, 1 , 1 , 1 };
const int dy[] = { -1 , 0 , 1 , -1 , 1 , -1 , 0 , 1 };
const int dm = 8;


int ma3x[2][MAXR][MAXR];

int r , c;
int n;

void read()
{
    scanf ( "%d" , &n );
    scanf ( "%d%d" , &r , &c );

    int i , j;
    for (i = 0; i < r; ++i)
        for (j = 0; j < c; ++j)
            scanf ( "%d" , &ma3x[0][i][j] );
}

bool ok ( int x , int y )
{
    return x >= 0 && x < r && y >= 0 && y < c;
}

void go ( int pos )
{
    int pr;
    if ( pos == 1 ) pr = 0;
    else pr = 1;


    int i , j , k;
    for (i = 0; i < r; ++i)
        for (j = 0; j < c; ++j)
        {
            int tmp = 0;
            for (k = 0; k < dm; ++k)
            {
                if ( ok ( i + dx[k] , j + dy[k] ) )
                {
                    tmp += ma3x[pr][ i + dx[k] ][ j + dy[k] ];
                }
            }


            if ( ma3x[pr][i][j] == 1 )
            {
                if ( tmp == 2 || tmp == 3 )
                    ma3x[pos][i][j] = 1;

                if ( tmp < 2 )
                    ma3x[pos][i][j] = 0;

                if ( tmp > 3 )
                    ma3x[pos][i][j] = 0;
            }
            else
            {
                if ( tmp == 3 )
                    ma3x[pos][i][j] = 1;
                else
                    ma3x[pos][i][j] = 0;
            }
        }
}


void solve()
{
    int i , j , pos = 1;
    for (i = 1; i <= n; ++i)
    {
        go ( pos );
        pos = (pos + 1) % 2;
    }

    pos = 1 - pos;
    int res = 0;

    for (i = 0; i < r; ++i)
        for (j = 0; j < c; ++j)
            res += ma3x[pos][i][j];

    printf ( "%d\n" , res );
}


int main()
{
    read();
    solve();

    return 0;
}
