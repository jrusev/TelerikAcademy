#include <iostream>
using namespace std;
int main ()
{
long long t1, t2, t3, n, p;
cin>>t1>>t2>>t3>>n;
for (long long i=1; i<=n-3; i++)
{
    p=t1+t2+t3;
    t1=t2;
    t2=t3;
    t3=p;
}
cout<<t3<<endl;
return 0;
}
