#include <iostream>
#include <cstring>
using namespace std;
char niz[2550];
int main ()
{
int r,w,n,br=0, r1, w1;
cin>>r>>w;
cin>>niz;
n=strlen(niz);
r1=r;
w1=w;
while (n>0)
{
if (((niz[n]!='B' || w1==0) && r1>0) || (niz[n]!='B' && w1==0 && r1>0))
{
    br++;
    r1--;
    n--;
    if (niz[n]=='B') br--;
 
    }
 
if (((niz[n]!='G' || r1==0) && w1>0) || (niz[n]!='G' && r1==0 && w1>0))
{
    w1--;
    n--;
    if (niz[n]=='B') br++;
 
}
    if (r1==0) r1=r;
    if (w1==0) w1=w;
}
cout<<br<<endl;
return 0;
}