#include <iostream>
using namespace std;
long long mas[500];
int main ()
{
long long K, N, p=1, br=1;
cin>>K>>N;
mas[14]=1;
for(int i=15; i<N+15; i++)
{
    int p=i;
    for (int v=K-1; v>=0; v--)
    {
      mas[i]=mas[i]+mas[p-1];
      p=p-1;
    }

br=br+mas[i];
}
cout<<br-1<<endl;
return 0;
}