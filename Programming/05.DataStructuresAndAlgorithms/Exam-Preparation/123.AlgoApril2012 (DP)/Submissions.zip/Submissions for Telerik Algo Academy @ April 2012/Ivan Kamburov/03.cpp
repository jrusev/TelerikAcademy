#include <cstdio>
#include <iostream>
#include <string.h>

using namespace std;

char input[81];
unsigned long long number_of_valid_moves = 0;
int size = 0;

bool valid_check()
{
    int br_open = 0, br_close = 0;
    for (int i = 0; i < size; i++)
    {
        if (input[i] == '(') br_open++;
        else
        {
            br_close++;
            if (br_close > br_open) return false;
        }
    }
    
    if (br_close != br_open) return false;
    
    return true;
}

void change_of_q_mark(int place)
{
    if (place == size) if (valid_check()) number_of_valid_moves++;
    
    if (input[place] == '?')
    {
        input[place] = '(';
        change_of_q_mark(place + 1);
        input[place] = ')';
        change_of_q_mark(place + 1);
        input[place] = '?';
    }
    else if (place < size) change_of_q_mark(place + 1);
}

int main()
{
    scanf("%s", input);
    
    size = strlen(input);
    
    change_of_q_mark(0);
    
    cout << number_of_valid_moves << endl;
    
    return 0;
}
