#include <iostream>//<cstdio>

using namespace std;

int songs = 0, before_every_song_1[50], before_every_song_2[50], max_power = 0, current_power = 0, power = -1;

int main()
{
    cin >> songs;
    
    for (int i = 0; i < songs; i++)
    {
        cin >> before_every_song_1[i];
        before_every_song_2[i] = -before_every_song_1[i];
    }
    
    cin >> current_power >> max_power;
    
    cout << max_power << endl;
    
    return 0;
}
