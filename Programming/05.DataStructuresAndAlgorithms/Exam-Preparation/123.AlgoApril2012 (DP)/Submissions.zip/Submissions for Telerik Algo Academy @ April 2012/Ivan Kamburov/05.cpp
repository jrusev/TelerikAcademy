#include <cstdio>
#include <iostream>

using namespace std;

int a[127][127], neighbouring[127][127], r, c, n, count1 = 0;

int neighbours(int i, int j)
{
    int br = 0;
    if ((i == 0) && (j == 0))
    {
        if (a[0][1]) br++;
        if (a[1][0]) br++;
        if (a[1][1]) br++;
    }
    else if ((i == r - 1) && (j == c - 1))
    {
        if (a[r - 1][c - 2]) br++;
        if (a[r - 2][c - 1]) br++;
        if (a[r - 2][c - 2]) br++;
    }
    else if ((i == 0) && (j == c - 1))
    {
        if (a[0][c - 2]) br++;
        if (a[1][c - 1]) br++;
        if (a[1][c - 2]) br++;
    }
    else if ((i == r - 1) && (j == 0))
    {
        if (a[r - 2][0]) br++;
        if (a[r - 1][1]) br++;
        if (a[r - 2][1]) br++;
    }
    else if (((i > 0) && (i < r)) && (j == 0))
    {
        if (a[i - 1][0]) br++;
        if (a[i + 1][0]) br++;
        if (a[i - 1][1]) br++;
        if (a[i + 1][1]) br++;
        if (a[i][1]) br++;
    }
    else if (((i > 0) && (i < r)) && (j == c - 1))
    {
        if (a[i - 1][j]) br++;
        if (a[i + 1][j]) br++;
        if (a[i - 1][j - 1]) br++;
        if (a[i + 1][j - 1]) br++;
        if (a[i][j - 1]) br++;
    }
    else if (((j > 0) && (j < c)) && (i == 0))
    {
        if (a[i][j - 1]) br++;
        if (a[i][j + 1]) br++;
        if (a[i + 1][j]) br++;
        if (a[i + 1][j - 1]) br++;
        if (a[i + 1][j + 1]) br++;
    }
    else if (((j > 0) && (j < c)) && (i == r - 1))
    {
        if (a[i - 1][j]) br++;
        if (a[i - 1][j - 1]) br++;
        if (a[i - 1][j + 1]) br++;
        if (a[i][j - 1]) br++;
        if (a[i][j + 1]) br++;
    }
    else
    {
        if (a[i][j - 1]) br++;
        if (a[i][j + 1]) br++;
        if (a[i + 1][j - 1]) br++;
        if (a[i + 1][j + 1]) br++;
        if (a[i + 1][j]) br++;
        if (a[i - 1][j - 1]) br++;
        if (a[i - 1][j + 1]) br++;
        if (a[i - 1][j]) br++;
    }
    return br;
}

void neighbour()
{
    for (int i = 0; i < r; i++)
        for (int j = 0; j < c; j++)
            neighbouring[i][j] = neighbours(i, j);
}

void new_board()
{
    count1 = 0;
    for (int i = 0; i < r; i++)
        for (int j = 0; j < c; j++)
        {
            if ((neighbouring[i][j] == 3) && (a[i][j] == 0)) a[i][j] = 1;
            else if (((neighbouring[i][j] < 2) || (neighbouring[i][j] > 3)) && (a[i][j] == 1)) a[i][j] = 0;
            if (a[i][j]) count1++;
        }
}

int main()
{
    scanf("%d%d%d", &n, &r, &c);
    for (int i = 0; i < r; i++)
        for (int j = 0; j < c; j++)
            cin >> a[i][j];
    
    neighbour();
    
    for (int i = 0; i < n; i++)
    {
        new_board();
        if (i < n - 1) neighbour();
    }
    
    cout << count1 << endl;//printf("%d\n", &count1);
    
    return 0;
}
