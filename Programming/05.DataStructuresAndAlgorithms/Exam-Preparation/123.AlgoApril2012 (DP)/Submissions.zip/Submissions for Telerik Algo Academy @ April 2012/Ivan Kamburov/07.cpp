#include <cstdio>

using namespace std;

int n, a[51], m;

int main()
{
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
    scanf("%d", &m);
    //cout << n + 1 << endl;
    int i = 1;
    while ((i <= n) && (m - a[i] > 0)) i++;
    
    if (i == n + 1) printf ("%d\n", i);
    else printf ("%d\n", (int)((int)(i/2) + (i%2) + 1));
    
    return 0;
}
