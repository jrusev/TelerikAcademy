#include <iostream>
   
using namespace std;
   
int main()
{
    long long t1, t2, t3, tn = 0;
    int n;
       
    cin >> t1 >> t2 >> t3 >> n;
       
    if (n == 1) tn = t1;
    else if (n == 2) tn = t2;
    else if (n == 3) tn = t3;
    else
    {
        for (int i = 4; i <= n; i++)
        {
            tn = t1 + t2 + t3;
            //cout << "t1 = " << t1 << " t2 = " << t2 << " t3 = " << t3 << " t" << i << " = " << tn << endl;
            t1 = t2;
            t2 = t3;
            t3 = tn;
        }
    }
       
    cout << tn << endl;
       
    return 0;
}