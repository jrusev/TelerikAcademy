#include <cstdio>

using namespace std;

struct block
{
    int min, mid, max;
};

void special_sort(block &aa)
{
    int a = aa.min, b = aa.mid, c = aa.max;
    if ((b < a) && (b < c)) aa.min = b;
    else if ((c < a) && (b > c)) aa.min = c;
    
    if (((a > b) && (a < c)) || ((a > c) && (a < b))) aa.mid = a;
    else if (((c > b) && (a > c)) || ((a < c) && (c < b))) aa.mid = c;
    
    if ((a > b) && (a > c)) aa.max = a;
    else if ((b > a) && (b > c)) aa.max = b;
}

block in[15];

int n;

int main()
{
    scanf("%d", &n);
    
    for (int i = 0; i < n; i++)
    {
        scanf("%d%d%d", &in[i].min, &in[i].mid, &in[i].max);
        special_sort(in[i]);
    }
    
    long long sum = 0;
    
    for (int i = 0; i < n; i++)
    {
        sum += in[i].max;
    }
    
    printf("%ld", sum);
    
    return 0;
}
