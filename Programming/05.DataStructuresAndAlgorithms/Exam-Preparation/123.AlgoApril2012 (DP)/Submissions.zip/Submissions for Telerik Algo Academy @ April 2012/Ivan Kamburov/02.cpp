#include <cstdio>
#include <iostream>

using namespace std;

int super_sum[14][14];

long long superSum(int k, int n)
{
    if (k == 0) return n;
    
    if (super_sum[k][n] == 0)
    {
        for (int i = 0; i < n; i++) super_sum[k][n] += superSum(k - 1, i + 1);
    }
    
    return super_sum[k][n];
}

int main()
{
    int n, k;
    scanf("%d%d", &k, &n);
    
    for (int i = 0; i < n; i++) super_sum[0][i] = i + 1;
    
    cout << (long long)superSum(k, n) << endl;
    
    return 0;
}
