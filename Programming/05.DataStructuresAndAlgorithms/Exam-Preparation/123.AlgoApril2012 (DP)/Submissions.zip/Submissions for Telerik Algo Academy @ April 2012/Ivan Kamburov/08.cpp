#include <cstdio>
#include <string.h>
//#include <vector>

using namespace std;

int r, w, size;
char s[2501];
//vector<char>luck;
int days = 0;//vector<int>days;

void sub_str()
{
    char a = s[0];
    int br = 1;
    for (int i = 1; i < size; i++)
    {
        while (s[i] == a)
        {
            br++;
            i++;
        }
        if (a == 'G') days += (((br / (r + 1)) * r) + (br % (r + 1)));
        //luck.push_back(a);
        //days.push_back(br);
        //br = 1;
        a = s[i];
    }
}

int main()
{
    scanf("%d%d%s", &r, &w, s);
    size = strlen(s);
    sub_str();
    
    printf("%d\n", days);
    
    return 0;
}