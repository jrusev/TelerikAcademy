#include <cstdio>
#include <iostream>
 
using namespace std;
 
char a[100][100];
int s_row, s_col, e_row, e_col, t, n, m, br = 0, filled = 0;
 
int main()
{
    scanf("%d%d%d", &t, &n, &m);
     
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
        {
            cin >> a[i][j];
            if (a[i][j] == '#') filled++;
        }
     
    printf("%d\n", m);
     
    return 0;
}