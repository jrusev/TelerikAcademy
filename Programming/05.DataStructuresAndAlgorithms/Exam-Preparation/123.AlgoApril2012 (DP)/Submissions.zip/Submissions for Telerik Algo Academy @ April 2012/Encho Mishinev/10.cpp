#include <iostream>
using namespace std;
char floor[15][15];
int main()
{
    int i,j,n,m,t,in;
    int down,right;
    int woodenplakes=0;
    int k=65;
    cin>>t;
    cin>>n>>m;
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=m;j++)
        {
            cin>>floor[i][j];
        }
    }
    for (i=1;i<=n;i++)
    {
        down=0;
        right=0;
        for (j=1;j<=m;j++)
        {
            if (floor[i][j]=='.')
            {


            in=i;
            while (floor[in][j]=='.' && in<=n)
            {
                down++;
                in++;
            }
            in=j;
            while (floor[i][in]=='.' && in<=m)
            {
                right++;
                in++;
            }
            if (right>=down)
            {
                in=j;
                while (floor[i][in]=='.' && in<=m)
                {
                    floor[i][in]=(char)k;
                    in++;
                }
                k++;
            }
            else
            {
                in=i;

                while (floor[in][j]=='.' && in<=n)
                {
                    floor[in][j]=(char)k;
                    in++;
                }
                k++;
            }
            woodenplakes++;

            }
        }
    }
    if (t==1)
    cout<<woodenplakes<<endl;
    else
    {
        for (i=1;i<=n;i++)
        {
            for (j=1;j<=m;j++)
            {
                cout<<floor[i][j];
            }
            cout<<endl;
        }
    }
    return 0;
}
