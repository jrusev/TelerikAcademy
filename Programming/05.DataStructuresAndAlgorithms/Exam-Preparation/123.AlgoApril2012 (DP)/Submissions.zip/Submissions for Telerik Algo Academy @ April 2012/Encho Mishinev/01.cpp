#include <iostream>
using namespace std;
int main()
{
    long long a,b,c,d,n;
    long long i;
    cin>>a>>b>>c>>n;
    for (i=4;i<=n;i++)
    {
        d=a+b+c;
        a=b;
        b=c;
        c=d;
    }
    cout<<c<<endl;
    return 0;
}
