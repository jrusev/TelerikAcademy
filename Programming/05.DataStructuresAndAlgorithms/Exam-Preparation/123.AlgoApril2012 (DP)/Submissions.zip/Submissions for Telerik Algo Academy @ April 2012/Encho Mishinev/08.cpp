#include <iostream>
using namespace std;
int main()
{
    int gooddays=0;
    int w,r;
    int i,j;
    int currgood=0,currbad=0;
    cin>>w>>r;
    string future;
    cin>>future;
    for (i=0;i<future.length();i++)
    {
        if (future[i]=='G')
        {
            if (currgood<w)
            {
                currbad=0;
                currgood++;
                gooddays++;
            }
            else
            {
                currbad++;
                currgood=0;
            }
        }
        if (future[i]=='B')
        {
            if (currbad<r)
            {
                currbad++;
                currgood=0;
                gooddays++;
            }
            else
            {
                currbad=0;
                currgood++;
            }
        }
    }
    cout<<gooddays<<endl;
    return 0;
}
