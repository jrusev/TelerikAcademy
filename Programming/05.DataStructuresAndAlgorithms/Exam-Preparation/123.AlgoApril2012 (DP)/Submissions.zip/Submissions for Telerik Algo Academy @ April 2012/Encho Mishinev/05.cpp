#include <iostream>
using namespace std;
long long TableOfLife[130][130];
long long NextGeneration[130][130];
int main()
{
    long long r,c;
    long long n;
    long long i,j,in;
    long long sum;
    cin>>n;
    cin>>r>>c;
    for (i=0;i<=r+1;i++)
    {
        TableOfLife[i][0]=0;
        TableOfLife[i][c+1]=0;
    }
    for (i=1;i<=c;i++)
    {
        TableOfLife[0][i]=0;
        TableOfLife[r+1][i]=0;
    }
    for (i=1;i<=r;i++)
    {
        for (j=1;j<=c;j++)
        {
            cin>>TableOfLife[i][j];
        }
    }
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=r;j++)
        {
            for (in=1;in<=c;in++)
            {
                sum=TableOfLife[j][in+1]+TableOfLife[j][in-1]+TableOfLife[j+1][in+1]+TableOfLife[j+1][in-1]+TableOfLife[j+1][in]+TableOfLife[j-1][in+1]+TableOfLife[j-1][in-1]+TableOfLife[j-1][in];
                if (TableOfLife[j][in]==1)
                {
                    if (sum==2 || sum==3)
                    NextGeneration[j][in]=1;
                    else
                    NextGeneration[j][in]=0;
                }
                else
                {
                    if (sum==3)
                    NextGeneration[j][in]=1;
                    else
                    NextGeneration[j][in]=0;
                }
            }
        }
        for (j=1;j<=r;j++)
        {
            for (in=1;in<=c;in++)
            {
                TableOfLife[j][in]=NextGeneration[j][in];
            }
        }
    }
    sum=0;
    for (i=1;i<=r;i++)
    {
        for (j=1;j<=c;j++)
        {
            if (TableOfLife[i][j]==1)
            sum++;
        }
    }
    cout<<sum<<endl;
    return 0;
}
