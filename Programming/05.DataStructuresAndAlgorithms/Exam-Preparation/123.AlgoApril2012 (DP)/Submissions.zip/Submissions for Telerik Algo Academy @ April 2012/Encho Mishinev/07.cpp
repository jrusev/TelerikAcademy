#include <iostream>
using namespace std;
int F[51][51][51];
int calcway(int x,int y)
{
    int way=0;
    while (1)
    {
        if (x==y)
        return way;
        else if (y-x==1)
        return way+2;
        else if (y-x==2)
        return way+2;
        else
        {
            way++;
            x=x+2;
        }
    }
}
int main()
{
    int i,j,in;
    int n,like[51];
    int hate;
    int totalmin,min;
    cin>>n;
    for (i=1;i<=n;i++)
    {
        cin>>like[i];
    }
    for (i=1;i<=50;i++)
    {
        for (j=1;j<=50;j++)
        {
            for (in=0;in<=50;in++)
            F[i][j][in]=0;
        }
    }
    cin>>hate;

    totalmin=999;
    for (i=1;i<=n;i++)
    {
        for (j=i;j<=n;j++)
        {
            if (like[j]-like[i]>=hate || like[i]-like[j]>=hate)
            {
                min=calcway(1,i)+calcway(i,j);

                if (i!=1)
                min--;

                if (min<totalmin)
                totalmin=min;
            }
        }
    }
    if (totalmin!=999)
    cout<<totalmin<<endl;
    else
    cout<<n<<endl;
    return 0;
}
