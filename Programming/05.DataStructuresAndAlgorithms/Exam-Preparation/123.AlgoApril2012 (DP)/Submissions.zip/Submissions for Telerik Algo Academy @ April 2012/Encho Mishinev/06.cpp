#include <iostream>
using namespace std;
string words[51];
int wordcount;
int mem[51][51];
string code;
int k;

bool IsCorrect(int str,int end,string check)
{
    if (end-str+1!=check.length())
    return false;

    int nums1[30];
    int nums2[30];
    int i;
    for (i=0;i<=29;i++)
    {
        nums1[i]=0;
        nums2[i]=0;
    }
    for (i=str;i<=end;i++)
    {
        nums1[ (int)code[i]-(int)'a' ]++;
    }
    for (i=0;i<check.length();i++)
    {
        nums2[ (int)check[i]-(int)'a' ]++;
    }
    for (i=0;i<=29;i++)
    {
        if (nums1[i]!=nums2[i])
        return false;
    }
    return true;
}

int Cost(int str,int end,string check)
{
    int i;
    int cost=0;
    for (i=0;i<check.length();i++)
    {
        if (check[i]!=code[i+str])
        cost++;
    }
    return cost;
}

int GetEmNow(int l,int r)
{
    //cout<<"Getting in with l="<<l<<" and r="<<r<<endl;
    if (l>r)
    return 0;

    int i,j;
    int num1,num2,num3;
    int min=999999999;

    for (i=1;i<=wordcount;i++)
    {
        //cout<<"current word is "<<words[i]<<" so you must know if we will proceed"<<endl;
        if (r-l+1>=words[i].length())
        {
            //cout<<"were in afterALL"<<endl;
            for (j=l;j<=r-words[i].length()+1;j++)
            {
               // cout<<"So we are trying to place it between "<<j<<" and "<<j+words[i].length()-1<<endl;
                if ( IsCorrect(j,j+words[i].length()-1,words[i]) )
                {
                   // cout<<"its ofcourse correct so lemme just calculate it"<<endl;
                    num1=Cost(j,j+words[i].length()-1,words[i]);
                   // cout<<"the cost of the word is "<<num1<<endl;
                    //cin>>k;
                    if ( mem[j+words[i].length()][r]==-1 )
                    {
                        num2=GetEmNow(j+words[i].length(),r);
                        mem[j+words[i].length()][r]=num2;
                    }
                    else
                    {
                        num2=mem[j+words[i].length()][r];
                    }
                    //cout<<"heeey im back from the long trip for checking "<<j+words[i].length()<<" to "<<r<<" and i know num2="<<num2<<", brb num3"<<endl;
                    //cin>>k;
                    if ( mem[l][j-1]==-1 )
                    {
                        num3=GetEmNow(l,j-1);
                        mem[l][j-1]=num3;
                    }
                    else
                    {
                        num3=mem[l][j-1];
                    }
                    //cout<<"and also num3="<<num3<<endl;
                    if (num2!=-1)
                    {
                        if (min>num1+num2+num3)
                        {
                            min=num1+num2+num3;
                            //cout<<"maaan new min="<<min<<endl;
                        }
                    }
                }
            }
        }
    }
    //cin>>k;
    if (min==999999999)
    return -1;
    else
    return min;
}

int main()
{

    string help;
    int i,j;
    cin>>code;
    cin>>wordcount;
    for (i=1;i<=wordcount;i++)
    cin>>words[i];

    for (i=0;i<=50;i++)
    {
        for (j=0;j<=50;j++)
        {
            mem[i][j]=-1;
        }
    }
    for (i=1;i<=wordcount;i++)
    {
        help="";
        for (j=0;j<words[i].length();j++)
        {
            if (words[i][j]>='a' && words[i][j]<='z')
            help=help+words[i][j];
        }
        words[i]=help;
    }
    cout<<GetEmNow(0,code.length()-1)<<endl;
    return 0;
}
