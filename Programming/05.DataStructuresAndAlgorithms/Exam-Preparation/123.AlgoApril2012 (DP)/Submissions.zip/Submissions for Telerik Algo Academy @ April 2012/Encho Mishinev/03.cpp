#include <iostream>
using namespace std;
bool OK(string k)
{
    long long brackets=0;
    long long i;

    if (k.length()%2==1)
    return false;

    for (i=0;i<k.length();i++)
    {
        if (k[i]=='(' || k[i]=='?')
            brackets++;
        else
            brackets--;

        if (brackets<0)
        return false;
    }
    brackets=0;
    for (i=k.length()-1;i>=0;i--)
    {
        if (k[i]==')' || k[i]=='?')
            brackets++;
        else
            brackets--;

        if (brackets<0)
        return false;
    }
    return true;
}

bool OnlyQ(string a)
{
    long long i;
    for (i=0;i<a.length();i++)
    {
        if (a[i]!='?')
        return false;
    }
    return true;
}

long long variations(string k)
{
   //?? cout<<"incoming "<<k<<endl;
        long long i,j;
        long long num1,num2;
        long long total=0;
        long long KL=k.length();
        string p="";
        if (OnlyQ(k))
        {
            //cout<<"luckily its only Q"<<endl;
            return ( 1+( (KL/2-1)*(KL/2-1) ) );
        }
        else
        {
           // cout<<"its not Qs"<<endl;
            k[0]='(';
            k[KL-1]=')';
            //cout<<"getting in!, k="<<k<<endl;
            for (i=1;i<KL;i++)
            {
               // cout<<"lets calculate"<<endl;
                p="";
                if (k[i]==')' || k[i]=='?')
                {
                    //cout<<"i believe "<<i<<" is good end"<<endl;
                    if (i!=1)
                    {
                        for (j=1;j<=i-1;j++)
                        p=p+k[j];

                        if (OK(p))
                        num1=variations(p);
                        else
                        num1=0;
                    }
                    else
                    num1=1;

                    //cout<<"num1 is now officially "<<num1<<endl;

                    if (i!=KL-1)
                    {
                        for (j=i+1;j<=KL-1;j++)
                        p=p+k[j];

                        if (OK(p))
                        {
                           // cout<<"ITS TIME TO DUEL"<<endl;
                            num2=variations(p);
                        }
                        else
                        num2=0;
                    }
                    else
                    num2=1;

                   // cout<<"and ofcourse, num2 is "<<num2<<endl;

                    total=total+(num1*num2);
                    //cout<<"and as u may know total="<<total<<" total with k="<<k<<" i meant"<<endl;
                }
            }
        }
        return total;
}
int main()
{
    string a;
    cin>>a;
    cout<<variations(a)<<endl;
    return 0;
}
