#include <iostream>
#include <vector>
using namespace std;
int wid[16],hid[16],lid[16];
int maxes=-1;
int n;
bool used[16];
void batrak(int h,int w,int l)
{
    if (maxes<h)
    maxes=h;
    int i;
    bool flag=false;
    for (i=1;i<=n;i++)
    {
        if (!used[i])
        flag=true;
    }
    if (!flag)
    return;
    for (i=1;i<=n;i++)
    {
        if (!used[i])
        {
            used[i]=true;
            if (hid[i]<=w && lid[i]<=l)
            batrak(h+wid[i],hid[i],lid[i]);
            if (wid[i]<=w && lid[i]<=l)
            batrak(h+hid[i],wid[i],lid[i]);
            if (lid[i]<=w && wid[i]<=l)
            batrak(h+hid[i],lid[i],wid[i]);
            if (hid[i]<=w && wid[i]<=l)
            batrak(h+lid[i],hid[i],wid[i]);
            if (wid[i]<=w && hid[i]<=l)
            batrak(h+lid[i],wid[i],hid[i]);
            if (lid[i]<=w && hid[i]<=l)
            batrak(h+wid[i],lid[i],hid[i]);
            used[i]=false;
        }
    }
}
int main()
{
    int i;

    cin>>n;
    for (i=1;i<=n;i++)
    {
        used[i]=false;
        cin>>wid[i]>>hid[i]>>lid[i];
    }
    for (i=1;i<=n;i++)
    {
        used[i]=true;
        batrak(wid[i],hid[i],lid[i]);
        batrak(hid[i],wid[i],lid[i]);
        batrak(hid[i],lid[i],wid[i]);
        batrak(lid[i],hid[i],wid[i]);
        batrak(lid[i],wid[i],hid[i]);
        batrak(wid[i],lid[i],hid[i]);
        used[i]=false;
    }
    cout<<maxes<<endl;
    return 0;
}
