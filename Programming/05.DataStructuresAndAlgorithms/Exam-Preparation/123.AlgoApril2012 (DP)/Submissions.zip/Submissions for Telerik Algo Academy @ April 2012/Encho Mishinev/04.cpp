#include <iostream>
using namespace std;
bool possiblesums[1001];
bool possible[1001];
bool usednum[1001][52];
long long c,m,b;
bool TrySums(long long num,long long numid)
{
    //cout<<"going with "<<num<<endl;
    bool usednumnow[1001][52];
    long long i,j;
    long long ctr=0;

    for (i=0;i<=1000;i++)
    {
        possible[i]=false;
        for (j=0;j<=51;j++)
        usednumnow[i][j]=false;
    }


    for (i=m;i>=0;i--)
    {
        if (possiblesums[i] && usednum[i][numid-1])
        {
            if (i+num>=0 && i+num<=m)
            {
                possible[i+num]=true;
                usednumnow[i+num][numid]=true;
            }
        }
    }
    for (i=0;i<=m;i++)
    {
        if (possible[i])
        {
           possiblesums[i]=true;
           for (j=0;j<=51;j++)
           {
               if (usednumnow[i][j])
               usednum[i][j]=true;
           }
           ctr++;
        }
    }
    if (ctr==0)
    return false;
    else
    return true;
}
int main()
{
    long long sounds[1001];
    long long i,j;
    bool one,two;
    for (i=0;i<=1000;i++)
    {
        possiblesums[i]=false;
        for (j=0;j<=51;j++)
        usednum[i][j]=false;
    }

    cin>>c;
    for (i=1;i<=c;i++)
    {
        cin>>sounds[i];
    }
    cin>>b;
    cin>>m;
    possiblesums[b]=true;
    usednum[b][1]=true;
    //cout<<"true becomes "<<b<<endl;
    for (i=1;i<=c;i++)
    {
        one=TrySums(sounds[i],i+1);
        two=TrySums(sounds[i]*-1,i+1);
        if (!one && !two)
        {
            cout<<-1<<endl;
            return 0;
        }
    }
    for (i=m;i>=0;i--)
    {
        if (possiblesums[i] && usednum[i][c+1])
        {
            cout<<i<<endl;
            return 0;
        }
    }
    return 0;
}
