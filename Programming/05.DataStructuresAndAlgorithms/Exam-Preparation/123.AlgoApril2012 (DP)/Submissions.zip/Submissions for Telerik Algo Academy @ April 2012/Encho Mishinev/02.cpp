#include <iostream>
using namespace std;
long long mem[15][15];
long long SuperSum(long long k,long long n)
{
    long long ss,ans=0;
    long long i;

    if (mem[k][n]!=-1)
    return mem[k][n];
    else
    {
        for (i=1;i<=n;i++)
        {
            ss=SuperSum(k-1,i);
            mem[k-1][i]=ss;
            ans=ans+ss;
        }
        return ans;
    }
}
int main()
{
    long long i,j;
    long long n,k;
    for (i=0;i<=14;i++)
    {
        for (j=0;j<=14;j++)
        {
            mem[i][j]=-1;
        }
    }
    for (i=0;i<=14;i++)
    {
        mem[0][i]=i;
    }
    cin>>k>>n;
    cout<<SuperSum(k,n);
}