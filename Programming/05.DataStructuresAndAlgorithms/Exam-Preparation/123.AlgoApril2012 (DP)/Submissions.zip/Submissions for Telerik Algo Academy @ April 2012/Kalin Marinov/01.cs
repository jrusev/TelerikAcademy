using System;

namespace ConsoleStuff
{
    class Program
    {
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            int T1 = int.Parse(line.Substring(0, line.IndexOf(" "))); 
            line = line.Substring(line.IndexOf(" ")+1);
            int T2 = int.Parse(line.Substring(0, line.IndexOf(" ")));
            line = line.Substring(line.IndexOf(" ") + 1);
            int T3 = int.Parse(line.Substring(0, line.IndexOf(" ")));
            int N = int.Parse(line.Substring(line.IndexOf(" ")))-3;
            int nextmember;
            for (; N > 0; N--)
            {
                nextmember = T1 + T2 + T3;
                T1 = T2;
                T2 = T3;
                T3 = nextmember;
            }
            Console.WriteLine(T3);
        }
    }
}
