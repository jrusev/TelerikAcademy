using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ALgo
{
    class Program
    {
        static void Main()
        {
            var a = Console.ReadLine();
            var b = a.Substring(a.IndexOf(' ') + 1);
            var c = b.Substring(b.IndexOf(' ') + 1);
            var d = c.Substring(c.IndexOf(' ') + 1);
            int T1 = int.Parse(a.Substring(0, a.IndexOf(' ') + 1));
            int T2= int.Parse(b.Substring(0, b.IndexOf(' ') + 1));
            int T3 = int.Parse(c.Substring(0, b.IndexOf(' ') + 1));
            int N = int.Parse(d);            
            int T = 0;

                for (; N > 3; N--)
                {
                    T = T1 + T2 + T3;
                    T1 = T2;
                    T2 = T3;
                    T3 = T; 
                }
                
               Console.WriteLine(T3);

        }
    }
}