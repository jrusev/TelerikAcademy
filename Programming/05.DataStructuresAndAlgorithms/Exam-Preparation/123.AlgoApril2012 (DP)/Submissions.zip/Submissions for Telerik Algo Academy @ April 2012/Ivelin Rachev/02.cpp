#include<iostream>
using namespace std;
long long a[16][16];
long long supersum(long long k,long long n)
{
  if(a[k][n]!=-1)return a[k][n];
  long long t=0;
  for(int i=1;i<=n;i++)
  {
    t+=supersum(k-1,i);
  }
  a[k][n]=t;
  return t;
}
int main()
{
  long long n,k;
  for(int i=0;i<16;i++)a[0][i]=i;
  for(int i=1;i<16;i++)
  for(int j=0;j<16;j++)a[i][j]=-1;
  cin>>n>>k;
  supersum(n,k);
  //supersum(n,k);
  cout<<a[n][k]<<endl;
  return 0;
}