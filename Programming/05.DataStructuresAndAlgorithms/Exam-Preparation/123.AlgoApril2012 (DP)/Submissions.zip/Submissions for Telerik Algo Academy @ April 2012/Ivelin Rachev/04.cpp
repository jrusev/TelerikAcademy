#include<iostream>
using namespace std;
int c,a[128],b,m,ans=-1;
int dp[64][1024];
int main()
{
 cin>>c;
 for(int i=0;i<c;i++)
 cin>>a[i];
 cin>>b>>m;
 dp[0][b]=1;
 for(int i=0;i<c;i++)
  for(int j=0;j<=m;j++)
  {
    if(dp[i][j]==1)
      {
        if(j+a[i]<=m)
        dp[i+1][j+a[i]]=1;
        if(j-a[i]>=0)
        dp[i+1][j-a[i]]=1;
      }
  }
  for(int j=m;j>=0;j--)
    if(dp[c][j]==1){cout<<j<<endl;return 0;}
    cout<<-1<<endl;
    return 0;
}