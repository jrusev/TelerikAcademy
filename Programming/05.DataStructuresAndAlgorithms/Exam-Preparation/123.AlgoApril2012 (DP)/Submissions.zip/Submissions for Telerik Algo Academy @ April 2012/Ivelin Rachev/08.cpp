#include<iostream>
#include<string>
using namespace std;
int main()
{
  int r,w;
  cin>>r>>w;
  string s;
  char c;
  cin.get(c);
  getline(cin,s);
  int ans=0;
  int n=s.size();
  for(int i=0;i<n;i++)
  {
    if(s[i]=='G')
    {
      int brg=1;
      i++;
      while(s[i]=='G' && i<n)
      {
        brg++;
        i++;
      }
      ans+=brg-(brg)/(r+1);
      i--;
    }
    else
    {
      int brb=1;
      i++;
      while(s[i]=='B' && i<n)
      {
        brb++;
        i++;
      }
      ans+=brb-(brb)/(w+1);
      i--;
    }
  }
  cout<<ans<<endl;
}