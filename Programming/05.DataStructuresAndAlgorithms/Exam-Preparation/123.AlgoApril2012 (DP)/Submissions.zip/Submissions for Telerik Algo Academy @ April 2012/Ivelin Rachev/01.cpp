#include<iostream>
using namespace std;
int main()
{
  int n;
  long long t1,t2,t3;
  cin>>t1>>t2>>t3>>n;
  if(n==1)
  {cout<<t1<<endl;return 0;}
  if(n==2)
  {cout<<t2<<endl;return 0;}
  if(n==3)
  {cout<<t3<<endl;return 0;}
  for(int i=4;i<=n;i++)
  {
    int t=t1+t2+t3;
    t1=t2;
    t2=t3;
    t3=t;
  }
  cout<<t3<<endl;
  return 0;
}