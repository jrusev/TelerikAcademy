#include<iostream>
#include<cmath>
using namespace std;
int main()
{
  int n,a[128];
  cin>>n;
  for(int i=0;i<n;i++)
  cin>>a[i];
  int ans=n-1;
  int raz;
  cin>>raz;
  for(int i=0;i<n;i++)
    for(int j=i+1;j<n;j++)
    {
      if(abs(a[j]-a[i])>=raz)
        ans=min(ans,(i+1)/2+(j-i+1)/2);
    }
    cout<<ans+1<<endl;
    return 0;
}