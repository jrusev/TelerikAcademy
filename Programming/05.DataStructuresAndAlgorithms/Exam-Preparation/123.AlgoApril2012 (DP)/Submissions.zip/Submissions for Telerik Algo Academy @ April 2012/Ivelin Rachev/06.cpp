#include<iostream>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int find_cost(string code,string orig)
{
  int cost=0;
  int t=code.size();
  for(int i=0;i<t;i++)
    if(code[i]!=orig[i])cost++;
    return cost;
}
string dic[256];
  string dic_sort[256];
  string s;
  int dp[256];
  int n;
int create_dp(int start)
{
  string work="";
  string work_sort;
int  k=start+1;
  while(work.size()+start+1<s.size())
  {
    work+=s[k++];
    work_sort=work;
    sort(work_sort.begin(),work_sort.end());
   // cout<<work<<endl;
    for(int i=0;i<n;i++)
      if(dic_sort[i]==work_sort)
      {
      //  cout<<start<<" "<<k<<endl;
      if(dp[k-1]==-1)
        dp[k-1]=find_cost(work,dic[i])+dp[start];
        else
        dp[k-1]=min(dp[k-1],find_cost(work,dic[i])+dp[start]);
      }
  }
}
int main()
{
  for(int i=0;i<256;i++)
    dp[i]=-1;
  getline(cin,s);
  cin>>n;
  for(int i=0;i<n;i++)
  {
    cin>>dic[i];
    dic_sort[i]=dic[i];
    sort(dic_sort[i].begin(),dic_sort[i].end());
  }
  string work="";
  string work_sort;
  int k=0;
  while(work.size()<s.size())
  {
    work+=s[k++];
    work_sort=work;
    sort(work_sort.begin(),work_sort.end());
    //cout<<work_sort<<" "<<work<<endl;
    for(int i=0;i<n;i++)
      if(dic_sort[i]==work_sort)
        {
          if(dp[k-1])
        dp[k-1]=find_cost(work,dic[i]);
        else
        dp[k-1]=min(dp[k-1],find_cost(work,dic[i]));
        }
  }
  for(int i=0;i<s.size();i++)
  if(dp[i]!=-1)
  {
    create_dp(i);
  }
  cout<<dp[s.size()-1]<<endl;
  return 0;
}