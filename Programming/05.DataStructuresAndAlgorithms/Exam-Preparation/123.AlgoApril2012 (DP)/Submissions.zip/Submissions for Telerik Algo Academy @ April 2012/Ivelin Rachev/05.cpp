#include<iostream>
using namespace std;
struct square
{
  int status;
  int live;
}
field[256][256];
int change_code[256][256];
int n,r,c;
int main()
{
  cin>>n>>r>>c;
  for(int i=0;i<=c+1;i++){field[0][i].status=0;field[r+1][i].status=0;}
  for(int i=0;i<=r+1;i++){field[i][0].status=0;field[0][c+1].status=0;}
  for(int i=1;i<=r;i++)
    for(int j=1;j<=c;j++)
    {
      cin>>field[i][j].status;
      }
  for(int i=0;i<n;i++)
  {
    bool change=0;
  for(int i=1;i<=r;i++)
    for(int j=1;j<=c;j++)
    field[i][j].live=field[i-1][j-1].status+field[i-1][j].status+field[i-1][j+1].status+field[i][j-1].status+field[i][j+1].status+field[i+1][j-1].status+field[i+1][j].status+field[i+1][j+1].status;
  for(int i=1;i<=r;i++)
    for(int j=1;j<=c;j++)
    if(field[i][j].status==0 && field[i][j].live==3)
    {
      change=1;
      field[i][j].status=1;
    }
    else
    if(field[i][j].status==1 && (field[i][j].live<2 || field[i][j].live>3))
    {
      field[i][j].status=0;
      change=1;
    }
    if(change==0)break;
  }
  int ans=0;
  for(int i=1;i<=r;i++)
    for(int j=1;j<=c;j++)
      if(field[i][j].status==1)
      ans++;
      cout<<ans<<endl;
}


