#include<iostream>
using namespace std;
int c,m,b,t[51],mx=-1;
void rec(int a,int st)
{
if(st>=c){if(a>mx)mx=a;return;}
if( a+ t[st]<=b)rec(a+t[st],st+1);
if( a- t[st]>=0)rec(a-t[st],st+1);
}
int main()
{

cin>>c;for(int i=0;i<c;i++)
cin>>t[i];
cin>>m>>b;
rec(m,0);
cout<<mx<<endl;
return 0;
}