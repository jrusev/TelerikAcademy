#include<iostream>
#include<cstdlib>
using namespace std;
string s;
long long br=0,bro=0,brv=0,brz=0,p,k,b;
int ri;
void rec(int l,int r, int lu,int ru,int po)
{
    if(po==b)br++;
if(s[po]=='(')rec(l,r,lu+1,ru,po+1);
else if(s[po]==')'&&lu>ru)rec(l,r,lu,ru+1,po+1);
else if(s[po]=='?'){if(l>0)rec(l-1,r,lu+1,ru,po+1);
if(r>0&&lu>ru)rec(l,r-1,lu,ru+1,po+1);
}}
int main()
{
int l,r;
cin>>s;
b=s.size();
for(int i=0;i<s.size();i++)
{
if(s[i]=='(')bro++;
else if(s[i]==')')brz++;
else brv++;
}

if(abs(bro-brz)>brv || (bro+brz+brv)%2==1)cout<<0<<endl;
else {p=(brz+brv-bro)/2;
l=p;
r=brv-p;
rec(l,r,0,0,0);
cout<<br<<endl;
}
return 0;
}