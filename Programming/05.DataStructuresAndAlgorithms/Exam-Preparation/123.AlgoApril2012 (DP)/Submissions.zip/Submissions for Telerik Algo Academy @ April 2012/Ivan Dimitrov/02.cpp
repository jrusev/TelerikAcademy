#include<iostream>
using namespace std;
unsigned long long rec(int k,int n)
{
 unsigned long long s=1;
 if(k==1)for(int i=2;i<=n;i++)s=s+i;
 else for(int i=2;i<=n;i++)s=s+rec(k-1,i);
 return s;
 }
int main()
{
int K,N;
cin>>K>>N;
if(K==0)K=1;
cout<<rec(K,N)<<endl;
return 0;
}