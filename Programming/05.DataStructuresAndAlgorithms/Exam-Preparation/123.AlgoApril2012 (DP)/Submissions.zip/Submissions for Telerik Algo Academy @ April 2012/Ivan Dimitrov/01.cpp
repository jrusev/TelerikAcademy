#include<iostream>
using namespace std;
int main()
{
long long t[21],n,s;
cin>>t[0]>>t[1]>>t[2]>>n;
for(int i=3;i<=n-1;i++)
{
s=t[i-1]+t[i-2]+t[i-3];
t[i]=s;
}
cout<<t[n-1]<<endl;
return 0;
}
