#include <iostream>
using namespace std;
int main()
{
    long long T1, T2, T3, i, N;
    cin>>T1>>T2>>T3>>N;
    N=N-3;
    for (i=0;i<N/3;i++)
    {
        T1=T1+T2+T3;
        T2=T1+T2+T3;
        T3=T1+T2+T3;
    }
    if (N%3==0) T1=T3;
    if (N%3==1) T1=T1+T2+T3;
    if (N%3==2) {T1=T1+T2+T3;T2=T1+T2+T3;T1=T2;}
    cout<<T1<<endl;
   // system ("pause");
    return 0;
}
