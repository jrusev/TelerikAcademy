#include <iostream>
#include <cstdlib>
using namespace std;
unsigned long long br=0, b;
string a;
void recurse (int left, int right, int leftused, int rightused, int pos)
{
     if (pos==b) br++;
     if (a[pos]=='(') recurse (left, right, leftused+1, rightused, pos+1);
     else if (a[pos]==')'&&leftused>rightused) recurse (left, right, leftused, rightused+1, pos+1);
     else if (a[pos]=='?') {if (left>0) recurse (left-1, right, leftused+1, rightused, pos+1);
                            if (right>0&&rightused<leftused) recurse (left, right-1, leftused, rightused+1, pos+1);
                            }
}
int main ()
{
    cin>>a;
    b=a.size();
    int i, left, right, br1=0, br2=0, br3=0, x;
    for (i=0;i<a.size();i++)
    {
        if (a[i]=='(') br1++;
        else if (a[i]==')') br2++;
        else br3++;
    }
    if (abs(br1-br2)>br3||br1+br2+br3%2==1) cout<<0<<endl;
    else {x=(br2+br3-br1)/2;
          left=x;
          right=br3-x;
          recurse (left, right, 0, 0, 0);
          cout<<br<<endl;
         }
 //   system ("pause");
    return 0;
}