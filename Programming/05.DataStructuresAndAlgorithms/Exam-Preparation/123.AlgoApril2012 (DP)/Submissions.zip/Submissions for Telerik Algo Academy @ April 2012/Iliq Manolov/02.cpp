#include <iostream>
using namespace std;
unsigned long long recurse (int K, int N)
{
     unsigned long long sum=0, i;
     if (K==1) for (i=1;i<=N;i++) sum=sum+i;
     else for (int i=1;i<=N;i++)
              sum=sum+recurse(K-1, i);
     return sum;
}
int main ()
{
    int K, N;
    cin>>K>>N;
    if (K==0) K=1;
    cout<<recurse(K, N)<<endl;
   // system ("pause");
    return 0;
}
