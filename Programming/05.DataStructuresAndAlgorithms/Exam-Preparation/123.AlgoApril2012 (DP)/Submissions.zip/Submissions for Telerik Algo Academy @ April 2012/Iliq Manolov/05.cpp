#include <iostream>
using namespace std;
int main ()
{
    bool flag[130][130]={0}, flag2[130][130]={0};
    int N, R, C, i, j, k, sum;
    cin>>N>>R>>C;
    for (i=1;i<=R;i++)
        for (j=1;j<=C;j++)
            cin>>flag[i][j];
    for (i=0;i<N;i++)
    {   for (j=1;j<=R;j++)
            for (k=1;k<=C;k++)
            {
                sum=flag[j-1][k-1]+flag[j-1][k]+flag[j-1][k+1]+flag[j][k-1]+flag[j][k+1]+flag[j+1][k-1]+flag[j+1][k]+flag[j+1][k+1];
                if (flag[j][k]==0) {if (sum==3) flag2[j][k]=1;
                                    else flag2[j][k]=0;
                                   }
                else {if (sum==2||sum==3) flag2[j][k]=1;
                      else if (sum<2) flag2[j][k]=0;
                      else flag2[j][k]=0;
                     }
            }
        for (j=1;j<=R;j++)
            for (k=1;k<=C;k++)
                 flag[j][k]=flag2[j][k];
    }
    sum=0;
    for (i=1;i<=R;i++)
        for (j=1;j<=C;j++)
            sum=sum+flag[i][j];
    cout<<sum<<endl;
  //  system ("pause");
    return 0;
}