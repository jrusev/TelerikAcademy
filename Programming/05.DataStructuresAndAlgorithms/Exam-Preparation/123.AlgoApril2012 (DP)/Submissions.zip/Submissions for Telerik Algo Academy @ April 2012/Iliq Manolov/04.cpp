#include <iostream>
using namespace std;
int C, plusmin[64], B, maxa=-1;
void recurse (int tmp, int stage)
{
     if (stage>=C) {if (tmp>maxa) maxa=tmp;
                    return;}
     if (tmp+plusmin[stage]<=B) recurse(tmp+plusmin[stage], stage+1);
     if (tmp-plusmin[stage]>=0) recurse(tmp-plusmin[stage], stage+1);
}
int main ()
{
    int i, M;
    cin>>C;
    for (i=0;i<C;i++)
        cin>>plusmin[i];
    cin>>M>>B;
    recurse(M, 0);
    cout<<maxa<<endl;
//    system ("pause");
    return 0;
}