#include <iostream>
#include <cstdio>
using namespace std;
int n,k;
long long a[20][20],ans;

void sol()
{
        for (int i=1; i<=n; i++) a[0][i]=i;
        for (int i=1; i<k; i++)
        {
            for (int j=1; j<=n; j++) a[i][j]=a[i][j-1]+a[i-1][j];
        }
       // for (int i=0; i<k; i++){ for (int j=0; j<=n; j++) cout<<a[i][j]<<" "; cout<<endl;}
        for (int i=1; i<=n; i++) ans=ans+a[k-1][i];
        printf("%lld\n",ans);
}

int main ()
{
    scanf("%d %d",&k,&n);
    sol();
    return 0;
}
