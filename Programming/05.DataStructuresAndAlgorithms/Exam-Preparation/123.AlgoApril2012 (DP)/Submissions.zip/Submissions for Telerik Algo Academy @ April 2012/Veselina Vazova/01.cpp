#include <iostream>
#include <cstdio>
using namespace std;
long long t1,t2,t3,n,ch;

void sol()
{
    for (int i=3; i<n; i++)
    {
        ch=t1+t2+t3;
        t1=t2;
        t2=t3;
        t3=ch;
    }
    printf("%lld\n",t3);
}

int main ()
{
    scanf("%lld %lld %lld %lld",&t1,&t2,&t3,&n);
    sol();
    return 0;
}