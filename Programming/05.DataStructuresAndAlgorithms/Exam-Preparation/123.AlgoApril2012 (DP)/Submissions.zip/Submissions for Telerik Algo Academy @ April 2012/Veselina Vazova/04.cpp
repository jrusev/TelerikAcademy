#include <iostream>
#include <cstdio>
using namespace std;
int c,m,b,a[50],ans=-1;
bool sums[55000];
  
void sol()
{
    sums[b]=1;
    for (int i=0; i<c; i++)
    {
        for (int j=m+50000; j>=0; j--)
        {
            if (a[i]+j<=m&&sums[j]==1)
            {
                sums[j+a[i]]=1;
                if (i==c-1){ ans=j; break;}
                //cout<<j<<endl;
            }
            if (j-a[i]>=0&&sums[j]==1)
            {
                sums[j-a[i]]=1;
                if (i==c-1&&ans<j){ ans=j; break;}
                //cout<<j<<endl;
            }
        }
    }
    printf("%d\n",ans);
}
  
int main ()
{
    scanf("%d",&c);
    for (int i=0; i<c; i++) scanf("%d",&a[i]);
    scanf("%d %d",&b,&m);
    sol();
    return 0;
}