#include <iostream>
using namespace std;

int main () {
  int r, w, w1, r1, bestDays = 0;
  cin >> r >> w;
  char S[2500];
  cin >> S;

  for (int i = 0; S[i] != '\0'; ++ i) {
    w1 = w;
    while (S[i] != '\0' && S[i] == 'B' && w1 > 0) {
      S[i] = 'D';
      w1 --;
      ++ i;
    }
  }

  for (int i = 0; S[i] != '\0'; ++ i) {
    r1 = r;
    while (S[i] != '\0' && S[i] == 'G' && r1 > 0) {
      ++ bestDays;
      r1 --;
      ++ i;
    }

    r1 = r;
    while (S[i] != '\0' && S[i] == 'D' && r1 > 0) {
      ++ bestDays;
      r1 --;
      ++ i;
    }
  }

  cout << bestDays << endl;
  return 0;
}
