#include <iostream>
using namespace std;

int main () {
  int n, r, c, alive;
  bool smth[128][128], smth1[128][128];
  cin >> n >> r >> c;

  for (int i = 0; i < r; ++ i)
    for (int j = 0; j < c; ++ j)
      cin >> smth[i][j];
//*****************************************************************
  for (int k = 0; k < n; ++ k) {
    for (int i = 0; i < r; ++ i)
      for (int j = 0; j < c; ++ j) {
        alive = 0;
        if (i > 0 && j > 0 && smth[i - 1][j - 1]) ++ alive;
        if (i > 0 && smth [i - 1][j]) ++ alive;
        if (i > 0 && j < c - 1 && smth [i - 1][j + 1]) ++ alive;
        if (j > 0 && smth[i][j - 1]) ++ alive;
        if (j < c - 1 && smth [i][j + 1]) ++ alive;
        if (i < r - 1 && j > 0 && smth[i + 1][j - 1]) ++ alive;
        if (i < r - 1 && smth[i + 1][j]) ++ alive;
        if (i < r - 1 && j < c - 1 && smth[i + 1][j + 1]) ++ alive;

//        cout << i << ", " << j << " - " << alive << "\n\n";

        if (!smth[i][j] && alive == 3) smth1[i][j] = true;
        if (!smth[i][j] && (alive < 3 || alive > 3)) smth1[i][j] = false;
        if (smth[i][j] && (alive == 2 || alive == 3)) smth1[i][j] = true;
        if (smth[i][j] && (alive < 2 || alive > 3)) smth1[i][j] = false;
      }
//    for (int a = 0; a < r; ++ a) {
//      for (int b = 0; b < c; ++ b)
//        cout << smth[a][b];
//      cout << endl;
//    }
//    cout << endl;

    for (int a = 0; a < r; ++ a)
      for (int b = 0; b < c; ++ b)
        smth[a][b] = smth1[a][b];
  }
  alive = 0;
  for (int i = 0; i < r; ++ i)
    for (int j = 0; j < c; ++ j)
      if (smth[i][j])
        alive ++;
  cout << alive << endl;
  return 0;
}
