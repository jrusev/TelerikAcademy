#include <iostream>
using namespace std;

long long t1, t2, t3, n;

long long trib () {
  for (long long i = 4; i <= n; ++ i) {
    long long newTrib = t1 + t2 + t3;
    t1 = t2;
    t2 = t3;
    t3 = newTrib;
  }
  return t3;
}

int main () {

  cin >> t1 >> t2 >> t3 >> n;

  cout << trib() << endl;
  return 0;
}
