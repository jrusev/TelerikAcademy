#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int n;
int a[64];
    int b;
    int dp[64][64][64];

int go ( int x , int y , int z ) {
    if ( x > n ) return n;
    if ( a[z] - a[y] >= b ) return 0;
    if ( x == n ) return n;
    int &ans = dp[x][y][z];
    if ( ans != -1 ) return ans;

    ans = n;
    ans = min ( ans ,1+ go ( x + 1 , (a[x + 1] < a[y]) ? (x + 1) : y , (a[x + 1] > a[z]) ? (x + 1) : z ) );
    ans = min ( ans , 1+go ( x + 2 , (a[x +2] < a[y]) ? (x + 2) : y , (a[x +2] > a[z]) ? (x + 2) : z ) );

    return ans;
}

int main() {
    int na;
    int i;

    scanf ( "%d" , &n );
    for (i = 0; i < n; i++) {
        scanf ( "%d" , &a[i] );
    }
    scanf ( "%d" , &b );
    memset ( dp , -1 , sizeof dp );
    printf ( "%d\n" , min ( n , 1+ go ( 0 , 0 , 0) ) );

    return 0;
}
