#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;

int t;
int n , m;
char a[16][16];
char res[16][16];
char best[16][16];
char next;
int zero;

int dp[16][16][1 << 10][2];

void read() {
    int i;

    scanf ( "%d%d%d" , &t , &n , &m );
    for (i = 0; i < n; i++) {
        scanf ( "%s" , a[i] );
    }
}

int go ( int x , int y , int mask , int line ) {
    if ( y == m ) {
        ++ x; y = 0;
        line = 0;
    }
    if ( x == n ) return 0;

    int &ans = dp[x][y][mask][line];
    if ( ans != -1 ) return ans;

    ans = 0;
    if ( a[x][y] == '#' ) {
        ans = go ( x , y + 1 , mask & (~(1 << y)) , 0 );
    } else {
        //printf ( "-- %d %d   %d %d       %d %d\n" , x , y , mask , line , !line , (!(mask & (1 << y))) );
        ans = min ( go ( x , y + 1 , mask & (~(1 << y)) , 1 ) + !line ,
                    go ( x , y + 1 , mask | (1 << y) , 0 ) + (!(mask & (1 << y))) );
    }

  //  printf ( "%d %d    %d %d     %d\n" , x , y , mask , line , ans );

    return ans;
}

void checkans() {
    int i , j;
    int bau =0 ;
    if ( !zero ) bau = 1;

    if ( zero ) {
        zero = 1;
        for (i = 0; i < n && bau; i++) {
            for (j = 0; j < m && bau; j++) {
                if ( a[i][j] == '.' ) {
                    if ( res[i][j] < best[i][j] ) bau = 0;
                    if ( res[i][j] > best[i][j] ) return ;
                }
            }
        }
    }

    if ( bau ) for (i = 0; i < n; i++) for (j = 0; j < m; j++) best[i][j] = res[i][j];
}

void prnt ( int x , int y , int mask , int line ) {
    if ( y == m ) {
        ++ x; y = 0;
        line = 0;
    }
    if ( x == n ) {
     checkans();   return ;

    }
    int ans = go ( x , y , mask , line );

    if ( a[x][y] == '#' ) {
        prnt ( x , y + 1 , mask & (~(1 << y)) , 0 );
    } else {
         if ( ans ==  go ( x , y + 1 , mask & (~(1 << y)) , 1 ) + !line ) {
             if ( ans == go ( x , y + 1 , mask | (1 << y) , 0 ) + (!(mask & (1 << y))) ) {
                 if ( line && (mask & (1 << y)) ) {
                     if ( res[x][y - 1] < res[x - 1][y] ) {
                         res[x][y] = res[x][y - 1];
                          prnt ( x , y + 1 , mask & (~(1 << y)) , 1 );
                          return ;
                     } else {
                         res[x][y] = res[x - 1][y];
                        prnt ( x , y + 1 , mask | (1 << y) , 0 );
                        return ;
                     }
                 } else {
                       if ( (mask & (1 << y)) ) {
                    res[x][y] = res[x - 1][y];

                        prnt ( x , y + 1 , mask | (1 << y) , 0 );
                        return ;
                        } else {
                            if ( line ) {res[x][y] = res[x][y - 1];
                            } else {
                                int svnext = next;
                                res[x][y] = next ++;
                        prnt ( x , y + 1 , mask | (1 << y) , 0 );
                        checkans();
                        next = svnext + 1;
                             }

                         prnt ( x , y + 1 , mask & (~(1 << y)) , 1 );
                          return ;
                     }
                 }
             }

            if ( !line ) {
                res[x][y] = next ++;
            } else {
                res[x][y] = res[x][y - 1];
            }
            prnt ( x , y + 1 , mask & (~(1 << y)) , 1 );
         } else {
             if ( (mask & (1 << y)) ) {
                 res[x][y] = res[x - 1][y];
             } else {
                 res[x][y] = next ++;
             }
             prnt ( x , y + 1 , mask | (1 << y) , 0 );
         }
    }
}

void solve() {
    memset ( dp , -1 , sizeof dp );

    if ( t == 1 ) {
        printf ( "%d\n" , go ( 0 , 0 , 0 , 0 ) );
    } else {
        next = 'A';
        prnt ( 0 , 0 , 0 , 0 );

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if ( a[i][j] == '#' ) best[i][j] = a[i][j];
                printf ( "%c" , best[i][j] );
            }
            printf ( "\n" );
        }
    }
}

int main() {
    read();
    solve();

    return 0;
}
