#include <set>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int INF = 1 << 30;
int n , m;
char a[64];
char b[64][64];
int sz[64];
int dp[64];

void read() {
    scanf ( "%s" , a );
    n = (int)strlen ( a );

    scanf ( "%d" , &m );
    int i;

    for (i = 0; i < m; i++) {
        scanf ( "%s" ,b[i] );
        sz[i] = (int)strlen ( b[i] );
    }
}



int can ( int x , int y ) {
    multiset < char > s1 , s2;
    int i;

    for (i = 0; i < sz[y]; i++) {
        s1.insert ( a[x + i] );
        s2.insert ( b[y][i] );
    }

    return s1 == s2;
}

int go ( int x  ) {
    if ( x == n ) return 0;

    int &ans = dp[x];
    if ( ans != -1 ) return ans;

    ans = INF;
    int i , y , cur = 0;

    for (y = 0; y < m; y++) {
        cur = 0;
    if ( x + sz[y]- 1 < n && can ( x , y ) ) {
        for (i = 0; i < sz[y]; i++) {
            cur += (b[y][i] != a[x + i]);
        }

    //    printf ( "%d   %d    %d %d %d\n" , x , y , ans , cur , go ( x + sz[y] ) );

        ans = min ( ans , cur + go ( x + sz[y] ) );
    }
    }

    return ans;
}

void solve() {
    memset ( dp , -1 , sizeof dp );
    int ans = go ( 0  );
    if ( ans >= INF ) ans = -1;

    printf ( "%d\n" , ans );
}

int main() {
    read();
    solve();

    return 0;
}

