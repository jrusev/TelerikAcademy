#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

int n;
long long dp[1 << 15][16][4][4];
int a[16][4];

void read() {
    int i;

    scanf ( "%d" , &n );
    for (i = 0; i < n; i++) {
        scanf ( "%d%d%d" , &a[i][0] , &a[i][1] , &a[i][2] );
    }
}

long long go ( int mask , int x , int y , int z ) {
    long long &ans = dp[mask][x][y][z];
    if ( ans != -1 ) return ans;

    int i , j , k , d;
    ans = 0;

     for (i = 0; i < n; i++) {
         if ( mask & (1 << i) ) continue;

        for (j = 0; j < 3; j++) {
            if ( a[i][j] >= a[x][y] )
            for (k = j +1; k < 3; k++) {
                if ( j != k && a[i][k] >= a[x][z] ) {
                    for (d = 0; d < 3; d++) {
                        if ( d != k && d != j ) {
                            ans = max ( ans , go ( mask | (1 << i) , i , j , k ) + a[i][d] );
                        }
                    }
                }
            }
        }
    }

    return ans;
}

void solve() {
    long long ans = 0;
    int i , j , k , d;

    memset ( dp , -1 , sizeof dp );

    for (i = 0; i < n; i++) sort ( a[i] , a[i] + 3 );

    for (i = 0; i < n; i++) {
        for (j = 0; j < 3; j++) {
            for (k = j; k < 3; k++) {
                if ( j != k ) {
                    for (d = 0; d < 3; d++) {
                        if ( d != k && d != j ) {
                            ans = max ( ans , go ( 1 << i , i , j , k ) + a[i][d] );
                        }
                    }
                }
            }
        }
    }

    cout << ans << '\n';
}

int main() {
    read();
    solve();

    return 0;
}
